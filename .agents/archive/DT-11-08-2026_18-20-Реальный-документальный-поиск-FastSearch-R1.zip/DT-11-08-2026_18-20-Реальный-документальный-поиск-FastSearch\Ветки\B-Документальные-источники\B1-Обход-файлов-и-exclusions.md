<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист B1 — Обход файлов и exclusions

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch / Leaf ID: `B / B1`
- Вес задачи: `5%`
- Состояние: `MATERIALIZED после A integration c45d764dfac43f919567066572e44250030cf97e`

## Наблюдаемое изменение

- Baseline: accepted A; real filesystem input отсутствует.
- После листа: downstream parser получает только разрешённые supported UTF-8 files в стабильном repo-relative порядке.

## Целевое состояние листа

Scanner уважает accepted `.gitignore`/explicit exclusion/root-containment contract. Source files и внешний sentinel неизменны; `.git`, service/build/vendor/generated/binary и outside-root targets не становятся input.

## MG-B1 — исполнимый контракт

- Writable: `src/adapters/source/mod.rs` и его unit tests; `tests/b1_filesystem_scan.rs` только при необходимости public seam. Иные paths read-only.
- Private `ScannedSource`: canonical absolute path, slash-normalized repo-relative locator, UTF-8 bytes, kind Markdown/TSV. B1 не создаёт record/hash/snapshot.
- std-only scan: root containment, no symlink follow, `.md`/`.tsv`, lexical locator sort; excludes `.git`, `.agents`, `target`, `.cfknowledge`, service/build/vendor/generated, explicit/configured and narrow root `.gitignore` literal file/dir/trailing-slash entries. Unsupported rule -> `SourceFailure`, never false gitignore claim.
- Any non-excluded I/O/UTF-8/escape failure -> all-or-nothing `SourceFailure`; empty set valid. Test must prove outside-root sentinel or block on unavailable Windows symlink privilege.
- RED/GREEN: source-module test `scanner_returns_only_allowed_contained_utf8_sources_in_locator_order`; targeted `cargo test --lib adapters::source::tests::scanner_returns_only_allowed_contained_utf8_sources_in_locator_order --locked`, then all locked/fmt/clippy/all-targets. No dependency change.

## Границы состояния

- Owner: B; предполагаемая area `src/adapters/source/**` и scanner tests.
- Exclusions: parser semantics, state/index writes, public/dependency changes.

## Preconditions

- MG-B1 материализует exact base, paths, causal RED, failure policy и platform fixtures после accepted A.

## Наблюдаемые сценарии

- Определяются MG-B1 из accepted A corpus/exclusion oracle.

## Definition of Done

- Exact allowed-set, determinism, containment и sentinel evidence PASS; B2 может быть материализован.

## Операционная проверка

- Test oracle / команда: не назначены до MG-B1.
- Expected evidence: causal RED/GREEN/REFACTOR/PASS и exact candidate.
- Unverified areas: production scale и non-Windows behavior.

## Условия остановки

- Accepted A contract/dependencies не выражают required containment/failure behavior.
- Scope/ownership/gate drift требует Root replan.

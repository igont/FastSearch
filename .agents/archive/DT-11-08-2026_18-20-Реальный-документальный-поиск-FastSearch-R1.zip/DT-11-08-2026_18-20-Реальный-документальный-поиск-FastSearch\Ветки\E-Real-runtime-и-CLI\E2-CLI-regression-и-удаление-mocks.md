<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист E2 — CLI regression и удаление mocks

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-4`
- Branch / Leaf ID: `E / E2`
- Вес задачи: `7%`
- Состояние: `DORMANT OUTLINE до MG-E2`

## Наблюдаемое изменение

- Baseline: accepted E1 core/recovery without final real CLI/mock migration.
- После листа: built executable exposes accepted real document flow; all tests PASS under explicit migration mapping and production mock surface is absent.

## Целевое состояние листа

Real init/index/search/get/status and cross-process degraded/recovery scenarios match A regression outcomes. Mock-only baseline targets are migrated/replaced, not silently deleted: retained adapter-neutral assertions/goldens map to real-runtime tests. Test-only doubles are isolated/classified; production code/module registration/CLI contains no MockSource/MockState/MockLexical/MockRuntime/MockFacade/MockSymbols/adapters::mock/mock-search construction or route.

## Границы состояния

- Owner: E; MG-E2 fixes exact CLI/test/mock paths and migration map.
- Exclusions: public/dependency changes, MCP/vector/maps/symbol implementation.

## Preconditions

- Accepted E1; MG-E2 materializes exact commands, causal RED, all-target migration mapping and G-09 audit.
- E1 must retain PV-2 controlled-failure evidence: durable update, failed projection, dropped process/runtime, same-directory reopen non-current, then rebuild recovery. E2 converts this accepted core behavior into real CLI process readback without adding a second composition seam.

## Наблюдаемые сценарии

- Must include normal real CLI, invalid/unavailable behavior, failure process → new-process degraded/stale → rebuild clear, and mock-only target replacement.
- Literal PV-4 process oracle: `fastsearch index update <source> <service> --test-fail-projection` exits non-zero after durable reconciliation and never emits current; a separate ordinary `fastsearch status <source> <service>` is stale/degraded; ordinary `index rebuild` restores current/equality. The flag is accepted only in that exact final position, rejected everywhere else, absent from normal help, and has no environment/config hook.

## Definition of Done

- G-04–G-09 PASS; each preserved DT1 assertion has real/test-only owner; production mock audit empty; candidate master-reviewed.

## Операционная проверка

- Test oracle / команда: not assigned before MG-E2.
- Expected evidence: causal RED/GREEN/REFACTOR/PASS, CLI/process readback, assertion migration map, audit manifest.
- PV-4 RED/GREEN: `tests/cli_real_flow.rs` invokes all real commands above, validates no-flag normal flow and incorrect flag positions; G-09 audit lists all permitted test-only Mock matches and proves zero production matches.
- Unverified areas: production corpus/performance, MCP parity, Linux packaging.

## Условия остановки

- Any runtime document mock is required for acceptance, or all-target migration loses an adapter-neutral assertion without replacement.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки D — Lexical поиск и ranking

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch ID: `D`
- Base revision: exact A integration revision после accepted merge A
- Состояние: `DORMANT OUTLINE до MG-D1`

## Наблюдаемое изменение

- Baseline: accepted A retrieval contract; runtime lexical remains mock.
- После ветки: real lexical projection separates exact/Russian FTS and returns stable explainable BALANCED/CURRENT/DESIGN ordering.

## Целостное состояние ветки

Exact intent has deterministic priority; Russian phrase/no-hit and projection mutation outcomes match A oracle. Mode ranking uses only accepted relevance/lifecycle/normativity/alignment semantics and visible metadata/channel/score. TODO `D2-TANTIVY-SCHEMA-ANALYZER` closes on exact evidence.

## Ownership

- Owner: D.
- Предполагаемая writable area: `src/adapters/lexical/**` and materialized lexical/ranking tests.
- Только чтение: A contracts/corpus, D2 spike evidence.
- Exclusions: manifest/lock, public contracts, source/state/application/CLI, vector channel.

## Зависимости и интеграция

- Materialization gate: MG-D1 after accepted/merged A; exact base/paths/contract/causal RED are recorded then.
- Consumers: E; B/C parallel only with disjoint ownership.
- Integration: Root after B/C and before E.

## Листы

| Leaf ID | Вес задачи | Target outline | Materialization gate |
|---|---:|---|---|
| D1 | 13% | Exact/Russian FTS/no-hit and projection lifecycle | MG-D1 after A |
| D2 | 12% | BALANCED/CURRENT/DESIGN ordering and D2 TODO closure | accepted D1; MG-D2 |

## Definition of Done

- Exact/FTS/mode/lifecycle regression PASS without public/dependency drift; no mock/vector false capability.
- Exact analyzer/schema/tests/commands are chosen only after materialization.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки A — Контракт реального поиска

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch ID: `A`
- Base revision: `23b22c11b5a3aade958a77921a3aa2a78e7dafa0`

## Наблюдаемое изменение

- Baseline: DT1 contract suite и mock runtime PASS, но oracle жёстко принимает только `BackendKind::Mock`; отсутствует contract для observable index lifecycle, а root manifest не содержит production dependencies.
- После ветки: один compile-checked adapter-neutral contract и regression oracle позволяют независимо реализовать real source/state/lexical adapters, не выдавая mock за real и не меняя общий core молча.

## Целостное состояние ветки

DT1 mock/reference tests продолжают проходить с expected backend `Mock`. Тот же oracle способен принять backend `Real`; DT2 corpus фиксирует ожидаемые records, lifecycle и queries. Public record/query/result/error/status и необходимые write/read boundaries выражают только наблюдаемое поведение, достаточное B/C/D/E. Root dependencies и adapter module scaffolds зафиксированы в одном lock baseline; production implementations ещё отсутствуют.

## Ownership

- Разрешено изменять: для A1 — `tests/support/**`, `tests/contract_ports.rs`, `tests/dt2_contract_oracle.rs`, `tests/fixtures/dt2/**`, `tests/golden/dt2/**`; для A2 — exact paths материализуются MG-A2 и могут включать `Cargo.toml`, `Cargo.lock`, `src/domain/**`, `src/ports/**`, adapter module scaffolds и bounded compatibility changes в current mock/application/tests только если A1 доказал необходимость.
- Только чтение: `ROADMAP.md`, DT1 spike evidence/archive; до MG-A2 все product paths A2 read-only.
- Запрещено изменять: production logic B/C/D/E, `.agents/`, `.cfknowledge/`, external source documents и TDR content.

## Зависимости и интеграция

- Preconditions: exact clean baseline `23b22c1`; DT1 G-08 D1–D3 evidence accepted; plan PASS и owner approval.
- Consumers: B, C, D, затем E.
- Producer gate / evidence: G-01–G-05; A1 decision однозначен; MG-A2 назначил exact public/dependency/compatibility ownership; A2 contract/mock-compatibility suite PASS; manifest не содержит production adapter logic.
- Допустимая параллельность: внутри A листья строго A1 → MG-A2 → A2. B/C/D закрыты до merge A.
- Порядок интеграции: первая product branch; Root merge A до создания B/C/D worktrees.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| A1 | 8% | Oracle различает expected backend, DT2 corpus/expected outcomes и boundary decision приняты | causal RED → GREEN; MG-A2 |
| A2 | 12% | Ports/errors/status/dependencies/module scaffolds compile-check consumers и сохраняют DT1 behavior | accepted A1; G-01–G-05 |

Сумма весов листьев равна весу ветки из `Описание задачи.md`.

## Definition of Done

- Все public изменения имеют causal test и одного producer A; mock/reference suite не регрессировала.
- B/C/D могут стартовать от одной revision без shared product writes и без самостоятельных изменений root manifest/public contracts.
- Regression fixtures не копируют implementation и содержат exact ID, Russian phrase, competing CURRENT/DESIGN metadata и add/change/delete cases.

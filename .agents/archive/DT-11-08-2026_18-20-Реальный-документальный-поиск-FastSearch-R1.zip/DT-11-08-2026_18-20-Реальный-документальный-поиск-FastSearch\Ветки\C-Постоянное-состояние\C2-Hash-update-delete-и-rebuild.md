<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист C2 — Hash update delete и rebuild

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch / Leaf ID: `C / C2`
- Вес задачи: `11%`
- Состояние: `MATERIALIZED после C1 integration adf52855fb97b52914b903e5c54f0a964450a499`

## Наблюдаемое изменение

- Baseline: accepted C1 individual persistent state.
- После листа: accepted snapshots deterministically produce add/unchanged/change/delete outcomes and rebuild equal logical state.

## Целевое состояние листа

Outcome identities/counts are sufficient for future E/D composition; failed lifecycle transition preserves an observable recoverable prior state. TODO D3 closes on exact evidence.

## MG-C2 — исполнимый контракт

- Writable only `src/adapters/state/sqlite.rs`, new `tests/c2_sqlite_lifecycle.rs`; no port/dependency/application/lexical changes.
- Persist source-snapshot ledger keyed by full SourceLocator + FileHash, and record ownership. `apply_snapshot` prevalidates duplicate/cross-source IDs, classifies add/unchanged/change/delete by record hash, atomically replaces one source membership/hash and increments durable generation only on logical change. unchanged does not mutate generation.
- Transaction/reopen/trigger failure rolls back records, ledger and generation; lifecycle remains Stale. Test-level rebuild equality compares incremental durable corpus with clean final snapshot application after reopen; lexical rebuild/Current/Degraded remain E/D scope.
- RED/GREEN: `tests/c2_sqlite_lifecycle.rs` covers add→unchanged→change→delete, equality, duplicate pre-mutation failure and rollback; targeted/all locked/fmt/clippy/all-targets.

## Границы состояния

- Owner: C; предполагаемая lifecycle area/tests.
- Exclusions: lexical writes/cross-store policy, public/dependency changes.

## Preconditions

- Accepted C1; MG-C2 materializes exact snapshot/change-set/rebuild oracle and causal RED.

## Наблюдаемые сценарии

- Определяются MG-C2 from accepted A/C1 evidence.

## Definition of Done

- Add/unchanged/change/delete, incremental=rebuild, containment/recovery and D3 TODO closure PASS.

## Операционная проверка

- Test oracle / команда: не назначены до MG-C2.
- Expected evidence: causal RED/GREEN/REFACTOR/PASS, full C regression/master verdict.
- Unverified areas: hard-crash consistency and performance.

## Условия остановки

- Change-set/recovery requires public or cross-store decision outside C ownership.

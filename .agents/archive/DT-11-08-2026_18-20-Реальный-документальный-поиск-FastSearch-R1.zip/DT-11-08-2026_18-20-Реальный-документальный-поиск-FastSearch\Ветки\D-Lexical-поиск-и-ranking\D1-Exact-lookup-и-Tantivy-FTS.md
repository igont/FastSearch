<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист D1 — Exact lookup и Tantivy FTS

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch / Leaf ID: `D / D1`
- Вес задачи: `13%`
- Состояние: `MATERIALIZED после A integration c45d764dfac43f919567066572e44250030cf97e`

## Наблюдаемое изменение

- Baseline: accepted A; production lexical projection absent.
- После листа: accepted exact/technical and Russian phrase queries produce expected candidates/no-hit across projection mutation/reopen/rebuild.

## Целевое состояние листа

Exact and natural-language representations remain distinct per A/D2 evidence; projection is disposable/bounded and reports failed writes honestly. Exact schema/analyzer/writer mechanism is not authority before MG-D1.

## MG-D1 — исполнимый контракт

- Writable: `src/adapters/lexical/mod.rs`, `tests/d1_lexical_projection.rs`; no public/dependency/application/CLI/fixtures/goldens/ranking changes.
- Use locked Tantivy `0.26.1`. Real internal adapter has schema `stable_id STRING|STORED`, exact technical identifier `STRING`, Russian text `TEXT`; exact uses `TermQuery`, quoted phrase uses the text field only. ASCII technical tokens are deterministically derived from canonical facts; no new public field.
- `apply_projection` validates duplicate IDs before write, commits generation then Current. Failure -> `ProjectionFailure`, `Degraded`, prior committed index recoverable; absent/behind -> Stale. Reopen reads index+marker. Rebuild input is authoritative record set. No D2 score/mode ordering.
- RED/GREEN: `tests/d1_lexical_projection.rs`, `cargo test --test d1_lexical_projection --locked`; exact `2433`, Russian phrase/no-hit, reopen, mutation, duplicate degrade and rebuild; then all locked/fmt/clippy/all-targets.

## Границы состояния

- Owner: D; предполагаемая lexical adapter/tests area.
- Exclusions: mode modifiers D2, cross-store composition, public/dependency changes.

## Preconditions

- MG-D1 after accepted A materializes exact contract, causal RED, lifecycle/failure oracle and paths.

## Наблюдаемые сценарии

- Определяются MG-D1 from A regression and D2 spike evidence.

## Definition of Done

- Exact/phrase/no-hit/mutation/reopen/rebuild/containment evidence PASS; D2 may open.

## Операционная проверка

- Test oracle / команда: не назначены до MG-D1.
- Expected evidence: causal RED/GREEN/REFACTOR/PASS, exact candidate.
- Unverified areas: morphology quality and performance.

## Условия остановки

- Accepted contract/dependency cannot express required retrieval/lifecycle/failure behavior.

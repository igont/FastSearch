<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист C1 — SQLite schema и transaction lifecycle

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch / Leaf ID: `C / C1`
- Вес задачи: `9%`
- Состояние: `MATERIALIZED после A integration c45d764dfac43f919567066572e44250030cf97e`

## Наблюдаемое изменение

- Baseline: accepted A; persistent state absent.
- После листа: one record per stable ID round-trips completely across reopen and failed transaction does not claim/leave partial success.

## Целевое состояние листа

SQLite is internal bounded state authority for DT2; exact schema/mapping/transaction mechanism is chosen only after MG-C1 and remains outside public domain.

## MG-C1 — исполнимый контракт

- Writable: `src/adapters/state/mod.rs`, новый `src/adapters/state/sqlite.rs`, `tests/c1_sqlite_state.rs`; no public/dependency/application/CLI changes.
- `SqliteStateStore::open(path)` implements existing `StateStore` on locked `rusqlite =0.40.2 bundled`. Lossless schema persists primary record plus ordered selector components, metadata and relations; idempotent schema init and FK on each connection.
- Each `put/remove` is one transaction and increments durable generation only within committed transaction. Reopen reconstructs full record; same ID atomically replaces children. Duplicate input IDs -> `DuplicateStableId` before mutation; SQL/reconstruction failure -> `StateFailure` and rollback.
- State after open/commit is `Stale` with durable generation and no projection generation, never `Current`; C2 snapshots/rebuild excluded.
- RED/GREEN: `tests/c1_sqlite_state.rs`, `cargo test --test c1_sqlite_state --locked`; prove full reopen, same-ID replacement and trigger-induced rollback/sentinel; then all locked/fmt/clippy/all-targets.

## Границы состояния

- Owner: C; предполагаемая state adapter/tests area.
- Exclusions: snapshot/rebuild logic C2, lexical projection, public/dependency changes.

## Preconditions

- MG-C1 after accepted A materializes exact contract, causal RED, failure/containment oracle and paths.

## Наблюдаемые сценарии

- Определяются MG-C1 from A/D3 evidence.

## Definition of Done

- Complete reopen, uniqueness, rollback and sentinel evidence PASS; C2 may open.

## Операционная проверка

- Test oracle / команда: не назначены до MG-C1.
- Expected evidence: causal RED/GREEN/REFACTOR/PASS, exact candidate.
- Unverified areas: concurrency, schema migrations, OS crash.

## Условия остановки

- Accepted A/dependency boundary cannot express required state/failure/containment behavior.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист A2 — Исполняемые ports и dependency baseline

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch / Leaf ID: `A / A2`
- Вес задачи: `12%`
- Состояние: `MATERIALIZED после accepted A1 f3f8941857b59a7172074341b65df4b13d719edf`

## Наблюдаемое изменение

- Baseline: accepted A1 oracle/corpus и boundary decision.
- После листа: B/C/D могут независимо реализовать real adapters против одного compile-checked public/dependency baseline, сохраняя adapter-neutral DT1 assertions.

## Целевое состояние листа

Public record/query/result/error/status и port boundaries выражают только наблюдаемое поведение, принятое A1. Root manifest/lock и module boundary принадлежат одному writer A. Если A1 доказал несовместимость current mock/application/tests, MG-A2 назначает A exact bounded compatibility paths; иначе эти paths остаются read-only. Production adapter logic отсутствует.

## MG-A2 — исполнимый контракт

- Exact base: `f3f8941857b59a7172074341b65df4b13d719edf`; A1 boundary passport: `tests/golden/dt2/boundary-passport.md`.
- Writable paths: `Cargo.toml`, `Cargo.lock`, `src/domain/{record.rs,search.rs,status.rs,error.rs,mod.rs}`, `src/ports/mod.rs`, `src/adapters/mod.rs`, `src/adapters/source/mod.rs`, `src/adapters/state/mod.rs`, `src/adapters/lexical/mod.rs`, `src/application/mod.rs`, `src/adapters/mock/mod.rs`, `tests/contract_ports.rs`, `tests/runtime_mock_contracts.rs`, `tests/agent_facade_mock_flow.rs`, `tests/a2_public_contract.rs`.
- Dependencies: `tantivy = "=0.26.1"`, `rusqlite = { version = "=0.40.2", features = ["bundled"] }`, `sha2 = "=0.10.9"`. Parser/file-walk crates, `serde` и `tempfile` не добавлять.
- Public surface: ввести валидируемый `FileHash`; существующий `ContentHash` является record hash. `SourceSnapshot { file_hash, records }` разделяет file/record facts. Ввести lifecycle `NotConfigured | Current | Stale | Degraded`, `LifecycleStatus { freshness, state_generation, projection_generation, detail }`; `SearchResponse` несёт freshness. Выразить typed `SourceFailure`, `StateFailure`, `ProjectionFailure`, `DuplicateStableId`.
- Ports: `SourcePort::snapshot`; state read/write boundary возвращает change-set add/unchanged/change/delete и durable generation; lexical read/write boundary принимает projection apply/rebuild и выдаёт lifecycle status. `AgentSurface::index_status` дополняет неизменённый capability `status`. E использует только эти ports, без SQLite/Tantivy handles или cross-store method.
- Compatibility: DT1 `records/get/put/remove/search/status` assertions сохраняются с backend `Mock`. Mock для нового lifecycle API возвращает явный `NotConfigured`, никогда не `Real`/`Current`; текущий CLI и `src/main.rs` неизменны.
- Adapter scaffolds: только declaration modules `source`, `state`, `lexical`, без production logic; эти implementation paths замораживаются для B/C/D после интеграции A.

## Границы состояния

- Owner: A только в exact MG-A2 paths.
- Exclusions: production source/state/lexical/runtime implementation; `src/main.rs`/CLI, vector/maps/symbol/MCP behavior, fixtures/goldens и любые пути вне списка.

## Preconditions

- A1 accepted на exact candidate.
- Root записал MG-A2: runnable contract, causal RED, exact ownership, dependency decisions, mock-compatibility mapping и полный accepted A1 boundary passport по identity/hashes/lifecycle/status/composition/ranking.

## Наблюдаемые сценарии

- Новый `tests/a2_public_contract.rs` сначала RED: current CRUD/status не выражают distinct hashes, change outcomes и stale/degraded response/status.
- GREEN: compile/object-safe ports выражают snapshot, change-set, projection lifecycle, deterministic status/search freshness и typed failures; mocks остаются только `Mock` + `NotConfigured`.
- Итог: `cargo test --test a2_public_contract --locked`, затем `cargo test --locked`, `cargo fmt --check`, `cargo clippy --workspace --all-targets -- -D warnings`, `cargo test --workspace --all-targets --locked`.

## Definition of Done

- A1 contract tests и adapter-neutral DT1 assertions PASS.
- B/C/D ownership можно открыть без shared product writes и самостоятельного изменения public/dependency baseline.
- Точный mock compatibility outcome и migration handoff E зафиксированы.
- Public boundaries однозначно выражают принятые freshness/recovery и CLI-status outcomes; adapter worker не должен изобретать новый public method или cross-store authority.

## Операционная проверка

- Test oracle / причинный RED: `tests/a2_public_contract.rs`; `cargo test --test a2_public_contract --locked`.
- Команды: listed above; обязательный итоговый класс gates — G-01–G-05.
- Evidence: exact A1 decision, materialized A2 contract, causal RED/GREEN, A master verdict.
- Unverified areas: concrete real adapters остаются за B/C/D.

## Условия остановки

- A1 не дал однозначный public/dependency/compatibility contract.
- Требуется product decision или scope дерева 3/4.
- Изменение результата/ownership/DAG/gate требует replan/review до materialization.

## PV-3 A2/R1 — full source reconciliation

- Writable: `src/ports/mod.rs`, `src/adapters/mock/mod.rs`, `tests/a3_full_source_reconciliation_contract.rs`. No domain/dependency/source/state/lexical/application/CLI writes.
- Add object-safe `StateStore::reconcile_snapshots(&[SourceSnapshot]) -> StateChangeSet`. The slice is the complete successful scan; empty means successful empty corpus. It atomically reconciles all source memberships, validates duplicate locators/StableIds before mutation, increments generation once only on aggregate logical change, and preserves `apply_snapshot` compatibility.
- Mock returns typed `StateFailure`, never Current/Real. RED proves dyn StateStore API absence; GREEN proves empty/full call, object safety and mock terminal behavior. C owns durable behavior after accepted A2/R1.

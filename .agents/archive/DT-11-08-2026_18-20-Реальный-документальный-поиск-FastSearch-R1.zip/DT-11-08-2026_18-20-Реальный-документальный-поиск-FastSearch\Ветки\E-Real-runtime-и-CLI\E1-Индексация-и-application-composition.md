<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист E1 — Индексация и application composition

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-2`
- Branch / Leaf ID: `E / E1`
- Вес задачи: `8%`
- Состояние: `DORMANT OUTLINE до MG-E1`

## Наблюдаемое изменение

- Baseline: integrated B/C/D adapters without production coordinator.
- После листа: one core performs accepted rebuild/update and maintains an honest current-or-degraded state across process boundaries.

## Целевое состояние листа

Source → SQLite lifecycle → lexical projection has observable success/failure/recovery. Controlled lexical failure ends the failing invocation; a newly opened application/CLI process on the same service directory sees durable or recomputed degraded/stale state and cannot claim current or serve stale result as current. Bounded rebuild restores equality and clear status. Exact mechanism remains worker discretion.

## PV-2 MG-E1 seam

- E owns a private generic coordinator over existing SourcePort, StateStore and LexicalRetrieval only. It is not a domain/port export and exposes no adapter internals.
- RealRuntime::open remains the only production factory. The coordinator may inject a failing lexical implementation only to prove durable update, failure, drop, same-directory real reopen non-current and rebuild recovery.

## Границы состояния

- Owner: E; exact composition/recovery/tests paths materialized by MG-E1.
- Exclusions: CLI polish/mock removal E2, public/dependency changes, hard-crash guarantee, прямой доступ к внутренним SQLite schema/transactions C или Tantivy schema/index/writer D.

## Preconditions

- Integrated accepted A+B+C+D; MG-E1 fixes exact base, causal RED, paths, migration/recovery oracle.

## Наблюдаемые сценарии

- Materialized MG-E1 must include normal flow and failure invocation → process exit → new-process reopen degraded/stale → rebuild equality/clear status.

## Definition of Done

- Cross-adapter lifecycle/readback, containment and cross-process recovery evidence PASS; E2 may open.

## Операционная проверка

- Test oracle / команда: not assigned before MG-E1.
- Expected evidence: causal RED/GREEN/REFACTOR/PASS, process-boundary status/search readback, exact candidate.
- Unverified areas: OS hard crash, concurrency, performance.

## Условия остановки

- Accepted adapters cannot expose honest reopen status/recovery without public/dependency drift.
- Composition требует нового public method, отдельной cross-store authority или обхода accepted A ports; это backflow в A и material replan, а не локальная свобода E.

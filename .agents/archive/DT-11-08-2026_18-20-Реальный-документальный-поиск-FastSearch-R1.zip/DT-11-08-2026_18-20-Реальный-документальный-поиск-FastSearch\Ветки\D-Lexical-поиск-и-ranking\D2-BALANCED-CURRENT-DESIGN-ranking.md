<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист D2 — BALANCED CURRENT DESIGN ranking

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch / Leaf ID: `D / D2`
- Вес задачи: `12%`
- Состояние: `MATERIALIZED после D1 integration 1925dfcef1910578e6af5f782736627b309c8a9e`

## Наблюдаемое изменение

- Baseline: accepted D1 candidate ordering without accepted mode modifiers.
- После листа: same relevant candidates produce expected mode-specific ordering while exact priority remains invariant.

## Целевое состояние листа

Ranking is bounded/explainable by accepted relevance/lifecycle/normativity/alignment semantics; raw metadata stays visible; равный итоговый score разрешается accepted A1 deterministic tie-break, а не iteration/index insertion order; no new mode, ontology, rule engine, vector fusion or architectural conflict resolution.

## MG-D2 — исполнимый контракт

- Writable only `src/adapters/lexical/mod.rs`, new `tests/d2_ranking_modes.rs`; exact path, public/dependencies/application/CLI and D1 test stay unchanged.
- Ranking only lexical phrase candidates. Exact remains Exact and dominant. Balanced uses finite relevance then StableId ascending; Current gives recognized raw `alignment=CURRENT` and `lifecycle=current` positive precedence; Design gives raw `alignment=DESIGN` positive precedence. `normativity` lacks accepted corpus vocabulary and is explicitly neutral/unknown. Missing/unknown metadata is neutral; final tie is StableId ascending.
- No quantitative public scoring contract, ontology or rule engine: deterministic ordinal metadata preference precedes finite Tantivy relevance only for recognized values.
- RED/GREEN: `tests/d2_ranking_modes.rs` competing `a-design`/`z-current` phrase shows D1 lexical order fails Current; verify Balanced/Current/Design and exact invariant, then targeted/all locked/fmt/clippy/all-targets.

## Границы состояния

- Owner: D; предполагаемая ranking area/tests.
- Exclusions: public/dependency changes and semantic vector behavior.

## Preconditions

- Accepted D1; MG-D2 materializes exact competing-record oracle, causal RED and paths.

## Наблюдаемые сценарии

- Определяются MG-D2 from accepted A/D1 evidence.

## Definition of Done

- Mode ordering, exact dominance, finite/stable score, no-hit and D2 TODO closure evidence PASS.

## Операционная проверка

- Test oracle / команда: не назначены до MG-D2.
- Expected evidence: causal RED/GREEN/REFACTOR/PASS, full D regression/master verdict.
- Unverified areas: quality outside bounded corpus and vector fusion.

## Условия остановки

- Authority conflict or required public contract drift; new mode/rule engine is out of scope.

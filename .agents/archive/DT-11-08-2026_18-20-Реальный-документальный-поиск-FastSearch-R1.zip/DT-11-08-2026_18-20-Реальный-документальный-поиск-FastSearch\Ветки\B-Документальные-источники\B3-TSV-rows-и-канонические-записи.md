<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист B3 — TSV rows и канонические записи

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch / Leaf ID: `B / B3`
- Вес задачи: `6%`
- Состояние: `MATERIALIZED после B2 integration f73b996d9cfc83a41e3b08d0a75db8ea62fd221e`

## Наблюдаемое изменение

- Baseline: accepted B2 Markdown source path.
- После листа: each accepted meaningful TSV row is one deterministic canonical record and combined SourcePort matches A manifest.

## Целевое состояние листа

Row identity, one-based locator, metadata/searchable representation and hash follow accepted A oracle; no file-level TSV chunk or silent duplicate overwrite. TODO `D1-ADAPTER-NORMALIZATION` closes on exact evidence.

## MG-B3 — исполнимый контракт

- Writable only `src/adapters/source/mod.rs` and its module tests. No public/dependency/state/lexical/application/CLI/fixture writes.
- TSV UTF-8: header row plus nonblank data rows; row locator is physical one-based (first data row 2), StableId `registry:<repo-relative-path>#row=<N>`, title first cell, searchable normalized raw row, metadata `format=tsv` and unique nonblank header→cell mapping after title, no relations. Malformed header/arity/title/UTF-8 -> all-or-nothing `SourceFailure`.
- File/record hash follows B2 `sha256:v1` normalized fixed facts. `FilesystemSource { root }` implements current SourcePort by one scan and deterministic combined Markdown/TSV snapshots/records; duplicate cross-snapshot ID -> `DuplicateStableId`.
- RED/GREEN: missing `FilesystemSource` test covering `registry:registry.tsv#row=2`, TSV row/hash/failure tests and B1/B2 regression; targeted/module/all locked/fmt/clippy/all-targets.

## Границы состояния

- Owner: B; предполагаемая TSV/composition area/tests inside source ownership.
- Exclusions: public/dependency changes, storage/retrieval/runtime.

## Preconditions

- Accepted B2; MG-B3 materializes exact TSV/failure contract, causal RED and paths.

## Наблюдаемые сценарии

- Определяются MG-B3 from accepted A/B2 evidence.

## Definition of Done

- Combined Markdown+TSV expected set, determinism, collision policy and D1 TODO closure PASS.

## Операционная проверка

- Test oracle / команда: не назначены до MG-B3.
- Expected evidence: causal RED/GREEN/REFACTOR/PASS, full B regression, exact candidate/master verdict.
- Unverified areas: registry dialects outside accepted contract.

## Условия остановки

- Row identity/failure semantics require public drift or dependency change.

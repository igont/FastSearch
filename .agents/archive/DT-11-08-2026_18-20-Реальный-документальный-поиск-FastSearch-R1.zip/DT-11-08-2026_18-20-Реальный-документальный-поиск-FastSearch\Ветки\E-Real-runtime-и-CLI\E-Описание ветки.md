<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки E — Real runtime и CLI

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-4`
- Branch ID: `E`
- Base revision: exact integration revision after accepted merges A → B → C → D and Root cross-adapter closure
- Состояние: `DORMANT OUTLINE до MG-E1`

## Наблюдаемое изменение

- Baseline: B/C/D real adapters accepted separately; production executable still mock-only.
- После ветки: one production core drives real init/index/search/get/status CLI, survives controlled cross-process projection failure honestly and contains no runtime document mocks.

## Целостное состояние ветки

Real source/state/lexical adapters are composed once. Incremental/rebuild results are read back through CLI; a failed projection invocation followed by a new process on the same state must expose degraded/stale, never false-current, until bounded rebuild restores equality. Source/State/Lexical are `Real`; Vector/CodeMaps/Symbols are `Unavailable`.

Adapter-neutral DT1 assertions/goldens remain as oracle. Existing mock-only executable/runtime targets (`tests/cli_mock_flow.rs`, `tests/runtime_mock_contracts.rs`, `tests/agent_facade_mock_flow.rs` and direct production mock imports) are owned by E for explicit migration/replacement only after MG-E1/E2. Test-only reference doubles may remain with audit classification; production MockRuntime/MockFacade/adapters registration and `mock-search` do not.

## Ownership

- Owner: E.
- Предполагаемая writable area after materialization: `src/application/**`, `src/main.rs`, final composition portions of `src/lib.rs`/`src/adapters/mod.rs`, `src/adapters/mock/**`, existing mock-only tests named above, their direct support/goldens, and materialized real runtime/CLI tests.
- Только чтение: accepted A contracts/dependencies and B/C/D implementations/fixtures.
- Exclusions: root dependency/public changes, vector/maps/symbol/MCP implementation, user corpus.

## Зависимости и интеграция

- Materialization gate: MG-E1 only after integrated A+B+C+D and G-01–G-07; exact base, writable paths, mock-test migration map, causal RED and reopen recovery oracle are fixed then.
- Consumer: Root final G-01–G-10 and DT3 passport.
- Parallel product work: none.

## Листы

| Leaf ID | Вес задачи | Target outline | Materialization gate |
|---|---:|---|---|
| E1 | 8% | One core index composition plus durable/recomputed degraded status across new-process reopen and rebuild recovery | MG-E1 after A+B+C+D |
| E2 | 7% | Real CLI/regression; mock-only test migration; complete production mock audit | accepted E1; MG-E2 |

## Definition of Done

- Real CLI lifecycle/exact/FTS/modes/status PASS, including failing invocation → new-process degraded/stale → rebuild equality/clear status.
- G-04 all-targets PASS under explicit mock-test migration mapping; adapter-neutral DT1 assertion inventory retained.
- G-09 finds no production mock composition/registration/command and classifies every permitted test-only match.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки B — Документальные источники

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch ID: `B`
- Base revision: exact A integration revision после accepted merge A
- Состояние: `DORMANT OUTLINE до MG-B1`

## Наблюдаемое изменение

- Baseline: accepted A contract/corpus; runtime source остаётся mock.
- После ветки: real SourcePort детерминированно возвращает ожидаемые Markdown-section и TSV-row records только из разрешённых UTF-8 sources.

## Целостное состояние ветки

Filesystem exclusions, Markdown/frontmatter/section parsing и TSV row normalization соответствуют accepted A oracle. Source authority остаётся read-only; stable ID, locator, metadata, relations и hash воспроизводимы; TODO `D1-ADAPTER-NORMALIZATION` закрыт evidence.

## Ownership

- Owner: B.
- Предполагаемая writable area: `src/adapters/source/**` и materialized source tests.
- Только чтение: A contracts/corpus, D1 evidence, roadmap.
- Exclusions: root manifest/lock, domain/ports, state/lexical/application/CLI, external TDR corpus.

## Зависимости и интеграция

- Materialization gate: `MG-B1` после accepted/merged A; Root фиксирует exact A base, runnable source contract, causal RED и exact paths.
- Consumers: E.
- Параллельность: C/D только при подтверждённом disjoint ownership.
- Интеграция: Root merge B первым после A.

## Листы

| Leaf ID | Вес задачи | Target outline | Materialization gate |
|---|---:|---|---|
| B1 | 5% | Разрешённый стабильный filesystem input без выхода за root | MG-B1 после A |
| B2 | 9% | Expected Markdown/frontmatter/section records | accepted B1; MG-B2 |
| B3 | 6% | Expected TSV-row и combined source records; D1 TODO closure | accepted B2; MG-B3 |

## Definition of Done

- Accepted A corpus даёт exact expected record set, exclusions отсутствуют, повторный прогон стабилен.
- Invalid/unsupported input следует materialized structured failure policy, а public/dependency contract не меняется молча.
- Exact tests/commands и dependency usage назначаются только при последовательных materialization gates.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Вердикт мастер-ревьюера ветки E

Файл append-only изменяет только мастер-ревьюер.

## Итерация [N]

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Scope: `[leaf или branch]`
- Candidate revision: `[hash]`
- Previous revision: `[hash или n/a]`
- Recheck scope: `[изменённая область или n/a]`
- Verdict: `[PASS | REWORK | BLOCKED | ESCALATION_REQUIRED]`
- Specialist reviews used: `[роли и verdict; или нет]`
- Evidence states: `[SCOPED PASS | BROAD BASELINE FAIL | PRODUCTION UNVERIFIED | PRODUCTION FAIL; или нет]`

### Blocking findings

- [Finding или нет.]

### Non-blocking findings

- [Finding или нет.]

### Проверено

- [Проверка и evidence.]

### Переиспользовано без повторной проверки

- [Проверка и основание или нет.]

### Не проверено и residual risk

- [Область или нет.]

## Итерация 1

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-2`
- Scope: `E1 — src/application/mod.rs, src/application/real.rs, tests/e1_real_runtime_recovery.rs`
- Candidate revision: `ab15cee31c8cfd28b81ac4f77046627d5af362cf`
- Previous revision: `313c01027443965d03d9a6d350d8a097c788ce0a`
- Recheck scope: `n/a`
- Verdict: `ESCALATION_REQUIRED`
- Specialist reviews used: `нет; полный master review по фактическому runtime/storage boundary`
- Evidence states: `SCOPED PASS для format/clippy/положительного reopen и controlled projection failure; PRODUCTION FAIL для полного lifecycle delete`

### Blocking findings

- `E1-B1 / HIGH — full-source refresh не удаляет durable запись отсутствующего source.` `IndexCoordinator::apply_source_snapshots` собирает только текущие `SourceSnapshot`, затем вызывает `StateStore::apply_snapshot` только для них. Когда целый файл исчез, его `source_key` не попадает в вызов: Tantivy получает пустой набор и search становится пустым, но SQLite сохраняет прежний `CanonicalRecord`, поэтому `AgentSurface::get` возвращает удалённый документ. Независимый controlled regression на exact candidate: initial refresh/find → удалить `guide.md` → refresh → `search` пуст, но `get(initial_id) == Some`; `cargo test --test e1_review_source_deletion` завершился FAIL. Это нарушает E1 «Source → SQLite lifecycle → lexical projection», общий `index update` add/unchanged/change/delete и правило единого владельца durable state.
- Исправление не является локальной свободой E1: в `StateStore` нет операции reconcile полного source-set/удаления отсутствующих snapshots, а E1 seam допускает только private generic coordinator над current `SourcePort`, `StateStore`, `LexicalRetrieval`. Durable manifest source→IDs в service directory создал бы прямо запрещённую листом отдельную cross-store authority; direct SQLite access обходил бы accepted port. Нужен Root material replan/backflow в C/A с одним ownership/transition contract для full-source reconciliation, после чего E1 получает новую exact boundary.

### Non-blocking findings

- Нет.

### Проверено

- Exact identity/base: `HEAD == ab15cee31c8cfd28b81ac4f77046627d5af362cf`; merge-base candidate/base равен `313c01027443965d03d9a6d350d8a097c788ce0a`; diff ограничен тремя заявленными путями.
- Причинный положительный/controlled-failure контракт: normal real same-directory reopen и injected lexical failure → drop → real reopen degraded → rebuild current покрыты тестами `e1_real_runtime_recovery` и `application::real::tests::failed_projection_is_durable_across_real_same_directory_reopen_until_rebuild`.
- `cargo fmt --check` PASS.
- `cargo clippy --all-targets -- -D warnings` PASS.
- `cargo test --test e1_real_runtime_recovery` PASS.
- `cargo test --workspace --no-fail-fast` PASS: 41 tests, 0 failures.
- Отдельный reviewer regression в detached worktree exact candidate обнаружил E1-B1; он не менял candidate.

### Переиспользовано без повторной проверки

- Нет.

### Не проверено и residual risk

- Hard OS crash, concurrency и performance исключены листом; не повышались до PASS.
- E2 CLI/migration mock-аудит не входит в E1 и остаётся закрытым до принятого E1.

## Итерация 2

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-2`; проверен E1 после принятого PV-3 contract `StateStore::reconcile_snapshots`.
- Scope: `E1 — src/application/mod.rs, tests/e1_real_runtime.rs`
- Candidate revision: `daeec9ae2c4944fe89ce1459fc46a18672d7e919`
- Previous revision: `ab15cee31c8cfd28b81ac4f77046627d5af362cf`
- Recheck scope: `полный source-scan reconciliation, real composition, controlled failure/reopen/rebuild и удалённый source`
- Verdict: `PASS`
- Specialist reviews used: `нет; независимый полный master review по application/runtime/storage boundary`
- Evidence states: `SCOPED PASS для E1; PRODUCTION UNVERIFIED только для явно исключённых hard crash, concurrency и performance`

### Blocking findings

- Нет.

### Non-blocking findings

- Нет.

### Проверено

- Exact identity и ancestry: `HEAD == daeec9ae2c4944fe89ce1459fc46a18672d7e919`; `merge-base(6b214313432df5f7558ffbc132bc4f97e2356d57, candidate) == 6b214313432df5f7558ffbc132bc4f97e2356d57`; diff ограничен `src/application/mod.rs` и `tests/e1_real_runtime.rs`. `git diff --check` PASS. E2-owned `src/main.rs` и три mock-only test path не изменены.
- Causal RED: в exact base отсутствует `RealRuntime`, тогда как materialized test импортирует `application::RealRuntime`; следовательно его запуск на base воспроизводит заявленный `E0432 unresolved import`. Exact candidate materializes тот же наблюдаемый real-runtime contract.
- Private `RuntimeCoordinator<S, T, L>` использует только `SourcePort`, `StateStore`, `LexicalRetrieval`; он не экспортируется, не открывает adapter internals и выполняет ровно один `StateStore::reconcile_snapshots(&snapshots)` на успешный полный source scan до projection.
- `cargo test application::real_runtime_recovery_tests::failed_projection_is_degraded_then_reopen_is_stale_until_rebuild` PASS: controlled lexical failure возвращает typed failure, state reconciled один раз, deleted source отсутствует в reopened SQLite state, real same-directory reopen имеет `Stale`, bounded rebuild возвращает `Current` и пустой result.
- `cargo test --test e1_real_runtime` PASS: real update после удаления source очищает durable `get` и lexical search, real reopen остаётся `Current`, rebuild сохраняет equality.
- Broad gates на exact candidate: `cargo fmt --check` PASS; `cargo clippy --all-targets -- -D warnings` PASS; `cargo test --workspace --no-fail-fast` PASS (все 40 тестов); `git diff --check` PASS.

### Переиспользовано без повторной проверки

- Нет: после исходного E1-B1 повторно проверены reconciliation/reopen paths и полный relevant workspace gate.

### Не проверено и residual risk

- Hard OS crash, concurrent writers/readers и performance не входят в E1; доказательств для них нет.
- E2 CLI, удаление production mocks и их migration/audit намеренно не проверялись: кандидат не затрагивает эти пути, и лист E2 закрыт до принятия E1.

## Итерация 3

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-4`
- Scope: `E2 — real CLI, process recovery, migration mock-only tests и G-09 production mock audit`
- Candidate revision: `d304661642365c44886334d5b188e4a7b7c81425`
- Previous revision: `daeec9ae2c4944fe89ce1459fc46a18672d7e919`
- Recheck scope: `n/a; первый review E2 на exact candidate`
- Verdict: `PASS`
- Specialist reviews used: `нет; независимый полный master review по CLI/process/durable-state boundary и migration audit`
- Evidence states: `SCOPED PASS для E2 и G-04/G-09; PRODUCTION UNVERIFIED только для исключённых corpus/performance, MCP parity и Linux packaging`

### Blocking findings

- Нет.

### Non-blocking findings

- Нет.

### Проверено

- Exact identity/ancestry/cleanliness: `HEAD == d304661642365c44886334d5b188e4a7b7c81425`; branch `real-document-search-fastsearch/E/cli`; `merge-base(8faca0b859a22e756d632c2adbb83f4f8946a603, candidate) == 8faca0b859a22e756d632c2adbb83f4f8946a603`; worker worktree clean. Diff ограничен E-owned application/main/adapters mock/test/evidence paths.
- Causal RED/GREEN: supplied RED `cargo test --test cli_real_flow --locked` against mock-only baseline; независимое чтение exact base подтверждает, что executable принимает только `mock-search` через `MockFacade`, поэтому real lifecycle contract отсутствует. На candidate `cargo test --test cli_real_flow --locked` PASS (2/2): real `init`, `index update`, all modes `search`, `get`, `status`; durable reconciliation затем literal final-only `--test-fail-projection` возвращает non-zero без `Current`; новый process видит `Stale|Degraded`; ordinary rebuild возвращает `Current`.
- Literal fault boundary: normal usage не содержит flag; все проверенные не-final/другие positions дают exit `2`; implementation принимает flag только exact `[index, update, source, service, --test-fail-projection]`, без environment/config hook или второго runtime factory.
- G-09: `cargo test --test production_mock_audit --locked` PASS (1/1). Независимый `rg` по `src/**` не нашёл `MockSource`, `MockState`, `MockLexical`, `MockRuntime`, `MockFacade`, `MockSymbols`, `adapters::mock` или `mock-search`. Все оставшиеся `BackendKind::Mock`/`ReferenceFixture` находятся в явно разрешённых `tests/support/**`, `tests/golden_mock_flow.rs`, `tests/dt2_contract_oracle.rs`, `tests/contract_ports.rs` и `src/contract_tests.rs` под `#[cfg(test)]`; migration map покрывает удалённые mock-only targets и их real/test-only owners.
- G-04 и quality gates on exact candidate: `cargo test --all-targets --locked --no-fail-fast` PASS (37 tests, 0 failures); `cargo fmt --check` PASS; `cargo clippy --all-targets --locked -- -D warnings` PASS; `git diff --check base candidate` PASS.
- Code graph rebuilt for exact worktree (`37 files`, `434 nodes`, `3295 edges`) and used for changed CLI/composition blast-radius review; direct source and executable-process tests remain authoritative evidence.

### Переиспользовано без повторной проверки

- Accepted E1 durable reconciliation/reopen ownership: E2 composes it once through `RealRuntime` and repeats the externally observable process recovery path; implementation of accepted state/lexical adapters не менялась.

### Не проверено и residual risk

- Production corpus/performance, MCP parity and Linux packaging исключены E2. Hard OS crash and concurrent writers/readers также не доказаны этим CLI leaf.

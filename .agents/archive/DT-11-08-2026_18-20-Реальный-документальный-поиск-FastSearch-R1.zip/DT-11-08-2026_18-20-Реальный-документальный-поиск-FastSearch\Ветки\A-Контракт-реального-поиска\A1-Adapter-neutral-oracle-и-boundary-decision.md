<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист A1 — Adapter-neutral oracle и boundary decision

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch / Leaf ID: `A / A1`
- Вес задачи: `8%`

## Наблюдаемое изменение

- Baseline: exact DT1 merge `23b22c1`; 13 tests PASS; `assert_contract_oracle` жёстко проверяет `BackendKind::Mock`; corpus состоит только из single-record mock fixture.
- После листа: contract oracle принимает явное expected backend и один DT2 regression corpus задаёт наблюдаемые outcomes real document flow, не реализуя adapters.

## Целевое состояние листа

Test-support больше не смешивает доступность capability с типом backend: mock fixture принимается только как `Mock`, production fixture сможет приниматься только как `Real`. Versioned corpus содержит разрешённые/исключённые Markdown и TSV sources, deterministic expected records, lifecycle mutations и regression queries для exact, Russian FTS и mode ordering. Boundary decision перечисляет только необходимые наблюдаемые изменения current ports/errors/status и точный runnable contract A2, включая полный boundary passport из корневого плана.

## Границы состояния

- В scope: `tests/support/**`, `tests/dt2_contract_oracle.rs`, `tests/fixtures/dt2/**`, `tests/golden/dt2/**`; read-only анализ public contracts и spike evidence.
- Сохраняется: DT1 golden flow, structured unavailable errors, `CanonicalRecord` invariants и отсутствие production capability claims.

## Preconditions

- Plan PASS и owner approval; clean exact baseline `23b22c1`.

## Наблюдаемые сценарии

- Один mock reference fixture проходит oracle с expected `Mock`; тот же status при expected `Real` отвергается.
- Corpus описывает два конкурирующих Markdown records с разным alignment/lifecycle, одну technical exact ID, русскую фразу, TSV row, excluded files и sequence add/unchanged/change/delete.
- Boundary readback классифицирует каждый gap как test-only, adapter-only либо public contract; только public gap открывает A2 изменение.
- Identity/hash readback фиксирует точную формулу stable ID/locator, multi-record и rename/delete/duplicate outcomes, а также раздельные file hash и record hash со scope/normalization/parser-version semantics.
- Lifecycle readback одним протоколом определяет `current`, `stale`, `degraded`, SQLite acceptance, Tantivy generation/failure и наблюдаемые outcomes `search/status/update/rebuild` после нового process reopen.
- Contract readback не допускает leakage Tantivy analyzer/ranking в `CanonicalRecord`, прямого E-доступа к внутренним C/D API или недетерминированного ranking tie-break.

## Definition of Done

- Oracle больше не содержит скрытого требования `Mock` для всех доступных backends.
- Каждое обязательное outcome DT2 имеет fixture/query/expected result и назначенного downstream owner B/C/D/E.
- A2 получает exact список contract tests, owned paths, dependency/module baseline и заполненный boundary passport; нерешённый identity/hash/lifecycle/status/composition/ranking decision отсутствует.
- Final equal-score tie-break задан детерминированно, проверяется competing-record oracle и не зависит от traversal/index insertion order.
- Любой необходимый новый public method или cross-store authority классифицирован как A backflow/material replan, а не как adapter-only correction.

## Операционная проверка

- Test oracle / причинный RED: новый `dt2_contract_oracle` задаёт expected `Real` для current mock status и до изменения helper падает потому, что oracle принимает только `Mock`; corpus completeness test сначала падает на отсутствующих expected cases.
- Команда или процедура: `cargo test --test dt2_contract_oracle --locked`; затем G-02–G-04.
- Окружение и prerequisites: Rust stable, versioned UTF-8 fixtures; сеть и production index не нужны.
- Ожидаемый GREEN / PASS: explicit backend mismatch обнаруживается; expected `Mock` проходит; corpus completeness перечисляет source/lifecycle/search/mode outcomes; все DT1 tests PASS.
- Evidence: test output, exact candidate diff, append-only A process/master verdict; boundary decision фиксируется в A1 acceptance record и A2 materialization handoff.
- Unverified areas: production parsing/storage/indexing остаются ожидаемо `PRODUCTION UNVERIFIED`.

## Условия остановки

- Невозможно определить stable identity, file/record hash boundary, lifecycle write boundary, search-on-stale behavior или status semantics без нового owner decision.
- Corpus требует source kind/vector/symbol/MCP behavior вне DT2 либо противоречит roadmap.
- Обнаружено public contract изменение, не укладывающееся в A ownership/DAG; Root выполняет material replan до A2.

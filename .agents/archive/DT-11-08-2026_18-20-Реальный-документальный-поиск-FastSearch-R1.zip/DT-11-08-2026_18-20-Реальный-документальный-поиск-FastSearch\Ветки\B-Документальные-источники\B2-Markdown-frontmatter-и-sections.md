<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист B2 — Markdown frontmatter и sections

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch / Leaf ID: `B / B2`
- Вес задачи: `9%`
- Состояние: `MATERIALIZED после B1 integration 487b102649119d8c4a2fd63735ca98b2e5be6893`

## Наблюдаемое изменение

- Baseline: accepted B1 file input.
- После листа: accepted Markdown fixtures produce exact canonical section records.

## Целевое состояние листа

Meaningful sections, heading locators, accepted frontmatter/raw metadata, relations, identity and hashes match A oracle without arbitrary character windows or silent partial success.

## MG-B2 — исполнимый контракт

- Writable only `src/adapters/source/mod.rs` and in-module tests. B2 consumes B1 private scanner and removes its transition-only dead-code allowance; no fixture/domain/port/dependency/TSV change.
- Parse only first-file `---` frontmatter with UTF-8 scalar `key: value`; blank/comment lines ignored, duplicate/malformed/non-scalar key or unterminated block -> all-or-nothing `SourceFailure`. `relations` is comma-separated normalized StableIds; other keys remain raw metadata.
- Produce one record only per non-empty heading section with own body (no parent record containing descendants). Normalized heading path is slash joined trimmed headings. Stable ID is `markdown:<repo-relative-path>#<heading-path>`; title is final heading; content is direct body normalized LF/trimmed. File and record hashes are `sha256:v1:<hex>` over passport-normalized facts in fixed field order.
- RED/GREEN: `markdown_parser_returns_expected_section_records_with_frontmatter_metadata_and_heading_locators`, invalid input all-or-nothing, B1 regression; targeted/module/all locked/fmt/clippy/all-targets.

## Границы состояния

- Owner: B; предполагаемая Markdown area/tests inside source ownership.
- Exclusions: TSV behavior, public contract/dependency choice, real user corpus.

## Preconditions

- Accepted B1; MG-B2 materializes exact parser contract, fixtures, causal RED and paths.

## Наблюдаемые сценарии

- Определяются MG-B2 from accepted A/B1 evidence.

## Definition of Done

- Expected record manifest and materialized invalid-input policy PASS; B3 may open.

## Операционная проверка

- Test oracle / команда: не назначены до MG-B2.
- Expected evidence: causal RED/GREEN/REFACTOR/PASS, B1 regression, exact candidate.
- Unverified areas: Markdown dialects outside corpus.

## Условия остановки

- Identity/locator/metadata requires public drift or owner decision.

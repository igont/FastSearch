<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки C — Постоянное состояние

- Task ID: `FASTSEARCH-DT2`
- Plan version: `PV-1`
- Branch ID: `C`
- Base revision: exact A integration revision после accepted merge A
- Состояние: `DORMANT OUTLINE до MG-C1`

## Наблюдаемое изменение

- Baseline: accepted A lifecycle contract; state остаётся in-memory mock.
- После ветки: real SQLite state persists records/hashes and yields repeatable add/unchanged/change/delete/rebuild outcomes.

## Целостное состояние ветки

Stable identity uniqueness, complete record reopen, transaction failure and incremental/rebuild equality match accepted A/D3 evidence. Derived state is bounded/disposable; TODO `D3-SQLITE-LIFECYCLE-TRANSACTION-CLEANUP` closes on exact tests.

## Ownership

- Owner: C.
- Предполагаемая writable area: `src/adapters/state/**` and materialized state/lifecycle tests.
- Только чтение: A contracts/corpus, D3 evidence.
- Exclusions: manifest/lock, public contracts, source/lexical/application/CLI and arbitrary filesystem.

## Зависимости и интеграция

- Materialization gate: MG-C1 after accepted/merged A; exact base/paths/contract/causal RED are recorded then.
- Consumers: E; B/D parallel only with disjoint ownership.
- Integration: Root after B and before D/E.

## Листы

| Leaf ID | Вес задачи | Target outline | Materialization gate |
|---|---:|---|---|
| C1 | 9% | Unique complete SQLite reopen and transaction failure behavior | MG-C1 after A |
| C2 | 11% | Add/unchanged/change/delete/rebuild equality and D3 TODO closure | accepted C1; MG-C2 |

## Definition of Done

- Accepted A lifecycle outcomes, containment and recovery evidence PASS without public/dependency drift.
- Exact schema/API/tests/commands are worker discretion only after materialization.

<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист B3 — DT2 compatibility runtime

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-1`
- Branch / Leaf ID: `B / B3`
- Вес задачи: `8%`

## Наблюдаемое изменение

- Baseline: public `RealRuntime` и generic `RuntimeCoordinator` живут в application root рядом с production exports и частично повторяют lifecycle flow.
- После листа: DT2 document-only contour явно изолирован как compatibility owner и повторно использует допустимую B2 orchestration policy без изменения public path/commands.

## Целевое состояние листа

Application root экспортирует прежний `RealRuntime`, но implementation и test-only projection-failure hook находятся в compatibility module. Удаление legacy contour не выполняется. Общий internal coordinator допускается только если он не расширяет ports и выражает различия production/document-only явно.

## Границы состояния

- В scope: `src/application/mod.rs`, compatibility modules, `tests/e1_real_runtime.rs`, DT2 paths в CLI tests только для verification.
- Сохраняется: `fastsearch init/index/search/get/status <source> <service>`, `RealRuntime` public API, test fault isolation и stale/degraded recovery.

## Preconditions

- B2 accepted; A1 DT2 compatibility matrix immutable.

## Наблюдаемые сценарии

- Legacy document-only index/search/get/status remain accepted and unadvertised as production surface.
- Controlled projection failure, process reopen stale state и rebuild recovery remain observable.

## Definition of Done

- Compatibility ownership visible from modules/docs; no public removals; legacy focused tests and full suite PASS.

## Операционная проверка

- Test oracle / причинный RED: architecture assertion требует compatibility module ownership, сохраняя imports/CLI outcomes; RED на B2 base.
- Команда или процедура: `cargo test --locked --test e1_real_runtime --test cli_real_flow --test dt2_contract_oracle`; `RF-G04`, `RF-G07` compatibility rows.
- Окружение и prerequisites: ordinary Windows contour.
- Ожидаемый GREEN / PASS: structural assertion GREEN; byte/semantic legacy outputs unchanged.
- Evidence: B3 leaf summary + B master verdict.
- RED gate: на exact accepted B2 candidate выполнить compatibility-ownership assertion; causal RED при GREEN legacy/recovery controls.
- Minimal GREEN gate: exact first compatibility-module candidate делает assertion GREEN и проходит listed B3 tests без public import/command change.
- REFACTOR gate: exact next candidate removes duplicated lifecycle/temporary re-export beyond required public compatibility, затем `RF-G12` и повтор B3 tests.
- Leaf/branch-final verification: exact B3 candidate сначала проходит `RF-G13L`; затем тот же descendant candidate со всеми accepted B1–B3 проходит `RF-G00`, `RF-G04..G07`, `RF-G13B` и B master review.
- Unverified areas: удаление/deprecation legacy contour вне scope.

## Условия остановки

- Public import/command must change, compatibility cannot reuse coordinator without semantic drift, or current fault recovery becomes inaccessible.

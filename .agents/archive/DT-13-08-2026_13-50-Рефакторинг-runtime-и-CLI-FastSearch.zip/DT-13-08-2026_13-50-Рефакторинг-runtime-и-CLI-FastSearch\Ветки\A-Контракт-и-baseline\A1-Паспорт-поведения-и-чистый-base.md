<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист A1 — Паспорт поведения и чистый base

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-1`
- Branch / Leaf ID: `A / A1`
- Вес задачи: `15%`

## Наблюдаемое изменение

- Baseline: clean exact `b083eae73a8963df2612abd3cf44b095f6d8e4f2`; содержимое подтверждено audit-run, но refactor invariants рассеяны по README/roadmap/code/tests.
- После листа: один clean exact base и один versioned passport с executable characterization и structural RED controls приняты как authority для всех refactor-листьев.

## Целевое состояние листа

`evidence/refactor/boundary-passport.md` фиксирует наблюдаемые входы/выходы, exclusions и процедуры проверки существующими tests/goldens/smokes. Для B/C/D перечислены будущие boundary tests/assertions и exact lifecycle `RED → minimal GREEN → REFACTOR → final`, но A1 не добавляет их в test suite и не меняет product/test code.

## Границы состояния

- В scope: exact-base readback, public contract inventory, существующие characterization fixtures/goldens, будущие structural oracle specifications и per-leaf gate materialization.
- Сохраняется: все product-файлы и текущее поведение; A1 не выполняет refactor и не меняет dependency/storage/runtime.

## Preconditions

- Root подтвердил clean exact base и что пользовательские dirty changes не потеряны и не смешаны с refactor.
- DT3 archive/handoff читаются; `RF-G00..G04` PASS на base.

## Наблюдаемые сценарии

- Direct technical, `--json` и chat вызывают одну production semantics и сохраняют ordering/status/errors/exit codes.
- Reopen/rebuild, unavailable E5, junction/reparse/bootstrap race и DT2 compatibility остаются наблюдаемыми отдельными scenarios; cache-gated claims маркируются отдельно.
- Для B2 паспорт фиксирует существующий ordered failure policy: все source snapshots валидируются до authority mutation; затем выполняется ровно один durable SQLite transition; lexical/vector projections обновляются после него. Cross-store rollback не вводится: lexical failure возвращает принятый typed recovery/degraded outcome, а optional vector failure не откатывает SQLite/lexical result и не создаёт ложный `Current`.

## Definition of Done

- Exact base, public boundary table, scenario matrix, expected outputs и per-leaf causal RED/GREEN/REFACTOR/final procedures перечислены без unresolved alternatives.
- Существующие characterization commands проходят на base; новые boundary oracles описаны через ownership/import direction и observable delegation, а не arbitrary size/internal name.
- Для каждого будущего oracle записана causal RED procedure на leaf base и required evidence; фактический RED выполняет соответствующий code-worker до product change.
- Для B1–D2 паспорт задаёт точный focused test/assertion target, команду RED, minimal GREEN revision, отдельный post-GREEN REFACTOR revision и final verification; произвольная structural эвристика без observable contract не принимается.

## Операционная проверка

- Test oracle / причинный RED: discovery exception — A1 не меняет code/tests. Он материализует test oracle и причинный RED для B1–D2; existing characterization suite сначала GREEN на exact base.
- Команда или процедура: `RF-G00..G04`; readback existing tests/goldens; dry-run/spec review будущих assertions без добавления failing tests.
- Окружение и prerequisites: clean Windows worktree, locked Cargo dependencies, no E5 requirement для ordinary passport.
- Ожидаемый GREEN / PASS: existing characterization GREEN; per-leaf lifecycle исполним и паспорт не содержит placeholder/unknown owner.
- Evidence: `evidence/refactor/boundary-passport.md`, test output summary, A master verdict.
- Unverified areas: E5 mutation/provider security остаётся cache-gated и передаётся D2 как обязательный gate.

## Условия остановки

- Dirty base не разрешён, contract conflicts найдены, structural oracle требует public/storage change или любое текущее поведение не удаётся воспроизвести.

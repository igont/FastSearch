<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Замеры ветки D

Во время активной работы Root добавляет короткий управленческий checkpoint не реже одного раза в 20 минут.

| Time | Active leaf | New verifiable result | Accepted delta | Wait or rework | Root decision |
|---|---|---|---:|---|---|
| 13.08.2026 13:50 | D1 | Нет; future horizon | 0% | DORMANT | Открыть после A1 PASS; D2 принять только с real cache evidence |
| 13.08.2026 14:33 | D1 | Clean common A integration base `6d61e154` assigned to worker | 0% | D2 remains BLOCKED: E5 env unset | Выполнить preflight, causal RED и D1 |
| 13.08.2026 14:35 | D1 | Stale handoff path blocked preflight; Root verified tracked passport in exact D worktree and resumed leaf | 0% | REWORK handoff path only; D2 remains BLOCKED | Use local tracked passport; no candidate change before causal RED |
| 13.08.2026 14:49 | D1 | RED→GREEN→REFACTOR и focused gates PASS; RF-G03 LNK1104 from shared-target collision, not accepted | 0% | WAITING Cargo-exclusive window; D2 remains BLOCKED | CG-02: rerun only RF-G03 after B/C CARGO_QUIET |
| 13.08.2026 14:52 | D1 | RF-G03 повторён в exclusive window: 91 PASS; RF-G13L candidate verified | +9% | D2 BLOCKED: E5 env unset | Freeze D1 candidate; await owner E5 path for D2 |

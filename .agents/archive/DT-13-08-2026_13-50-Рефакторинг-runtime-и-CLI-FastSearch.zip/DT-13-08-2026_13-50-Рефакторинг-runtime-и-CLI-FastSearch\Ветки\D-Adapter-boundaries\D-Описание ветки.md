<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки D — Adapter boundaries

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-2`
- Branch ID: `D`
- Base revision: exact Root integration revision после accepted A1; immutable anchor обязателен.

## Наблюдаемое изменение

- Baseline: `source/mod.rs` совмещает scan/containment и Markdown/TSV parsing; `vector.rs` совмещает projection lifecycle, model verification, provider invocation, Windows guards и security tests.
- После ветки: parser и verified-provider boundaries физически разделены, сохраняя adapter public surface, bytes/state semantics и fail-closed security.

## Целостное состояние ветки

Filesystem admission остаётся единственным owner source discovery и передаёт bounded UTF-8 content чистым parsers. Vector lifecycle остаётся owner state/projection, а immutable model verification/provider execution живут за узким internal seam. No new fallback, provider, cache format or public port appears.

## Ownership

- Разрешено изменять: `src/adapters/source/**`, `src/adapters/vector/**`, их internal/focused tests; PV-2 D2 exception — только `src/adapters/symbols.rs` locator-order preservation и exact `tests/d2_symbol_lifecycle.rs` assertion.
- Только чтение: domain/ports, production/application wiring, A1 passport, map/symbol/state/lexical adapters.
- Запрещено изменять: Cargo dependencies/features, source/stable-id semantics, SQLite/Tantivy/E5 formats, public adapter signatures, roadmap/handoff, `.agents` candidate content; PV-2 не разрешает иных изменений `symbols.rs`.

## Зависимости и интеграция

- Preconditions: A1 accepted/integrated; exact A base; qualified E5 cache available before D2 acceptance.
- Consumers: Root integration and future maintenance.
- Producer gate / evidence: D master PASS; D1 `RF-G08`; D2 `RF-G10`; full `RF-G09`.
- Допустимая параллельность: B/C; внутри D — D1 затем D2 для одного worker, хотя paths disjoint.
- Порядок интеграции: после B/C to minimize application conflicts; repeat all adapter and integration gates.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| D1 | 9% | Scanner/containment и Markdown/TSV parsers имеют отдельное ownership | structural RED; parser/admission tests PASS |
| D2 | 11% | Projection lifecycle и immutable verified provider имеют отдельное ownership | D1 accepted; qualified E5 cache; all security/race tests PASS |

Сумма весов листьев равна весу ветки из `Описание задачи.md`.

## Definition of Done

- Adapter entrypoints и outputs неизменны, internal layers независимы и тестируемы; ordinary and cache-gated security evidence PASS на exact candidate.
- D1 завершается leaf-final `RF-G13L`; D2 после квалифицированного immutable E5 cache evidence сначала проходит `RF-G13L`, затем формирует branch-final candidate для `RF-G13B` и D master-review. Master-review получает exact RED base/output, minimal GREEN revision, отдельный REFACTOR revision и leaf-final acceptance каждого листа.

<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки B — Production runtime

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-1`
- Branch ID: `B`
- Base revision: exact Root integration revision после accepted A1; worker обязан подтвердить immutable anchor.

## Наблюдаемое изменение

- Baseline: `src/application/production.rs` одновременно владеет production wiring, indexing/search, filesystem containment, Windows handles и run cleanup; `application/mod.rs` содержит отдельный DT2 `RealRuntime` coordinator.
- После ветки: те же public runtime types и результаты делегируют security, orchestration и compatibility явным внутренним owners; production/DT2 paths не дублируют lifecycle policy.

## Целостное состояние ветки

`ProductionRuntime` остаётся фасадом/composition root. Service containment и run ownership изолированы от retrieval; indexing coordinator единолично упорядочивает source snapshot → SQLite reconciliation → lexical/vector projection; compatibility runtime находится в явно legacy-модуле и сохраняет старые команды. Ни один extraction не меняет public types, failure classification, storage/index paths или security guarantees.

## Ownership

- Разрешено изменять: `src/application/production.rs` с разбиением в `src/application/production/**`; `src/application/mod.rs`; новый `src/application/compatibility/**`; focused runtime/security tests.
- Только чтение: `src/domain/**`, `src/ports/**`, adapters кроме импортов, A1 passport, CLI tests.
- Запрещено изменять: CLI grammar/rendering, Cargo dependencies, SQLite schema, Tantivy/E5 formats, roadmap/handoff, `.agents` в candidate.

## Зависимости и интеграция

- Preconditions: A1 accepted/integrated; B worker starts clean from exact A base.
- Consumers: Root integration и будущий DT4 composition.
- Producer gate / evidence: B master PASS с `RF-G04..G06`, `RF-G09`; exact public/runtime parity.
- Допустимая параллельность: C и D на том же A base; внутри B строго B1 → B2 → B3 из-за общих application files.
- Порядок интеграции: после A, до C/D.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| B1 | 12% | Security/service/run boundary извлечена без ослабления checks | structural RED; Windows negative tests; master PASS |
| B2 | 15% | Index/search/lifecycle coordination имеет одного owner | B1 accepted; runtime/recovery/fusion gates PASS |
| B3 | 8% | DT2 compatibility изолирована и использует общий принятый coordinator policy | B2 accepted; legacy CLI/runtime tests PASS |

Сумма весов листьев равна весу ветки из `Описание задачи.md`.

## Definition of Done

- `ProductionRuntime` и `RealRuntime` сохраняют public behavior, но application modules имеют раздельное ownership; все security, lifecycle, recovery и compatibility gates проходят на exact candidate.
- B1 и B2 завершаются leaf-final `RF-G13L`; B3 сначала проходит `RF-G13L`, затем формирует branch-final candidate для `RF-G13B` и B master-review. Master-review получает exact RED base/output, minimal GREEN revision, отдельный REFACTOR revision и leaf-final acceptance каждого листа; объединённое GREEN/REFACTOR evidence не принимается.

<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки C — CLI pipeline

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-1`
- Branch ID: `C`
- Base revision: exact Root integration revision после accepted A1; immutable anchor обязателен.

## Наблюдаемое изменение

- Baseline: `execute_cli_formatted` распознаёт positional vectors и одновременно dispatches runtime; console отдельно разбирает text, снова собирает `Vec<String>`, а `cli.rs` рендерит technical/human/JSON.
- После ветки: direct и interactive входы создают один typed command, общий dispatcher выполняет его, отдельные presenters формируют прежние outputs.

## Целостное состояние ветки

Parsing, execution и presentation имеют явные internal contracts. Direct automation сохраняет grammar, `--json` placement/terminator, stdout/stderr и exit codes. Chat сохраняет prompts, context, cancel/continue, whitespace-in-query и режим JSON. DT2 compatibility commands остаются в том же parser contract, но не рекламируются как production surface.

## Ownership

- Разрешено изменять: `src/application/cli.rs` с разбиением в `src/application/cli/**`; `src/application/console.rs` с разбиением в `src/application/console/**`; минимальный `src/main.rs`; CLI tests/goldens.
- Только чтение: A1 passport, application runtime public surface, domain/ports.
- Запрещено изменять: runtime semantics, adapters, dependency set, JSON schema version/fields, public CLI commands, roadmap/handoff, `.agents` candidate content.

## Зависимости и интеграция

- Preconditions: A1 accepted/integrated; exact A base.
- Consumers: Root integration. C1 command/dispatcher остаётся private CLI-only implementation; future MCP продолжает ориентироваться на принятые `AgentSurface`/`ProductionRuntime`, а общий use-case boundary/DTO/indexing ownership решаются только DT4 discovery/replan.
- Producer gate / evidence: C master PASS, `RF-G04`, `RF-G07`, `RF-G09`, no runtime semantic duplication.
- Допустимая параллельность: B/D; C1 → C2 sequential.
- Порядок интеграции: после B; conflict resolution only mechanical and followed by full CLI gates.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| C1 | 17% | Typed command/parser/dispatcher accepted | parser causal RED; direct/legacy tests PASS |
| C2 | 13% | Technical/human/JSON presenters и chat translation изолированы | C1 accepted; goldens/chat/stream/exit parity PASS |

Сумма весов листьев равна весу ветки из `Описание задачи.md`.

## Definition of Done

- Все CLI entry paths проходят один typed pipeline; представления не содержат runtime operations; полный supported UX/automation contract совпадает с A1 passport.
- C1 завершается leaf-final `RF-G13L`; C2 сначала проходит `RF-G13L`, затем формирует branch-final candidate для `RF-G13B` и C master-review. Master-review получает exact RED base/output, minimal GREEN revision, отдельный REFACTOR revision и leaf-final acceptance каждого листа; dispatcher остаётся private CLI-only detail и не становится MCP boundary.

<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Замеры ветки A

Во время активной работы Root добавляет короткий управленческий checkpoint не реже одного раза в 20 минут.

| Time | Active leaf | New verifiable result | Accepted delta | Wait or rework | Root decision |
|---|---|---|---:|---|---|
| 13.08.2026 13:50 | A1 | План материализован; product work не начат | 0% | WAITING: dirty main | Не создавать worker/worktree до plan PASS и owner execution command |
| 13.08.2026 13:58 | A1 | Clean exact base `b083eae` доступен | 0% | WAITING: plan review/owner command | Повторить validate и согласовать план; worker не запускать |
| 13.08.2026 14:21 | A1 | Worker подтвердил clean exact base, ancestry и ограниченный ownership; RF-G01..G04 воспроизводятся | 0% | — | Продолжить bounded discovery до паспорта и master review |
| 13.08.2026 14:24 | A1 | Параллельный baseline запуск прерван shared Cargo cache lock/outer timeout, PASS не заявлен | 0% | REWORK процедуры evidence | Выполнить gates последовательно; корректировка CG-01 |
| 13.08.2026 14:28 | A1 | Последовательные RF-G01..G04 PASS; materialized versioned passport | 0% | — | Принять candidate только после RF-G00 и master verdict |

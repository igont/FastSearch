<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист D1 — Source parser boundary

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-1`
- Branch / Leaf ID: `D / D1`
- Вес задачи: `9%`

## Наблюдаемое изменение

- Baseline: one 1044-line module owns canonical scan, ignore rules, containment, frontmatter/Markdown sections, TSV rows and broad tests.
- После листа: scanner/admission and format parsers are separate internal modules with identical `FilesystemSource`/snapshot behavior.

## Целевое состояние листа

Scanner alone resolves canonical contained files, exclusions, allowed kinds, UTF-8 and deterministic locator order. Markdown/TSV parsers receive bounded content/locator context and either return a complete snapshot or typed error; they never perform filesystem discovery or partial publication.

## Границы состояния

- В scope: `src/adapters/source/**` physical module split and existing source tests.
- Сохраняется: ignore/negation/nested rules, junction containment, UTF-8/size admission, frontmatter semantics, heading/row locators, hashes, stable IDs, duplicate/atomic failure and ordering.

## Preconditions

- A1 source behavior matrix and structural assertion accepted; exact D base.

## Наблюдаемые сценарии

- Contained allowed file scans once and dispatches to correct pure parser.
- Invalid UTF-8/frontmatter/TSV, excluded or external junction yields same fail-closed/no-partial result.

## Definition of Done

- Parser modules contain no directory traversal; scanner contains no Markdown/TSV grammar.
- All source, DT2 oracle and representative map/symbol admission tests PASS identically.

## Операционная проверка

- Test oracle / причинный RED: internal parser boundary tests and architecture assertion require parser modules callable without traversal; absent/mixed on base, so RED while current source suite GREEN.
- Команда или процедура: source unit tests; `RF-G04`, `RF-G08`; `cargo test --locked --test dt2_contract_oracle --test a2_public_contract`.
- Окружение и prerequisites: Windows junction fixtures and ordinary locked contour.
- Ожидаемый GREEN / PASS: boundary GREEN; exact snapshots/errors/order match passport.
- Evidence: D1 test summary + diff ownership inventory.
- RED gate: на exact A base выполнить parser-without-traversal/import-direction oracle; causal RED при GREEN current source/admission suite.
- Minimal GREEN gate: exact first D1 candidate делает boundary oracle GREEN и проходит `RF-G04`, `RF-G08` focused commands.
- REFACTOR gate: exact next candidate removes duplicate grammar/traversal helpers and temporary forwarding, verifies no parser filesystem discovery, then `RF-G12` with repeat D1 tests.
- Leaf-final verification gate: exact D1 candidate проходит `RF-G00`, `RF-G01..G04`, `RF-G08`, `RF-G13L`; Root acceptance записан до открытия D2. Branch master review здесь ещё не выполняется.
- Unverified areas: no new source formats/languages.

## Условия остановки

- Split changes locator/hash/stable ID, duplicates admission ownership, requires new port or weakens atomic failure.

<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист B2 — Индексация поиск и lifecycle

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-1`
- Branch / Leaf ID: `B / B2`
- Вес задачи: `15%`

## Наблюдаемое изменение

- Baseline: `ProductionRuntime` напрямую сканирует три sources, reconciles SQLite, обновляет две projections, вычисляет lifecycle и собирает пять retrieval channels.
- После листа: отдельные internal indexing и search coordinators выполняют эти flows; `ProductionRuntime` остаётся wiring/facade без дублирования policy.

## Целевое состояние листа

Один coordinator сначала получает и полностью валидирует source snapshots, затем выполняет ровно один durable SQLite transition и только после него обновляет rebuildable projections. Cross-store rollback запрещён: lexical/vector failure не откатывает SQLite authority. Другой coordinator получает channel candidates и вызывает существующий `FusionCoordinator`. Exact dominance, ordering/provenance и optional vector fallback остаются прежними.

## Границы состояния

- В scope: `ProductionRuntime::project/search/lifecycle_status/combined_records` и новые internal coordinator modules/tests.
- Сохраняется: source order/identity, durable generation, projection update/rebuild behavior, channel calibration, map/symbol related semantics, no false Current.

## Preconditions

- B1 accepted candidate; exact continuation revision; A1 runtime oracle GREEN.

## Наблюдаемые сценарии

- Update/rebuild validates complete sources, commits one SQLite generation, затем обновляет lexical и optional vector согласно baseline order.
- Lexical failure возвращает прежний typed error/degraded-or-stale recovery при сохранённой authority; optional vector failure не откатывает SQLite/lexical success, не маскируется как Current и сохраняет truthful vector capability/fallback. Никакого cross-store rollback.

## Definition of Done

- Facade delegates flows through named internal boundaries; no new port/cross-store access exists.
- Runtime, fusion, recovery, related and production mock audit tests PASS.

## Операционная проверка

- Test oracle / причинный RED: boundary test обращается к target coordinator contract и architecture assertion запрещает direct multi-adapter orchestration в facade; RED на B1 base.
- Команда или процедура: `RF-G04..G06`; `cargo test --locked --test e1_fusion --test c3_sqlite_full_reconciliation --test c2_related_navigation --test production_mock_audit`.
- Окружение и prerequisites: locked ordinary contour; no E5 cache required for fallback cases.
- Ожидаемый GREEN / PASS: structural GREEN и одинаковые records/order/freshness/errors/generations.
- Evidence: focused output summary + B master verdict.
- RED gate: на exact accepted B1 candidate выполнить A1 orchestration assertion; causal RED при GREEN current runtime/recovery tests.
- Minimal GREEN gate: exact first coordinator candidate делает boundary oracle GREEN и проходит focused B2 commands с baseline SQLite-before-projection outcomes.
- REFACTOR gate: exact next candidate удаляет duplicate flow/temporary forwarding, проходит import/ownership audit и `RF-G12` с повтором B2 recovery/fusion tests.
- Leaf-final verification gate: exact B2 candidate проходит `RF-G00`, `RF-G04..G06`, `RF-G13L`; Root acceptance записан до старта B3, evidence отдельно фиксирует lexical failure и optional-vector failure без rollback.
- Unverified areas: configured real E5 path проверяется D2/integration `RF-G10`.

## Условия остановки

- Нужен новый public method/port, изменяется cross-store authority, failure masking или ranking semantics.

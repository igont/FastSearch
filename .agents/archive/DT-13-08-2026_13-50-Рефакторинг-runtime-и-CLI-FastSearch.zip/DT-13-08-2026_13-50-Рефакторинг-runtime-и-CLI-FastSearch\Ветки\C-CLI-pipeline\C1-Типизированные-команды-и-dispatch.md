<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист C1 — Типизированные команды и dispatch

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-1`
- Branch / Leaf ID: `C / C1`
- Вес задачи: `17%`

## Наблюдаемое изменение

- Baseline: one 95-line match parses shapes and invokes runtime helpers; console rebuilds positional vectors.
- После листа: internal `Command`/configuration values are parsed once and executed by one dispatcher for production and compatibility variants.

## Целевое состояние листа

Private CLI parser owns only syntax/validation and yields private CLI commands. Private CLI dispatcher owns runtime opening/index/search/get/related/status solely for current direct/chat CLI. Он не является transport/application DTO или границей MCP. Test-only projection fault remains literal, final-update-only and absent from normal help. No command implicitly mutates more than current behavior.

## Границы состояния

- В scope: CLI argument normalization/parser/dispatch helpers and focused tests.
- Сохраняется: command names/order, optional E5 argument, mode values, `--json` position/terminator/idempotence, usage/runtime error mapping, search process-boundary reconciliation and DT2 compatibility.

## Preconditions

- A1 command matrix/outputs accepted; clean C worktree from exact A base.

## Наблюдаемые сценарии

- Production direct command parses to typed value and dispatches once.
- Invalid/duplicate/options-after-terminator/test-fault/legacy shapes preserve current acceptance and error classification.

## Definition of Done

- Console and direct mode can invoke the same typed dispatcher without fabricating positional vectors.
- Parser/dispatcher tests plus direct CLI process tests PASS with unchanged outputs.

## Операционная проверка

- Test oracle / причинный RED: new parser contract tests instantiate target typed commands and compare A1 command matrix; target boundary absent on base, so RED while existing CLI suite remains GREEN.
- Команда или процедура: focused parser tests; `cargo test --locked --test cli_ux --test cli_real_flow`; `RF-G04`.
- Окружение и prerequisites: Windows process tests; exact A base.
- Ожидаемый GREEN / PASS: typed tests GREEN; supported args, errors, stdout/stderr and exit codes unchanged.
- Evidence: C1 test summary + candidate diff inventory.
- RED gate: на exact A base выполнить private typed-command boundary tests; causal RED при GREEN existing `cli_ux/cli_real_flow`.
- Minimal GREEN gate: exact first C1 candidate делает typed tests GREEN и проходит listed direct/legacy CLI controls.
- REFACTOR gate: exact next candidate removes positional-vector reconstruction/duplicate parsing and temporary bridge, confirms CLI-only visibility/no domain or MCP DTO, then runs `RF-G12` and repeats C1 tests.
- Leaf-final verification gate: exact C1 candidate проходит `RF-G00`, `RF-G04`, `RF-G07`, `RF-G13L`; Root acceptance записан до старта C2. Branch master review здесь ещё не выполняется.
- Unverified areas: interactive presentation moved only in C2.

## Условия остановки

- Typed model would become transport DTO/public domain, command behavior changes or runtime must gain a new method.

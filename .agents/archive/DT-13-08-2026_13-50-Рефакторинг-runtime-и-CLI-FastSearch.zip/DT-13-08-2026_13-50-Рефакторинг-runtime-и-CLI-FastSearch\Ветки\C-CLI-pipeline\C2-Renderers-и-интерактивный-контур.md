<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист C2 — Renderers и интерактивный контур

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-1`
- Branch / Leaf ID: `C / C2`
- Вес задачи: `13%`

## Наблюдаемое изменение

- Baseline: `cli.rs` mixes execution with three render formats; console parses commands and translates them back to argument vectors.
- После листа: format-specific presenters consume typed application outcomes; console translates human input directly to C1 commands and owns only session/prompt/color behavior.

## Целевое состояние листа

Technical, human and JSON schema v1 presenters share explicit naming/mapping helpers without running product operations. Chat maintains context and error recovery around typed dispatcher. JSON toggling, ANSI suppression, help/version and EOF/cancellation behave exactly as passport/goldens.

## Границы состояния

- В scope: CLI result types/presenters, console command translation/session, test/golden organization.
- Сохраняется: byte-level golden rows where asserted, JSON keys/schema, technical output, Russian prompts/help, Enter/accepted answer semantics, NO_COLOR, streams/codes.

## Preconditions

- C1 accepted; exact continuation revision; A1 output matrix immutable.

## Наблюдаемые сценарии

- One typed outcome renders in Technical/Human/Json without reopening runtime.
- Chat executes multiple commands, recovers after error, changes context, toggles JSON and exits/EOF cleanly.

## Definition of Done

- Presenters have no filesystem/runtime calls; console no longer constructs direct-CLI argument vectors.
- Full CLI/golden suite and scripted smoke produce accepted outputs/codes/streams.

## Операционная проверка

- Test oracle / причинный RED: presenter/console seam tests call target outcome renderer/typed translation absent on C1 base; existing golden suite remains control GREEN.
- Команда или процедура: `RF-G07`; `cargo test --locked --test cli_ux --test cli_real_flow --test golden_mock_flow`; built executable smoke for help/version/cancel/continue.
- Окружение и prerequisites: redirected and terminal-like output tests; no E5 required.
- Ожидаемый GREEN / PASS: new seam tests GREEN and A1 expected stdout/stderr/JSON/prompts identical.
- Evidence: focused logs summarized in C master verdict.
- RED gate: на exact accepted C1 candidate выполнить presenter/typed-console seam tests; causal RED при GREEN current goldens/chat controls.
- Minimal GREEN gate: exact first C2 candidate делает seam GREEN и проходит listed outputs/prompts/stream tests.
- REFACTOR gate: exact next candidate removes duplicated names/mapping and positional-vector translation, verifies presenters have no runtime/filesystem calls, then `RF-G12` with full C2 tests.
- Leaf/branch-final verification: exact C2 candidate сначала проходит `RF-G13L`; затем тот же descendant candidate со всеми accepted C1–C2 проходит `RF-G00`, `RF-G04`, `RF-G07`, `RF-G13B` и C master review.
- Unverified areas: real interactive terminal color is covered by is-terminal/NO_COLOR tests, not manual browser/UI.

## Условия остановки

- Any JSON/technical/prompt contract change, loss of deterministic automation, or execution logic remains duplicated in presenter/console.

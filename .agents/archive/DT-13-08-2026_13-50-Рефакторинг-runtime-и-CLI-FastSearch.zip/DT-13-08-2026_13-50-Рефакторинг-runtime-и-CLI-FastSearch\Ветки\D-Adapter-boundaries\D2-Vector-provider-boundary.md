<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист D2 — Vector provider boundary

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-2`
- Branch / Leaf ID: `D / D2`
- Вес задачи: `11%`

## Наблюдаемое изменение

- Baseline: one 1045-line module owns projection mutex/generations, embedding/search math, immutable model allowlist/manifest verification, Win32 handles and cache-gated race/security tests.
- После листа: projection lifecycle delegates immutable verified byte acquisition/provider execution to a dedicated internal boundary, with identical provenance, fallback and security behavior.

## Целевое состояние листа

Lifecycle state/generation/search owns projection records and vector scoring. Verified model owner pins canonical directories/files, validates exact allowlist/manifest/size/EOF, invokes accepted provider over verified bytes and prevents mutation/replacement until completion. Test hooks remain cfg(test) and cannot form production route.

## Границы состояния

- В scope: `src/adapters/vector/**` physical split and existing vector tests; PV-2 exception — source file enumeration in `src/adapters/symbols.rs` is sorted by the same normalized emitted locator contract before `SourceSnapshot` creation, with an exact external symbol lifecycle assertion.
- Сохраняется: `LocalE5Vector` public API, model identity/provenance, normalization/cosine/ranking, generation/freshness, unavailable/degraded recovery, manifest/allowlist and mutation/reparse/race protections; `SymbolSource::snapshots` observed normalized-locator ordering.

## Preconditions

- D1 accepted; A1 vector passport; accepted complete local cache in `FASTSEARCH_E5_MODEL_ROOT` is available and read-only.

## Наблюдаемые сценарии

- Verified model embeds accepted records/query and projection reports same results/provenance.
- Missing/incomplete/mutated/replaced/reparse model or concurrent reconfigure fails/degrades exactly as before without false hits/current or external mutation.

## Definition of Done

- Provider boundary cannot access mutable projection state; lifecycle cannot bypass verified model acquisition.
- Ordinary fallback and every selected ignored `RF-G10` security/race test PASS on exact candidate.

## Операционная проверка

- Test oracle / причинный RED: boundary test requires verified provider seam and architecture assertion forbids provider/Win32 file verification inside projection lifecycle; RED on D1 base. PV-2 adds separate causal ordering RED on exact `cb531851`: remove the R1 test-side sort, then `cargo test --locked --test d2_symbol_lifecycle exact_current_src_repeats_complete_bounded_runtime_inventory` must fail only because `SymbolSource::snapshots` still sorts raw `PathBuf`; test-side sorting is prohibited.
- Команда или процедура: ordinary vector tests plus exact `RF-G10` commands; `RF-G01..G03`, `RF-G09`.
- Окружение и prerequisites: Windows, immutable accepted local E5 cache, no network requirement.
- Ожидаемый GREEN / PASS: boundary GREEN; all ordinary and cache-gated tests PASS; outputs/provenance/failure states unchanged.
- Evidence: exact cache identity without machine path/raw corpus, command outcomes, D master verdict.
- RED gate: после successful bounded E5 preflight на exact accepted D1 candidate выполнить verified-provider/projection ownership oracle; causal RED при GREEN ordinary vector fallback tests.
- Minimal GREEN gate: exact first D2 candidate делает provider-boundary oracle GREEN; PV-2 exact next GREEN candidate precomputes normalized emitted locators and orders `SourceSnapshot` inputs by them before materialization, makes the unsorted symbol oracle GREEN, then passes provider boundary, ordinary vector and symbol lifecycle controls plus exact `RF-G10` ignored tests.
- REFACTOR gate: exact next candidate removes duplicate verification/provider paths and temporary bridge, preserves the normalized-locator ordering implementation without test normalization, proves lifecycle cannot bypass verified acquisition, then `RF-G12`, exact symbol oracle and every D2/`RF-G10` command repeat on that revision.
- Leaf/branch-final verification: exact D2 candidate сначала проходит `RF-G13L` with `cargo test --locked --test d2_symbol_lifecycle exact_current_src_repeats_complete_bounded_runtime_inventory`; затем тот же descendant candidate со всеми accepted D1–D2 проходит `RF-G00`, `RF-G01..G03`, `RF-G08..G10`, exact affected symbol/admission order gate, `RF-G13B` и D master review.
- Unverified areas: no Linux/runtime-provider qualification and no alternative model/provider.

## Условия остановки

- Cache unavailable, any ignored test fails, model/provider bytes or features must change, new fallback appears or security invariant cannot survive split.

<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист B1 — Безопасность service и runs

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-1`
- Branch / Leaf ID: `B / B1`
- Вес задачи: `12%`

## Наблюдаемое изменение

- Baseline: service containment, secure bootstrap, Windows handle guards, marker ownership и retrieval facade сосуществуют в одном `production.rs`.
- После листа: внутренний service/run security owner предоставляет узкий facade, а `ProductionRuntime` только вызывает его; все negative scenarios дают прежние typed failures и не пишут за boundary.

## Целевое состояние листа

Path canonicalization/containment, reparse detection, secure service creation и exact run cleanup собраны в security-focused modules. Windows и non-Windows implementations остаются explicit cfg variants. Security code не знает retrieval adapters, а production facade не повторяет низкоуровневые checks.

## Границы состояния

- В scope: строки `production.rs` для path/run/handle logic, новые internal modules, текущие bootstrap/security tests.
- Сохраняется: accepted path exceptions, fail-closed junction/reparse/race behavior, exact marker/schema checks, cleanup ownership и error kinds/messages where externally asserted.

## Preconditions

- A1 passport/structural assertion accepted; clean B worktree from exact A base.

## Наблюдаемые сценарии

- Production open создаёт/pins isolated service и затем wiring adapters.
- Source overlap, junction insertion, existing-parent swap, unknown run content или wrong owner marker отклоняются до external write/delete.

## Definition of Done

- Security modules не импортируют retrieval/domain behavior кроме typed error boundary; facade exposes only required service/run operations.
- `RF-G05` и branch-focused unit tests PASS; static structural assertion GREEN.

## Операционная проверка

- Test oracle / причинный RED: A1 assertion требует отдельного security owner и запрещает path/run/Win32 implementation в facade; на base RED при зелёном `RF-G05`.
- Команда или процедура: structural assertion; `cargo test --locked --test e2_production_runtime --test e2_release_runner`; focused production security unit tests.
- Окружение и prerequisites: Windows NTFS, junction privileges как в текущих tests.
- Ожидаемый GREEN / PASS: assertion GREEN; все positive/negative outputs и no-external-write sentinels прежние.
- Evidence: test summary + B master verdict.
- RED gate: на exact A base выполнить A1 security ownership assertion отдельно; получить causal RED при GREEN `RF-G05`, записать base и output.
- Minimal GREEN gate: на exact first candidate assertion и B1 focused tests GREEN; записать GREEN revision, не выполнять дополнительную перестройку в этом commit.
- REFACTOR gate: на следующем exact candidate устранить временные re-export/duplication, проверить import direction и выполнить `RF-G12` с повтором всех B1 tests; записать GREEN→REFACTOR revisions.
- Leaf-final verification gate: exact B1 candidate проходит `RF-G00`, `RF-G01..G05`, `RF-G13L`; Root acceptance записан до старта B2. Branch master review здесь ещё не выполняется.
- Unverified areas: non-Windows cfg и Linux runtime не компилировались/не квалифицировались; Windows `--all-targets` их не покрывает.

## Условия остановки

- Extraction требует public API, error/storage change, ослабляет atomic containment или Windows negative test не воспроизводится.

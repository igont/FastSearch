<!-- dtree generator=0.3.1 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки A — Контракт и baseline

- Task ID: `FASTSEARCH-REFACTOR-13-08-2026`
- Plan version: `PV-1`
- Branch ID: `A`
- Base revision: `b083eae73a8963df2612abd3cf44b095f6d8e4f2`; clean local main, remote behind 1.

## Наблюдаемое изменение

- Baseline: `HEAD=b083eae`, clean worktree, descendant `d4affc3`; same content passed format/Clippy/91 ordinary tests, E5 contour ignored.
- После ветки: принят clean exact base и versioned boundary passport, который превращает текущее поведение CLI/runtime/storage/security в исполняемый refactor oracle.

## Целостное состояние ветки

Ни один refactor-worker больше не опирается на некоммитнутый снимок или неявные ожидания. Паспорт перечисляет public Rust surface, direct/chat CLI grammar, JSON/error/exit contracts, persistence/projection boundaries, security-negative scenarios, DT2 compatibility и cache-gated evidence. Characterization tests способны обнаружить semantic drift, но не закрепляют случайное внутреннее расположение кода.

## Ownership

- Разрешено изменять: `evidence/refactor/**` только; A1 не создаёт test/product code.
- Только чтение: `src/**`, `Cargo.toml`, `Cargo.lock`, `README.md`, `ROADMAP.md`, `evidence/dt3-dt4-handoff.md`, принятый DT3 archive.
- Запрещено изменять: product-код, dependency set, persistence artifacts, baseline commit content и `.agents/**` в candidate revision.

## Зависимости и интеграция

- Preconditions: Root разрешил происхождение текущих изменений и получил clean exact base; `RF-G00..G04` проходят на нём.
- Consumers: B, C, D и итоговая integration acceptance.
- Producer gate / evidence: A1 discovery master PASS; паспорт содержит exact per-leaf commands, causal RED, minimal GREEN, REFACTOR и final procedures для каждого consumer.
- Допустимая параллельность: нет; A1 — единственный runnable leaf до producer gate.
- Порядок интеграции: A первым; exact A integration revision становится общим base B/C/D.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| A1 | 15% | Clean exact base и исполняемый behavior/boundary passport | `RF-G00..G04`; causal-oracle controls; master PASS |

Сумма весов листьев равна весу ветки из `Описание задачи.md`.

## Definition of Done

- Паспорт и characterization suite однозначно отделяют сохраняемое поведение от целевой внутренней структуры; clean exact A candidate принят и может безопасно породить B/C/D.

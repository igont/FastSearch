<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Замеры ветки D

Во время активной работы Root добавляет короткий управленческий checkpoint не реже одного раза в 20 минут.

| Time | Active leaf | New verifiable result | Accepted delta | Wait or rework | Root decision |
|---|---|---|---:|---|---|
| 11.08.2026 15:58 | D1 | Exact A integration revision зафиксирован; D1 materialized и worktree чист | 0% | — | Запущен D1; следующий gate — evidence и G-08.D1 |
| 11.08.2026 16:12 | D1 | RED/green replay и master review PASS; classified adapter-only/internal | 6% | D1-R1/R2 evidence repaired | G-08.D1 PASS; разрешено materialize D2 |
| 11.08.2026 16:20 | D2 | Изолированный Tantivy exact/FTS replay и review PASS | 7% | — | G-08.D2 PASS; разрешено materialize D3 |
| 11.08.2026 16:31 | D3 | Изолированный SQLite lifecycle replay и review PASS; общий A revision подтверждён | 7% | — | G-08.FINAL PASS; D закрыта, разрешено materialize B1 |

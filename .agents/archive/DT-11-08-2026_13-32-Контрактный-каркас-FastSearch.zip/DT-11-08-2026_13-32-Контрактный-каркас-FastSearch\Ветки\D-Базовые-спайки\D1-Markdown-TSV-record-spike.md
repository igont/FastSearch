<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист D1 — Markdown TSV record spike

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch / Leaf ID: `D / D1`
- Вес задачи: `6%`

## Dormant outline

- Текущее состояние: discovery-лист не материализован и не назначается worker до MG-D1.
- Dependency/base rule: exact accepted A revision задаёт record contract; B ещё не материализован.
- Наблюдаемый результат: один synthetic Markdown section и одна synthetic TSV row воспроизводимо сопоставлены фактическим canonical records либо доказан точный mismatch.
- Ownership после materialization: изолированный подкаталог `spikes/**`, synthetic fixtures и `evidence/spikes/**`; production source/manifests read-only.
- Exclusions: parser choice, fields, command, hashes и expected records определяются после accepted A; TDR content и полный corpus не читаются.
- Materialization gate: Root фиксирует вопрос, минимальные inputs, обязательные record observations, exact reproduction и decision gate `подходит | подходит с ограничениями | заменить`; manifest связывает evidence с exact A revision и G-08.D1 классифицирует результат до D2.
- Stop/backflow: adapter-only/internal позволяет MG-D2 только с exact future TODO. Public record/identity drift блокирует D2/B и запускает A2 causal remediation; после A′ evidence D1 `SUPERSEDED`, D restart с D1. Ownership/DAG/core drift блокирует D2/B и требует owner-specific material replan/review без A2; restart D только если принятый replan изменил A revision.

## Materialized execution — 11.08.2026 15:57

- Exact A / integration revision: `01e557899e5be846bd59f233edf81270dda89da0`; producer-contract A accepted by branch master review iteration 4.
- Question: могут ли публичные типы A без изменения production source сохранить в `CanonicalRecord` один synthetic Markdown section и одну synthetic TSV registry row со stable identity, source locator, searchable content, metadata, relations и content hash?
- Synthetic boundary: только две новые UTF-8 fixtures в `spikes/d1-markdown-tsv/fixtures/**`. Markdown fixture содержит один section; TSV fixture — ровно одну data row. Полный corpus, TDR content и production parser не читаются.
- Reproduction: worker создаёт изолированную Rust spike-program в `spikes/d1-markdown-tsv/**`, собирает library A без изменения manifest, компилирует spike против публичного `fastsearch` library artifact и запускает её на двух fixtures. Program должен строить record только через public A boundary, проверять все обязательные observations и записывать stdout/stderr, команды и вывод в `evidence/spikes/d1-markdown-tsv/**`.
- Required observations: stable IDs различаются и детерминированы; source path и selector различают Markdown section и TSV row; searchable content и metadata не теряются; relations могут быть пусты явно; content hash различает payloads. Spike не заявляет о готовом parser/retrieval implementation.
- Decision gate: `подходит` — все observations подтверждены на exact A revision; `подходит с ограничениями` — только adapter-local parsing/normalization detail отсутствует в A и оформлен точным future TODO без изменения public contract; `заменить` — evidence показывает public record/identity/locator/content/hash mismatch и передаётся в G-08.D1 как public drift. Ownership/DAG/core mismatch не направляется в A2.
- Evidence manifest: `evidence/spikes/d1-markdown-tsv/manifest.md` обязан содержать `evidence → affected contract/path → category → TODO/backflow → A revision → superseded/rerun → verdict`; кандидат D1 не меняет `src/**`, `Cargo.toml`, `Cargo.lock` или tests B/C.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист D2 — Tantivy exact FTS spike

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch / Leaf ID: `D / D2`
- Вес задачи: `7%`

## Dormant outline

- Текущее состояние: discovery-лист не материализован и не назначается worker до MG-D2 после accepted D1 и G-08.D1 PASS.
- Dependency/base rule: exact accepted D1 revision предоставляет только подтверждённые synthetic records и constraints.
- Наблюдаемый результат: изолированный Tantivy experiment различает exact technical identifier и русский FTS либо выдаёт точное ограничение/решение о замене.
- Ownership после materialization: изолированный `spikes/**` и `evidence/spikes/**`; production index/ranking/manifests read-only.
- Exclusions: schema, analyzer, queries, commands и expected IDs определяются после D1; morphology quality, performance и production ranking вне scope.
- Materialization gate: Root фиксирует малый synthetic corpus, отдельные exact/FTS observations, clean-index reproduction и decision gate `подходит | подходит с ограничениями | заменить`; manifest связывает evidence с exact A revision и G-08.D2 классифицирует result до D3.
- Stop/backflow: adapter-only analyzer/index change при неизменном public contract позволяет MG-D3 с exact future TODO. Searchable representation/query public drift блокирует D3/B и запускает A2 causal remediation; после A′ D1/D2 evidence `SUPERSEDED`, D restart с D1. Ownership/DAG/core drift блокирует D3/B и требует owner-specific material replan/review без A2; restart D только при изменении A revision.

## Materialized execution — 11.08.2026 16:12

- Exact A revision: `01e557899e5be846bd59f233edf81270dda89da0`; D1 accepted on integration revision `e6341b669f3c42edd8df7eee8ca2d62a54291c1a`, G-08.D1=`PASS` with no public drift.
- Question: может ли изолированный Tantivy index на малом synthetic corpus независимо возвращать document по exact technical identifier и по русской phrase query, не меняя `SearchQuery`/`SearchResult` A и не выбирая production ranking?
- Synthetic boundary: отдельный local spike package в `spikes/d2-tantivy-exact-fts/**` с фиксированной Tantivy version/lock и двумя UTF-8 documents: один содержит технический identifier, другой — русскую phrase. Никакой production corpus/TDR не читается; root `Cargo.toml` и `Cargo.lock` read-only.
- Reproduction: runner создаёт clean temporary index в ignored `target/d2-tantivy-exact-fts/**`; causal RED должен показать, что одна неразделённая retrieval configuration не доказывает оба different query intent. GREEN обязан использовать отдельное exact-ID поле и Russian text field, вернуть exact expected stable ID для identifier и expected stable ID для phrase, а также записать commands/version/output в `evidence/spikes/d2-tantivy-exact-fts/**`. Replay не меняет tracked evidence.
- Required observations: exact ID lookup не становится полнотекстовым ranking; phrase query не использует exact-ID field; оба hit связываются с synthetic stable IDs A; empty/nonmatching query даёт explicit no-hit, а не panic. Performance, morphology quality, scoring tuning и production schema остаются вне scope.
- Decision gate: `подходит` — independently reproducible exact and Russian FTS observations; `подходит с ограничениями` — adapter-local schema/analyzer/normalization future TODO при неизменных public A query/result semantics; `заменить` — evidence требует изменить public searchable representation, query/result/error/status contract и передаётся как public drift в G-08.D2. Ownership/DAG/core finding не направляется в A2.
- Evidence manifest: `evidence/spikes/d2-tantivy-exact-fts/manifest.md` с per-spike полями `evidence → affected contract/path → category → TODO/backflow → A revision → superseded/rerun → verdict`; кандидат может менять только `spikes/**` и `evidence/spikes/**`.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки B — TDD и fixtures

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch ID: `B`
- Base revision: exact integration revision, созданная Root после принятия A, D и G-08 Contract Closure

## Текущий горизонт

Ветка находится в состоянии `DORMANT OUTLINE`: accepted A+D и G-08.FINAL PASS ещё отсутствуют, поэтому B не задаёт test-target commands, scenarios, composition или expected outputs. Наблюдаемый результат после будущего исполнения — переиспользуемый contract oracle и минимальные synthetic golden fixtures, проверяющие exact post-spike public contracts A на test-local reference doubles.

## Ownership

- После соответствующего MG-B1/MG-B2 разрешено изменять только: `tests/contract_ports.rs`, `tests/golden_mock_flow.rs`, `tests/support/b/**`, `tests/fixtures/**`, `tests/golden/**`.
- Только чтение: contracts ветки A, `ROADMAP.md`, внешние описания.
- Запрещено изменять: root Cargo manifests, production domain/ports без backflow к A, `src/main.rs`, runtime `src/adapters/**`, `src/application/**`, `src/bin/**`, `spikes/**`, `.agents/**`.

## Зависимости и интеграция

- Materialization gate MG-B1: только после accepted/merged A+D и G-08.FINAL PASS Root проверяет отдельные entries D1/D2/D3, одну общую exact A revision, отсутствие `SUPERSEDED` evidence в accepted set и отсутствие unresolved public/ownership drift; затем фиксирует post-spike public contracts/TODO и превращает B1 в исполнимый лист. MG-B2 открывает B2 только после accepted B1. Каждый code-лист обязан отдельно задать причинный RED, минимальный GREEN, REFACTOR с повторным GREEN и итоговый PASS с G-02–G-04 на exact candidate.
- Если materialization меняет результат, scope, ownership, DAG, public contract, acceptance gate либо активирует новый защитный риск, Root выполняет replan/review; конкретизация уже подтверждённого контура является обычным lifecycle update.
- Consumers: C.
- Producer gate / evidence после materialization: contract oracle и golden fixtures PASS на test-local reference doubles; G-02–G-04.
- Допустимая параллельность: B1 предшествует B2; C не стартует до принятия B; D уже принят до B.
- Порядок интеграции: после A, D и G-08.FINAL; до C.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| B1 | 12% | Post-spike ports A получают переиспользуемый behavioral oracle и test-local reference doubles | MG-B1 после A+D и G-08.FINAL PASS на одной A revision; затем leaf-level TDD gates |
| B2 | 13% | Минимальные synthetic fixtures фиксируют внешний happy/failure/status contract без runtime adapters | MG-B2 после B1 PASS; затем leaf-level TDD gates |

Сумма весов листьев равна весу ветки из `Описание задачи.md`.

## Definition of Done

- До accepted A+D и G-08.FINAL PASS ветка не исполнима и не может быть назначена worker.
- После materialization oracle проходит на reference doubles и готов проверить runtime mocks C; fixtures минимальны, UTF-8 корректны и не содержат TDR content.
- Любая новая непригодность post-spike A повторно активирует contract classification/backflow, а не обход contracts внутри tests.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки A — Контракты и границы

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch ID: `A`
- Base revision: initial exact base `5d9d0bf926b213ea4c0cc0f5ac7c110c8f6af0b2`

## Наблюдаемое изменение

- Baseline: в репозитории есть только `.gitignore` и `ROADMAP.md`; `Cargo.toml`, Rust source и исполняемый контракт отсутствуют; toolchain доступен.
- После ветки: минимальный Rust-пакет собирается, а единая доменная модель и ports выражают границы mock-потока и будущей замены adapters без реализации реального поиска.

## Целостное состояние ветки

Репозиторий имеет один общий core и исполняемую границу. Каноническая запись, запросы, результаты, structured errors и capability status покрыты unit/compile-time tests. Ports отделяют источники, состояние, lexical/vector retrieval, карты, symbols и agent surface от orchestration. Типы не обещают детали будущих adapters, но позволяют явно представить `mock`, `unavailable` и `real`. Несоответствие источникам не скрывается: оно оформляется точным TODO и возвращается владельцу этой ветки.

## Ownership

- Разрешено изменять: root Cargo manifests и `Cargo.lock`, `src/domain/**`, `src/ports/**`, `src/lib.rs`, единственный executable `src/main.rs` и относящиеся unit tests.
- Только чтение: `ROADMAP.md`, внешние исходные описания, `.gitignore`.
- Запрещено изменять: `.agents/**`, `tests/contracts/**`, `tests/fixtures/**`, `tests/golden/**`, `src/adapters/**`, `src/application/**`, `spikes/**`, `evidence/**`.

## Зависимости и интеграция

- Preconditions: plan `PV-2` имеет `PASS`; worker worktree создан из exact initial base и чист.
- Consumers: сначала D и G-08 Contract Closure; только затем B и C.
- Producer gate / evidence: G-01–G-04; public boundary покрыта tests; нет неразрешённых TODO текущего результата.
- Допустимая параллельность: внутри ветки A1 предшествует A2; D не стартует до принятия A, B/C не стартуют до принятия D и G-08.FINAL PASS.
- Порядок интеграции: первая ветка; Root фиксирует accepted candidate и merge revision до MG-D1. Только public-contract drift на G-08.Dk append-only отменяет затронутую приёмку A и под следующей Plan version повторно открывает A2: mismatch Dk служит причинным RED, затем обязательны targeted `GREEN → REFACTOR → PASS`, master review и accepted A′. После A′ всё D evidence superseded и D restart с D1. Ownership/DAG/core drift не назначает A2 и уходит в material replan/review к фактическому owner; restart D нужен только при изменении A revision. После G-08.FINAL и accepted B C получает узкий writer handoff. `src/bin/**`, второй library target и path-include source не создаются.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| A1 | 10% | Rust package/core boundary собираются и имеют минимальную исполняемую поверхность | G-01–G-04 на exact candidate |
| A2 | 15% | Каноническая модель, ports, errors и capability status приняты как единый producer-контракт | A1 PASS; contract-focused tests и G-02–G-04 |

Сумма весов листьев равна весу ветки из `Описание задачи.md`.

## Definition of Done

- На exact accepted candidate выполняются G-01–G-04, Rust-каркас существует без реальных adapters, а D может проверить contract-changing гипотезы без изменения production source.
- B получает A только после принятия D и G-08.FINAL; при public drift A2 повторно проходит causal remediation gates/review, а D1–D3 повторяются на exact A′ до materialization B.
- Все TODO либо закрыты, либо точно указывают объект будущей актуализации и не блокируют наблюдаемый результат A.

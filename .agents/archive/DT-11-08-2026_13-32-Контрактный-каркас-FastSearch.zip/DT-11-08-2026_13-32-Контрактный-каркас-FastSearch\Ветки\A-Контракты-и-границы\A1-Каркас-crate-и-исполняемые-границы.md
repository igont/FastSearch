<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист A1 — Каркас crate и исполняемые границы

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch / Leaf ID: `A / A1`
- Вес задачи: `10%`

## Наблюдаемое изменение

- Baseline: exact commit `5d9d0bf926b213ea4c0cc0f5ac7c110c8f6af0b2`; Rust toolchain доступен, но `Cargo.toml` отсутствует и Cargo не распознаёт продукт.
- После листа: Cargo распознаёт единый FastSearch package с library core и executable boundary; минимальные targets форматируются, компилируются и тестируются.

## Целевое состояние листа

В корне репозитория находится минимальный Rust package, пригодный для добавления доменной модели без перестройки проекта. Library target является будущим общим core, executable target остаётся тонкой границей и не содержит поисковой логики. Реальные adapters, mock composition и подробный CLI отсутствуют.

## Границы состояния

- В scope: Cargo manifests/lock, минимальные library/executable targets, базовые package-level tests.
- Сохраняется: один распространяемый бинарник и один общий core; `.agents` и roadmap не входят в product source.

## Preconditions

- Plan `PV-2` принят; worktree чист и основан на exact initial base.

## Наблюдаемые сценарии

- `cargo metadata` видит package и оба target; `cargo test --workspace --all-targets` завершается успешно.
- Executable target может быть запущен в минимальном режиме без паники и без ложного заявления о работающем поиске.

## Definition of Done

- G-01–G-04 проходят на exact candidate; package не содержит реальных поисковых dependencies или поведения вне scope.
- A2 может добавить модель и ports без изменения package topology.

## Операционная проверка

- Test oracle / причинный RED: на exact baseline `cargo test --workspace --all-targets` завершается ошибкой отсутствующего `Cargo.toml`; worker фиксирует этот ожидаемый RED до создания package.
- GREEN gate: после минимальной реализации тот же `cargo test --workspace --all-targets`, а также `cargo metadata --no-deps` и минимальный запуск завершаются с exit `0`; `src/main.rs` сообщает только scaffold-state.
- REFACTOR gate: после устранения дублирования/уточнения crate boundaries повторно выполняются тот же `cargo test --workspace --all-targets` и минимальный запуск; они остаются GREEN, наблюдаемый scaffold-output не меняется.
- PASS gate exact candidate: `cargo fmt --check`; `cargo clippy --workspace --all-targets -- -D warnings`; `cargo test --workspace --all-targets`; минимальный запуск `src/main.rs`; все команды exit `0`.
- Окружение и prerequisites: Windows, Rust/Cargo `1.97.1`, чистый worker worktree.
- Evidence: отдельные журналы причинного RED, минимального GREEN, повторной GREEN-проверки после REFACTOR и PASS на exact candidate revision в handoff ветки A.
- Unverified areas: будущие dependency versions, adapters и пользовательская CLI-семантика.

## Условия остановки

- Возвратить Root при невозможности сохранить один core/один binary, при toolchain failure вне scope либо если создание package требует изменить roadmap или публичное обещание.

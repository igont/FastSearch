<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки D — Базовые спайки

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch ID: `D`
- Base revision: exact integration revision, созданная Root после принятия и merge ветки A

## Текущий горизонт

Ветка находится в состоянии `DORMANT OUTLINE`: accepted A ещё отсутствует, поэтому spike manifests, commands, schemas, fixtures и expected outputs не фиксируются. Authority уже ограничивает результат ровно тремя гипотезами: Markdown section + TSV row → canonical records; Tantivy exact identifier + русский FTS; SQLite add/change/delete/unchanged по content hash. После materialization каждый результат получает изолированное воспроизводимое evidence и вывод `подходит | подходит с ограничениями | заменить` до создания B/C.

## Ownership

- Разрешено изменять: `spikes/**`, `evidence/spikes/**` и относящиеся полностью синтетические spike fixtures.
- Только чтение: Cargo/core/contracts A, `ROADMAP.md`, внешние описания.
- Запрещено изменять: production manifests/source и contracts A, tests/goldens B, runtime mock/application C, `.agents/**`.

## Зависимости и интеграция

- Materialization gate MG-D1: только после accepted/merged A Root фиксирует exact revision и фактические record/retrieval/hash contracts, затем превращает D1 в исполнимый discovery-лист. MG-D2 открывается только после accepted D1 и G-08.D1 PASS; MG-D3 — только после accepted D2 и G-08.D2 PASS. Каждый materialized leaf заранее называет вопрос, synthetic fixture boundary, exact reproduction procedure, expected observation, evidence path и decision gate.
- Дополнительный spike не появляется автоматически: только новое evidence с material impact на результат/scope/contract/risk разрешает replan/review.
- Consumers: Root G-08 Contract Closure, затем B; повторное исследование следующего дерева.
- Producer gate / evidence после materialization: каждый Dk воспроизводим и имеет отдельный manifest `evidence → affected contract/path → category → TODO/backflow → exact A revision → superseded/rerun → verdict`; G-08.Dk принят до следующего листа, G-08.FINAL — до B.
- Допустимая параллельность: `D1 → G-08.D1 → D2 → G-08.D2 → D3 → G-08.D3`; B и C не стартуют до G-08.FINAL PASS.
- Порядок интеграции: после A и до B; D не изменяет production runtime. При contract drift Root возвращает A, а не разрешает B обходить evidence.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| D1 | 6% | Один synthetic Markdown section и одна synthetic TSV row проверены против фактического record contract A | MG-D1 после A PASS; G-08.D1 до D2 |
| D2 | 7% | Tantivy проверен на точном identifier и русском FTS без выбора production ranking | MG-D2 после D1 + G-08.D1 PASS; G-08.D2 до D3 |
| D3 | 7% | SQLite проверен на add/change/delete/unchanged по фактической hash semantics A | MG-D3 после D2 + G-08.D2 PASS; G-08.D3 и FINAL до B |

Сумма весов листьев равна весу ветки из `Описание задачи.md`.

## Definition of Done

- До MG-D1 ветка не исполнима и не может быть назначена worker; после последовательной materialization и checkpoints приняты ровно D1–D3 на одной exact A revision.
- Каждый spike имеет самостоятельный exact command и evidence, не зависит от runtime mocks и не выдаётся за production implementation.
- Формулировка `заменить механизм` сама не определяет переход: adapter-only/internal при неизменном public/ownership contract создаёт future TODO и может продолжить D; public drift требует A remediation/replan; ownership/DAG/core drift требует replan/review.
- После любой A′ всё прежнее D evidence помечено `SUPERSEDED`, а D начинается с D1. Повторный drift того же checkpoint после одной remediation или потребность четвёртого spike останавливает ветку по recovery G-08.

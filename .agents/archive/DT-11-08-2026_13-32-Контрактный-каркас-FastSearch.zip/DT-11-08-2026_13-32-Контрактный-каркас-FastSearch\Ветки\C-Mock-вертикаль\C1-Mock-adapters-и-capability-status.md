<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист C1 — Mock adapters и capability status

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch / Leaf ID: `C / C1`
- Вес задачи: `14%`

## Исполнимый лист — MG-C1 открыт 11.08.2026 17:11

- Exact base: `700a110b47183c41849a8f817705219835b4178a`; contracts A, D G-08.FINAL и B oracle/goldens приняты. C обязан использовать B oracle без изменения assertions или fixtures.
- Наблюдаемый результат: `src/adapters/mock/**` реализует `SourcePort`, `StateStore`, `LexicalRetrieval`, `CodeMapPort`, `SymbolPort` и явно unavailable `VectorRetrieval`; `src/application/**` собирает эти mocks, status маркирует mock/unavailable, а `tests/runtime_mock_contracts.rs` запускает accepted B oracle на runtime composition.
- Ownership: `src/adapters/mock/**`, `src/application/**`, только module-registration/composition/re-export wiring C-owned modules в `src/lib.rs`, `tests/runtime_mock_contracts.rs`, `tests/support/c/**`. Domain/ports A, B files/assertions/fixtures, Cargo и `src/main.rs` read-only.
- RED: targeted runtime-contract test обязан сначала не компилироваться или падать из-за отсутствующей runtime mock composition; сохранить exact command/non-zero exit.
- GREEN: минимальная in-memory runtime composition удовлетворяет B oracle и сообщает `BackendKind::Mock`/`Unavailable`, не `Real`; `cargo test --test runtime_mock_contracts` проходит.
- REFACTOR: отделить composition от adapter storage без изменения B oracle/golden result; повторить targeted GREEN.
- PASS: targeted runtime contract, B tests, `cargo fmt --check`, `cargo clippy --workspace --all-targets -- -D warnings`, `cargo test --workspace --all-targets`, master review. Любое изменение A/B boundary или скрытие mock state — stop/backflow к Root.

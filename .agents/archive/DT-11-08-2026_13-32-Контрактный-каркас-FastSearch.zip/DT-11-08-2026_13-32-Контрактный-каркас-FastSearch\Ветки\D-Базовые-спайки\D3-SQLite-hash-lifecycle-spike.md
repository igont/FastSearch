<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист D3 — SQLite hash lifecycle spike

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch / Leaf ID: `D / D3`
- Вес задачи: `7%`

## Dormant outline

- Текущее состояние: discovery-лист не материализован и не назначается worker до MG-D3 после accepted D2 и G-08.D2 PASS.
- Dependency/base rule: exact accepted D2 revision плюс фактические stable identity/content hash semantics A задают base.
- Наблюдаемый результат: disposable SQLite experiment воспроизводимо различает add, unchanged, change и delete либо выдаёт точное ограничение/решение о замене.
- Ownership после materialization: изолированный `spikes/**`, временные synthetic data и `evidence/spikes/**`; production storage/manifests read-only.
- Exclusions: schema, commands и transition representation определяются после D2; migrations, concurrency, crash recovery и performance вне scope.
- Materialization gate: Root фиксирует synthetic transition sequence, clean-database reproduction, cleanup evidence и decision gate `подходит | подходит с ограничениями | заменить`; manifest связывает evidence с exact A revision, G-08.D3 классифицирует result, затем G-08.FINAL сверяет все три entries до B.
- Stop/backflow: adapter-only storage replacement при неизменном public contract допускает G-08.FINAL с exact future TODO. Stable-ID/hash/state public drift блокирует B и запускает A2 causal remediation; после A′ D1–D3 evidence `SUPERSEDED`, D restart с D1. Ownership/DAG/core drift блокирует B и требует owner-specific material replan/review без A2; restart D только при изменении A revision. Cleanup failure блокирует D3 PASS.

## Materialized execution — 11.08.2026 16:20

- Exact A revision: `01e557899e5be846bd59f233edf81270dda89da0`; D1/D2 accepted and classified `adapter-only/internal` without public drift.
- Question: подтверждает ли isolated SQLite experiment add → unchanged → change → delete на stable identity и content hash A без выбора production state-store API?
- Synthetic boundary and reproduction: отдельный locked spike package `spikes/d3-sqlite-hash-lifecycle/**`, одна synthetic record identity и три deterministic payloads; runner создаёт/удаляет database только under ignored `target/d3-sqlite-hash-lifecycle/**`. RED нарушает lifecycle invariant and exits nonzero; GREEN records each transition and cleanup, writes stable evidence under `evidence/spikes/d3-sqlite-hash-lifecycle/**`, and replay leaves tracked files clean.
- Required observations: new hash adds once; equal payload is unchanged; changed payload updates exactly once; delete removes identity; stable ID and content-hash values are preserved at boundary; database cleanup is proven. Migrations, concurrency, crash recovery and performance are out of scope.
- Decision: adapter-local schema/transaction/cleanup detail may create exact future TODO; public stable-ID/hash/state mismatch is public drift to G-08.D3/A2; ownership/DAG/core goes to Root replan. Manifest uses the standard per-spike fields and candidate changes only `spikes/**`, `evidence/spikes/**`.

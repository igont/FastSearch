<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки C — Mock вертикаль

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch ID: `C`
- Base revision: exact integration revision, созданная Root после принятия A, D, G-08.FINAL и B

## Текущий горизонт

Ветка находится в состоянии `DORMANT OUTLINE`: accepted A+D+B и G-08.FINAL PASS ещё отсутствуют, поэтому C не фиксирует composition, scenarios, commands или outputs. Наблюдаемый результат после будущего исполнения — runtime mocks проходят post-spike oracle B, а единственный executable `src/main.rs` и protocol-independent internal facade используют один application core с честным mock/unavailable status.

## Ownership

- После соответствующего MG-C1/MG-C2 разрешено изменять: `src/application/**`, `src/adapters/mock/**`, последовательно переданный A единственный `src/main.rs`, только composition/module-registration/re-export wiring C-owned modules в `src/lib.rs`, `tests/runtime_mock_contracts.rs`, `tests/cli_mock_flow.rs`, `tests/agent_facade_mock_flow.rs`, `tests/support/c/**`.
- Только чтение: contracts A, oracle/fixtures B, `ROADMAP.md`, внешние описания.
- Запрещено изменять: root Cargo manifests, domain/ports declarations/exports/semantics в `src/lib.rs` без backflow к A, expected assertions/fixtures B без backflow к B, `src/bin/**`, второй binary/library и path-include source, `spikes/**`, `evidence/spikes/**`, `.agents/**`.

## Зависимости и интеграция

- Materialization gate MG-C1: только после accepted/merged A+D+B и G-08.FINAL PASS Root фиксирует exact revision, post-spike ports и oracle/fixtures, подтверждает заморозку A и последовательную передачу C writer-права на `src/main.rs` и composition/export wiring в `src/lib.rs`, затем превращает C1 в исполнимый лист. MG-C2 открывает C2 только после accepted C1.
- Каждый materialized code-лист C обязан отдельно задать причинный RED, минимальный GREEN, REFACTOR с повторным GREEN и итоговый PASS с G-02–G-05 на exact candidate. Материальное изменение результата/scope/ownership/DAG/contract/gate требует replan/review.
- Consumers: Root final gates и будущий handoff.
- Producer gate / evidence после materialization: runtime mocks проходят accepted oracle; единственный executable и internal facade дают принятый mock-flow/status; G-01–G-05.
- Допустимая параллельность: C1 предшествует C2; D уже принят и G-08 закрыт до старта C.
- Порядок интеграции: после A, D, G-08.FINAL и B; C является последней product-веткой первого дерева.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| C1 | 14% | Runtime mocks реализуют post-spike ports, проходят oracle B и раскрывают mock/unavailable status | MG-C1 после A+D+B и G-08.FINAL PASS; затем leaf-level TDD gates |
| C2 | 16% | Единственный executable и internal facade исполняют принятый mock-flow через один core | MG-C2 после C1 PASS; затем leaf-level TDD gates и G-05 |

Сумма весов листьев равна весу ветки из `Описание задачи.md`.

## Definition of Done

- До accepted A+D+B и G-08.FINAL PASS ветка не исполнима и не может быть назначена worker.
- После materialization G-01–G-05 PASS на exact candidate; mock runtime невозможно принять за real capability.
- Сквозной поток использует application core и ports, а не предопределённый ответ верхнего уровня.
- Контракты A и oracle B не изменены молча; все необходимые актуализации оформлены через точный backflow/TODO.

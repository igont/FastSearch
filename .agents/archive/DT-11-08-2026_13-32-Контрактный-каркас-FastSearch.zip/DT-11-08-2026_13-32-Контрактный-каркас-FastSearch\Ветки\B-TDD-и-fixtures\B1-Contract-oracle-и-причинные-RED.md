<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист B1 — Contract oracle и причинные RED

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch / Leaf ID: `B / B1`
- Вес задачи: `12%`

## Исполнимый лист — MG-B1 открыт 11.08.2026 16:32

- Exact base: `b44ac8dc65c4b916a2905e502201c0ae1e634ce3`; A revision для D1–D3: `01e557899e5be846bd59f233edf81270dda89da0`; accepted evidence не содержит `SUPERSEDED`, public или ownership drift.
- Фактический public input: `SourcePort`, `StateStore`, `LexicalRetrieval`, `VectorRetrieval`, `CodeMapPort`, `SymbolPort`, `AgentSurface`; `CanonicalRecord`, `SearchQuery`, `SearchResponse`, `CapabilityStatus` и structured `FastSearchError` из A. D подтверждает только будущие adapter TODO: `TODO[D1-ADAPTER-NORMALIZATION]`, `TODO[D2-TANTIVY-SCHEMA-ANALYZER]`, `TODO[D3-SQLITE-LIFECYCLE-TRANSACTION-CLEANUP]`.
- Наблюдаемый результат: `tests/support/b/**` содержит один переиспользуемый behavioral oracle, а `tests/contract_ports.rs` доказывает на test-local reference doubles source/state/lexical/agent happy и unavailable/error boundary. C сможет подключить тот же oracle без дублирования assertions.
- Ownership: только `tests/contract_ports.rs`, `tests/support/b/**`. Cargo manifest и production source read-only; fixtures/golden и runtime C не трогать.
- RED: до product-изменения создать targeted oracle, который не компилируется или падает из-за отсутствующей test-local oracle boundary; сохранить точную команду и ненулевой exit как causal evidence.
- GREEN: добавить минимальные test-local reference doubles и oracle без изменения `src/**`; `cargo test --test contract_ports` проходит.
- REFACTOR: убрать дублирование assertions в helper/oracle при неизменном наблюдаемом contract; повторить targeted GREEN.
- PASS: `cargo fmt --check`, `cargo clippy --workspace --all-targets -- -D warnings`, `cargo test --workspace --all-targets`, targeted oracle; master review. Любая необходимость менять A public contract — stop, classification/backflow к Root; TDR content не читать.

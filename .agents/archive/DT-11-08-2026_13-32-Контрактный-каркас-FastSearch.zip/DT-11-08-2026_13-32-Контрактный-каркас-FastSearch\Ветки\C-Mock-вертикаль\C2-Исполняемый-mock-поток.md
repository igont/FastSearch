<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист C2 — Исполняемый mock поток

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch / Leaf ID: `C / C2`
- Вес задачи: `16%`

## Исполнимый лист — MG-C2 открыт 11.08.2026 17:28

- Exact base: `f7d517104c6a81ec9c3adc310f431329d2db6ae2`; C1 runtime composition принята. `src/main.rs` и C-owned facade обязаны вызывать один `application` core, не дублировать predetermined response.
- Наблюдаемый результат: executable принимает минимальный mock command/flow и печатает результат со статусом mock/unavailable; protocol-independent internal facade выполняет те же `search/get/related/status` через тот же runtime. `tests/cli_mock_flow.rs` и `tests/agent_facade_mock_flow.rs` доказывают это и запускают B oracle/golden там, где применимо.
- Ownership: `src/application/**`, `src/main.rs`, C-owned module-registration/composition/re-export wiring в `src/lib.rs`, `tests/cli_mock_flow.rs`, `tests/agent_facade_mock_flow.rs`, `tests/support/c/**`. Domain/ports A, B fixtures/assertions, Cargo, `src/bin/**` и второй target запрещены.
- RED: targeted CLI/facade test обязан сначала не компилироваться или падать из-за отсутствующего executable/facade mock flow; сохранить exact non-zero command.
- GREEN: минимальный CLI и facade делегируют в один application core и явно выводят mock/unavailable status; targeted CLI/facade tests проходят.
- REFACTOR: устранить дублирование core-flow между surfaces при неизменном output и oracle; повторить targeted GREEN.
- PASS: targeted C2 tests, B oracle/golden, `cargo fmt --check`, `cargo clippy --workspace --all-targets -- -D warnings`, `cargo test --workspace --all-targets`, `cargo metadata --no-deps --format-version 1` (ровно один lib и bin), `cargo run --quiet -- <accepted mock command>`, master review и G-05. Любой разный core semantics/скрытый mock status — stop/backflow к Root.

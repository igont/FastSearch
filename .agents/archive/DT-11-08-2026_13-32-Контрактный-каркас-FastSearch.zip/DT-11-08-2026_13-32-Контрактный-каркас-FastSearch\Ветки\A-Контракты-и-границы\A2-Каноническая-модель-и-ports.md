<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист A2 — Каноническая модель и ports

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch / Leaf ID: `A / A2`
- Вес задачи: `15%`

## Наблюдаемое изменение

- Baseline: accepted A1 candidate содержит собираемый package, но предметные типы и архитектурные ports отсутствуют.
- После листа: каноническая запись, search/get/related/status boundary, structured errors, capability status и заменяемые ports представлены настоящими типами и покрыты tests.

## Целевое состояние листа

Core способен без привязки к конкретным библиотекам представить документы, registry rows, будущие maps и symbols через общую запись со stable identity, source locator, searchable content, metadata, explicit relations и content hash. Search modes `BALANCED`, `CURRENT`, `DESIGN` существуют как контракт, но ranking ещё не реализуется. Ports позволяют подставлять test-local, runtime mock и будущие real adapters. Capability state честно различает доступность и тип backend.

## Границы состояния

- В scope: `src/domain/**`, `src/ports/**`, относящиеся unit/compile-time tests и минимальные exports общего core.
- Сохраняется: library не зависит от Tantivy, SQLite, Tree-sitter, MCP SDK или embedding provider; конкретные algorithms остаются за adapters.

## Preconditions

- A1 принят на exact candidate; package topology и quality gates стабильны.

## Наблюдаемые сценарии

- Одна запись может описать синтетический Markdown section и TSV row без потери source path/locator, metadata и stable identifier.
- Status не выдаёт mock либо unavailable backend за real; invalid identifier, unsupported source и unavailable capability представлены структурированно, а не паникой или строковым ad hoc error.

## Definition of Done

- D может проверить canonical-record, exact/FTS и hash-lifecycle гипотезы только через публичные границы A без изменения production source.
- Плановая замена ports из `ROADMAP.md` окончательно допускается downstream только после D1–D3 и G-08.FINAL; public drift возвращается A, а не передаётся B как TODO.
- В domain/ports отсутствует реализация реальных или mock adapters.

## Операционная проверка

- Test oracle / причинный RED: новые contract-focused tests сначала не компилируются или падают, потому что record/search/status/error types и ports отсутствуют на accepted A1.
- GREEN gate: минимальные domain/ports types и invariants делают тот же targeted oracle GREEN без добавления adapters.
- REFACTOR gate: после выравнивания names/exports и удаления дублирования тот же targeted oracle повторно остаётся GREEN; public behavior и capability semantics не меняются.
- PASS gate exact candidate: targeted domain/ports oracle и G-02–G-04 PASS; exact TODO scan подтверждает отсутствие блокирующей актуализации текущего contract.
- Окружение и prerequisites: accepted A1 revision, Rust/Cargo `1.97.1`.
- Evidence: отдельные журналы причинного RED, минимального GREEN, повторной GREEN-проверки после REFACTOR и PASS; список public contracts и exact candidate revision.
- Unverified areas: пригодность contracts для выбранных record/retrieval/state mechanisms; это проверяет D до B без молчаливого изменения A.

## Post-spike remediation

- Public-contract mismatch Dk является причинным RED именно для затронутого contract A2; Root фиксирует affected type/method/field/behavior и exact D evidence. Чистый ownership/DAG/core drift не является RED A2 и направляется фактическому owner через material replan/review.
- Под следующей Plan version новый candidate A′ обязан дать targeted GREEN, сохранить его после REFACTOR и пройти G-02–G-04, TODO scan и master review.
- Accepted A′ инвалидирует всё ранее принятое D evidence; Root помечает его `SUPERSEDED` и запускает D1 заново, чтобы G-08.FINAL связал D1–D3 с одной A revision.
- Повторный drift того же checkpoint после одной remediation не запускает бесконечный A↔D цикл, а возвращается Root как `ESCALATION_REQUIRED`.

## Условия остановки

- Вернуть Root, если исходные описания требуют взаимоисключающих полей/семантики, если port невозможно проверить через три согласованные spike-гипотезы либо требуется расширить их scope.

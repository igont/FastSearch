<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист B2 — Golden fixtures и сквозной тестовый контур

- Task ID: `FASTSEARCH-DT1`
- Plan version: `PV-2`
- Branch / Leaf ID: `B / B2`
- Вес задачи: `13%`

## Исполнимый лист — MG-B2 открыт 11.08.2026 16:48

- Exact base: `63f2a5488bb2155f99686c373ef3c7bfa8d66b66`; B1 oracle и post-spike A contracts приняты. Внешний contract ограничен synthetic records: happy exact/lexical result, no-hit, structured unavailable/error и capability status `Mock`/`Unavailable`.
- Наблюдаемый результат: UTF-8 fixtures и golden expectations под `tests/fixtures/**`/`tests/golden/**`, а `tests/golden_mock_flow.rs` проверяет B reference doubles через уже принятый oracle без выбора SQLite/Tantivy/parser/ranking detail.
- Ownership: только `tests/golden_mock_flow.rs`, `tests/fixtures/**`, `tests/golden/**`, `tests/support/b/**`; `src/**`, Cargo и future runtime C read-only.
- RED: targeted golden test обязан сначала не компилироваться или падать из-за отсутствующих synthetic fixture/golden boundary; сохранить exact command и non-zero exit.
- GREEN: добавить минимальные UTF-8 fixtures, expected golden и adapter-neutral reference flow; `cargo test --test golden_mock_flow` проходит.
- REFACTOR: вынести повторяемые fixture/golden assertions в B helper при неизменном targeted GREEN.
- PASS: targeted test, `cargo fmt --check`, `cargo clippy --workspace --all-targets -- -D warnings`, `cargo test --workspace --all-targets`, master review. Изменение A public contract или потребность в технологии — stop/backflow к Root; TDR content не читать.

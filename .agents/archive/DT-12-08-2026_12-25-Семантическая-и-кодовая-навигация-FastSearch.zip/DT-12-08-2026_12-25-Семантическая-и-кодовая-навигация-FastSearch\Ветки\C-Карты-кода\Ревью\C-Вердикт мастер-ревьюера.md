<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Вердикт мастер-ревьюера ветки C

Файл append-only изменяет только мастер-ревьюер.

## Итерация 1

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-8`
- Scope: `C1 — src/adapters/maps.rs; tests/c1_cfmap_lifecycle.rs`
- Candidate revision: `5bebf527e17c270e9f9c2d8eda7ee62386a0dfb7`
- Previous revision: `d9bddda5a3c18af4dbe5d83e24c0a52d11f2a6ce`
- Recheck scope: `n/a`
- Verdict: `REWORK`
- Specialist reviews used: `file-boundary security reviewer — REWORK`
- Evidence states: `SCOPED PASS для fmt/all-targets locked/clippy; PRODUCTION UNVERIFIED для безопасной файловой записи`

### Blocking findings

- `[P1]` `contained_map_path` проверяет canonical containment, но `regenerate` затем отдельно читает и пишет тот же pathname. Подмена файла или родительской директории symlink/junction между проверкой и `fs::write` может вывести запись за configured root. Нужны safe no-follow/handle-relative запись, повторная identity/containment проверка и атомарная замена в trusted directory; добавить negative/race test там, где платформа позволяет.
- `[P1]` Ненадёжная файловая граница не ограничивает размер входного map, число файлов, глубину обхода и размер `derived_body`: `fs::read`, `read_to_string`, рекурсивный обход и сбор replacement допускают OOM/CPU/stack DoS. Нужны явные bounded limits до allocation/recursion и tests, что over-limit возвращает ошибку без записи.

### Non-blocking findings

- `[P2]` `referenced_source_exists` определяет `CURRENT` через `root.join(relative).is_file()`, который следует symlink/reparse point; AUTO map может быть current по source за root. Канонизировать source и требовать containment либо отвергать reparse source.
- План C1 требует observable rename lifecycle, однако regression suite доказывает delete/reopen, но не rename. После исправления P1 добавить отдельный causal lifecycle oracle или зафиксировать плановый backflow.

### Проверено

- Exact candidate является потомком exact base; `git diff --name-status` содержит только `src/adapters/maps.rs` и `tests/c1_cfmap_lifecycle.rs`; C2 не затронут.
- Causal RED задокументирован в `C-Процесс ветки.md`: на base отсутствуют `CodeMapSource` и `RegenerationOutcome`; GREEN проверен на exact candidate.
- На exact candidate успешно выполнены `cargo fmt --check`, `cargo test --workspace --all-targets --locked` (48 tests) и `cargo clippy --workspace --all-targets --locked -- -D warnings`.
- Позитивно: locator отвергает absolute/traversal/non-Normal components; snapshot пропускает directory symlink и проверяет containment canonical file; CURATED и invalid AUTO не доходят до записи; test проверяет сохранение CURATED bytes и отсутствие записи при invalid derived body.

### Переиспользовано без повторной проверки

- Нет.

### Не проверено и residual risk

- Исполняемая гарантия single-classification остаётся покрытой existing A2 contract test, но C1 не меняет adapter registry/production composition; C2 намеренно не проверялся.
- Пока P1 не закрыты, production `regenerate` не соответствует required filesystem security boundary; broad acceptance запрещена.

## Итерация 2

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-8`
- Scope: `C1 delta — закрытие P1/P2 файловой границы`
- Candidate revision: `85ed0262aeb16994e697665f0f1ba46e467d05fe`
- Previous revision: `5bebf527e17c270e9f9c2d8eda7ee62386a0dfb7`
- Recheck scope: `лимиты, symlink containment, atomic replacement`
- Verdict: `REWORK`
- Specialist reviews used: `переиспользован file-boundary review; master delta inspection`
- Evidence states: `SCOPED PASS для лимитов и exact gates; PRODUCTION UNVERIFIED для TOCTOU/проверки source`

### Blocking findings

- `[P1, не закрыт]` `replace_map_atomically` создаёт temp и выполняет rename по pathname после первоначального canonical containment. Это делает content replacement recoverable при локальном I/O failure, но не фиксирует path identity: concurrent actor всё ещё может заменить target либо parent directory reparse/symlink между `contained_map_path` и create/rename. Нужен handle-relative/no-follow протокол либо identity revalidation непосредственно перед commit с безопасным отказом; текущий static symlink test не воспроизводит race.

### Non-blocking findings

- `[P2, не закрыт]` `referenced_source_exists` по-прежнему использует `root.join(relative).is_file()` без canonical containment/reparse rejection; AUTO metadata может объявить `CURRENT` по source вне root через symlink.
- `[P2, закрыт]` Явные limits: 1 MiB map, 64 KiB derived body, 1024 files, depth 16; размер map проверяется до штатного read, отдельный over-limit test сохраняет исходный файл.

### Проверено

- New candidate является потомком previous candidate и его diff ограничен C1 двумя файлами.
- На exact `85ed0262` успешно выполнены `cargo fmt --check`, `cargo test --test c1_cfmap_lifecycle --locked` (6 tests), `cargo test --workspace --all-targets --locked` (50 tests), `cargo clippy --workspace --all-targets --locked -- -D warnings`.
- New Windows negative test подтверждает, что уже существующая внешняя symlink map не проходит `contained_map_path` и external bytes не изменяются; cleanup temp выполняется при ошибке replacement.

### Переиспользовано без повторной проверки

- Исходная RED/GREEN причинность, schema/lifecycle assertions и scope baseline из Итерации 1: delta не меняет эти контракты.

### Не проверено и residual risk

- C2 не проверялся. Rename lifecycle по-прежнему не материализован отдельным oracle.
- `ensure_bounded_map` делает metadata/read по pathname, поэтому конкурентная подмена может также обойти size check; это входит в тот же незакрытый P1 trusted-file-boundary.

## Итерация 3

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-15`
- Scope: `C1 R2 — read-only authority rework`
- Candidate revision: `1a35bc83d131b6b38cb91f7bb720170fc89730eb`
- Previous revision: `85ed0262aeb16994e697665f0f1ba46e467d05fe`
- Recheck scope: `удаление write API, SQLite authority, external-source contract`
- Verdict: `REWORK`
- Specialist reviews used: `master bounded delta review`
- Evidence states: `SCOPED PASS для write-boundary removal и lifecycle gates; PRODUCTION UNVERIFIED для declared external-symlink rejection`

### Blocking findings

- `[P1]` PV-15 Definition of Done требует, чтобы external-symlink source был rejected. `referenced_source_is_current` лишь возвращает `false`, если `root.join(relative)` canonicalizes outside root; `parse_map_file` вследствие этого публикует valid AUTO snapshot со state `STALE`, а не отвергает source. New test `external_source_locator_is_rejected...` проверяет только `../outside.md`, не external symlink. Либо реализовать explicit rejection canonicalized external source с negative symlink test, либо Root должен изменить accepted observable contract; до этого PASS невозможен.

### Non-blocking findings

- `[P2, закрыт]` Product `maps.rs` больше не содержит `regenerate`, `fs::write`, `OpenOptions`, `File::create`, `write_all` или cfmap AUTO write path. Тем самым снят предыдущий pathname-write TOCTOU.
- `[P2, закрыт]` AUTO/CURATED snapshot повторно reconcile через existing `SqliteStateStore`; тест подтверждает idempotent `Added` → `Unchanged`, сохранение исходных authored bytes и rename/delete/reopen lifecycle.

### Проверено

- Exact candidate является потомком R1 candidate; delta ограничен `src/adapters/maps.rs` и `tests/c1_cfmap_lifecycle.rs`.
- На exact candidate успешно выполнены `cargo fmt --check`, `cargo test --test c1_cfmap_lifecycle --locked` (5 tests), `cargo test --workspace --all-targets --locked` (50 tests) и `cargo clippy --workspace --all-targets --locked -- -D warnings`.
- `maps.rs` read-only; limits и all-or-nothing invalid snapshot path сохраняются. `referenced_source_is_current` canonicalizes existing source и не объявляет external symlink CURRENT, но это не эквивалент planned reject.

### Переиспользовано без повторной проверки

- Предыдущие P1 pathname writer и size-race закрыты устранением самой write authority; их точечные write-path checks не повторялись как неприменимые.

### Не проверено и residual risk

- C2 не проверялся. До exact external-symlink negative contract отсутствует доказательство required rejection; test с `..` не заменяет symlink/reparse boundary.

## Итерация 4

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-15`
- Scope: `C1 R3 — exact external-symlink rejection`
- Candidate revision: `4695ec52cbfd8129a6152f3f6347fd45171f466d`
- Previous revision: `1a35bc83d131b6b38cb91f7bb720170fc89730eb`
- Recheck scope: `единственный P1 Iteration 3`
- Verdict: `PASS`
- Specialist reviews used: `master bounded delta review`
- Evidence states: `SCOPED PASS`

### Blocking findings

- Нет.

### Non-blocking findings

- Linker warning в unrelated `d1_tree_sitter_identity` при all-targets test остаётся вне C1 diff и не является clippy warning/failure.

### Проверено

- Exact candidate является потомком R2 candidate; delta ограничен C1 `maps.rs` и lifecycle test.
- `referenced_source_state` различает missing source (`STALE`) и existing source, canonicalized outside configured root (`InvalidContent`); non-file source также reject.
- Exact Windows directory-junction test успешно materialized и доказал, что `linked/source.md` вне root останавливает полный snapshot без partial result.
- На exact candidate успешно выполнены `cargo fmt --check`, `cargo test --test c1_cfmap_lifecycle --locked` (6 tests), `cargo test --workspace --all-targets --locked` (51 tests) и `cargo clippy --workspace --all-targets --locked -- -D warnings`.

### Переиспользовано без повторной проверки

- Read-only authority, отсутствующий cfmap write API, SQLite idempotence и rename/delete/reopen evidence из Iteration 3: R3 меняет только source-state admission.

### Не проверено и residual risk

- C2 намеренно не проверялся; C1 принят в declared scope. Runtime source filesystem остаётся inherently mutable between scan operations, но C1 не пишет files и external canonical source перед публикацией snapshot проверяется.

## Итерация 5

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-17`
- Scope: `C2 — src/adapters/maps.rs; tests/c2_related_navigation.rs`
- Candidate revision: `282f7caeb36c2489925b39d433b4d4a23fa317de`
- Previous revision: `56ad9f2fcfa43fcf0a90bebe5d6d5c4bd2f8e6b1`
- Recheck scope: `полный первый review C2: explicit relation projection, D2 identity и lifecycle oracle`
- Verdict: `REWORK`
- Specialist reviews used: `нет; Rust/maps scope проверен master review`
- Evidence states: `SCOPED PASS для direct deterministic traversal, exact D2-symbol identity, provenance и Rust gates; PRODUCTION UNVERIFIED для обязательного rename replay`

### Blocking findings

- `[P1]` C2 DoD и final gate требуют combined map→symbol replay после `reopen/delete/rename` на exact base. `tests/c2_related_navigation.rs` покрывает direct found document/map/symbol targets, cycle, dangling, delete и recreate/reopen, но не вызывает `fs::rename` и не проверяет relation oracle после rename. Поэтому stable map locator/ID и D2 target identity не доказаны на обязательном rename lifecycle; C1 rename-only evidence не заменяет C2 combined replay. Добавить причинный rename scenario в C2 relation suite и повторить exact target/provenance/order oracle после него.

### Non-blocking findings

- Windows linker messages `#[warn(linker_messages)]` появляются в full workspace test, но не являются warning/error от clippy и находятся вне C2 diff.

### Проверено

- Exact candidate является потомком exact C2 base; worktree чист; diff ограничен `src/adapters/maps.rs` и `tests/c2_related_navigation.rs`, `git diff --check` чист.
- На base отсутствуют `CodeMapRelated`, `related_maps` implementation и C2 test target; candidate fixture обращается к новому concrete adapter. Это подтверждает заявленную причинную unavailable state до C2; на candidate targeted `cargo test --test c2_related_navigation --locked` — 3 GREEN.
- `CodeMapRelated` индексирует IDs однозначно, принимает только `RecordKind::CodeMap` как source, берёт relations ровно один раз, сортирует через `BTreeSet`, не обходит cycle рекурсивно и возвращает typed `NotFound` для dangling. Возвращённая запись сохраняет canonical target identity и добавляет explicit-map provenance без compiler/reference claim.
- Targeted oracle строит symbol target через exact `SymbolSource`, проверяет document/map/symbol direct targets, D2 stable ID, 5 deterministic repeats, dangling/cycle/delete/reopen и stale-source refusal.
- На exact candidate успешно выполнены `cargo fmt --check`, `cargo test --workspace --all-targets --locked` и `cargo clippy --workspace --all-targets --locked -- -D warnings`.

### Переиспользовано без повторной проверки

- C1 read-only `.cfmap.md` admission, SQLite authority и external-source boundary из Iteration 4: C2 их не изменяет.

### Не проверено и residual risk

- До P1 combined map→symbol lifecycle после rename не доказан; `PASS` ветки C и открытие E запрещены. Другие C2 direct-relation cases имеют scoped evidence.

## Итерация 6

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-17`
- Scope: `C2 R1 — закрытие P1 Iteration 5`
- Candidate revision: `b622526b72ab811698545247511849386d39255d`
- Previous revision: `282f7caeb36c2489925b39d433b4d4a23fa317de`
- Recheck scope: `combined map→exact-D2-symbol replay после rename/delete/reopen`
- Verdict: `PASS`
- Specialist reviews used: `master bounded delta review`
- Evidence states: `SCOPED PASS`

### Blocking findings

- Нет.

### Non-blocking findings

- Windows linker messages `#[warn(linker_messages)]` при test build не являются clippy warning/error и вне C2 delta.

### Проверено

- New candidate является потомком Iteration 5 candidate; diff ограничен одним C2 test-only файлом, product/public/shared paths не менялись, `git diff --check` и worktree чисты.
- Новый oracle materializes exact D2 symbol IDs через `SymbolSource`, создаёт map→symbol relations, затем выполняет `fs::rename`, delete и recreate/reopen. Он доказывает изменение map ID после rename, сохранение reopened map ID, и сохранение ordered symbol IDs с explicit-map provenance на каждом replay.
- Targeted `cargo test --test c2_related_navigation --locked` — 4 GREEN; exact candidate также прошёл `cargo fmt --check`, `cargo test --workspace --all-targets --locked --no-fail-fast` и `cargo clippy --workspace --all-targets --locked -- -D warnings`.

### Переиспользовано без повторной проверки

- Iteration 5 direct traversal, causal unavailable baseline, D2 identity, deterministic order, dangling/cycle/stale and source/delete/reopen checks: R1 изменяет только недостающий rename lifecycle oracle.

### Не проверено и residual risk

- C2 принят в declared maps-only scope; E runtime composition и cross-branch final integration не входят в этот leaf. Runtime filesystem remains mutable between scans, но C2 read-only и не публикует compiler/resolved-reference claims.

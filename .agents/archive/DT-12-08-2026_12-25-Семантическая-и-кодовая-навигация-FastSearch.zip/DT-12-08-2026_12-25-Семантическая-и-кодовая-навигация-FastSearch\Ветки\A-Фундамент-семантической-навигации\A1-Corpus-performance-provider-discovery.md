<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист A1 — Corpus performance provider discovery

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-28`

- Состояние bounded amendment: `MATERIALIZED / RUNNING`; exact base `879bafeddf955292cc29553569ddccd7295e5aca`; only accepted performance evidence/manifest and amendment tests may change, product/dependencies remain forbidden.
- Branch / Leaf ID: `A / A1`
- Вес задачи: `12%`
- Состояние: `MATERIALIZED / RUNNABLE AFTER OWNER START`

## Наблюдаемое изменение

- Baseline: exact `135572ff45321005ca75c6bc3624e1525f99bce7`; document corpus работает, но release performance/quality, code roots/languages, `.cfmap.md`, multi-root collisions и embeddings constraints не имеют принятого evidence.
- После листа: существует один reviewed foundation passport, достаточный для точной материализации A2 и bounded adapter leaves без угадывания provider, schema, identity или thresholds.

## Целевое состояние листа

Working area содержит воспроизводимые fixtures/procedures и evidence, но product behavior не меняется. Любой corpus path передаётся параметром. Corpus/profile hashes и logical root IDs позволяют повторить измерения на другой папке. Relevance oracle фиксируется до реализации. Provider matrix отделяет local/offline и external-egress варианты; unsupported/unknown остаётся видимым gap.

## Границы состояния

- В scope: inventory document/code roots; минимум текущий FastSearch Rust root и переданный Obsidian/Python representative root; 24+ logical-selector labels в scope-labeled quality sections; numeric performance contract; одна accepted legacy-to-named-root transition; safe service/evidence contract; `.cfmap.md` fixture needs; Tree-sitter grammar/dependency applicability; provider/model/store/license/privacy/fallback matrix; exact A2 dependency/module/admission decision map.
- Writable: `evidence/dt3/foundation/**`, `tests/fixtures/dt3/**`, `spikes/dt3-foundation/**`.
- Сохраняется: `src/**`, root `Cargo.*`, DT2 tests/evidence/roadmap и target-vault authored files read-only.
- Runtime service writes: только новый exact `<document-root>/.cfknowledge/dt3-a1-<run-id>` либо isolated service root вне всех input roots. До write canonical path не равен input root, не является его предком; descendant разрешён только для exact `.cfknowledge/dt3-a1-<run-id>`, и ни один path не выходит из allowed target через reparse/junction/symlink. Existing `.cfknowledge/state.sqlite`/`lexical` не изменять.

## Preconditions

- Новая явная команда владельца на исполнение DT3.
- Root создаёт integration и A worktrees от повторно проверенного clean `main`; baseline ancestor фиксируется operationally.
- Runtime inputs передаются как `-DocumentRoot`, `-CodeRoot`, `-ServiceRoot`; committed evidence пишет только logical root IDs, relative locators/selectors, ranks, hashes, timings и error classes — без absolute paths, source snippets, raw corpus и secrets.
- External network/data egress запрещены до owner decision; provider research использует official docs и synthetic/hand-authored text.

## Наблюдаемые сценарии

- Повторить DT2 rebuild/update/search/status на parameterized representative root; зафиксировать release build, hardware/toolchain/cache profile, corpus logical identity, file/record counts, service size, peak memory и не менее пяти cold/warm runs. На этом evidence до dependent implementation принять numeric absolute budgets и DT2/A1 regression ratios для index/update/rebuild, warm query, service size и peak memory.
- Сменить root на отдельный fixture root и доказать отсутствие hardcode/identity leakage; отдельно смоделировать одинаковые relative paths в двух named roots.
- Сформировать минимум 24 query rows: exact/lexical, paraphrase, doc→map, symbol, no-hit и vector-unavailable/fallback. Каждая row ссылается на invariant `logical_root_id + relative_locator + selector_kind/value`, а не на future wire `StableId`, и содержит intent, section owner/gate, `top_k`, `required_rank_max`, expected/must-not selectors, source evidence и review status.
- До B1 зафиксировать `quality-contract.md` с immutable sections: document/vector (`A1/B1`), map (`C1/C2`), symbol (`D1/D2`) и fusion (`E1`). Для каждой section фиксируются inclusion gate, formulas, numeric thresholds, required-hit/must-not и repeats. До owner gate unavailable section имеет `NOT_APPLICABLE_UNTIL_<gate>` и не входит как zero в ранний aggregate; downstream не меняет состав section и не снижает thresholds.
- Снять language/extensions inventory и distinguishing cases для Rust/Python representative contour; все иные языки пометить unsupported/unverified до отдельного evidence.
- Создать authored `.cfmap.md` fixtures для AUTO/CURATED/stale/change/delete/invalid cases, не объявляя schema принятой.
- Сравнить provider/store alternatives по privacy/egress, offline availability, model identity/dimension, deterministic caching, license, hardware, latency, update lifecycle и graceful absence; выбрать shortlist и один recommended direction только при измеримом основании. Для A2 decision map указать exact shared crates/versions/module declarations; B/C/D не выбирают новые shared dependencies после A2.
- На isolated копии existing DT2 service fixture сравнить transition alternatives и принять ровно одну policy: logical root ID, normalized locator/selector, StableId/source-key versioning, legacy single-root compatibility или mandatory rebuild, lifecycle после open/update, duplicate/collision behavior. Если choice не выводится из evidence, вернуть владельцу один exact blocking question.
- Провести negative runner scenarios: service root равен input root, является его предком, inside-root path не exact `.cfknowledge/dt3-a1-<run-id>`, reparse escape и evidence payload с absolute path/snippet/secret-like sentinel. Все scenarios отклоняются до unsafe write/commit.

## Definition of Done

- `corpus-passport.md` и machine-readable manifest не содержат absolute paths/raw vault content/secrets и воспроизводятся на переданных roots.
- `queries.tsv` содержит 24+ independently reviewable labels и покрывает все шесть intent-классов; labels созданы до retrieval implementation.
- `quality-contract.md` фиксирует immutable owner/gate sections, logical selectors, inclusion/`NOT_APPLICABLE_UNTIL` semantics, per-section formulas и numeric thresholds; exact cases имеют rank `1` в `100%`, must-not violations `0`, dedupe/order `5/5`. Нерешённый owner threshold блокирует A1 PASS.
- `performance-baseline.md` содержит exact commands, revision, release binary hash, environment/cache profile, five-run samples, median/max, service sizes и peak memory. Отдельный `performance-contract.md` фиксирует numeric absolute budgets и regression ratios до dependent implementation; unresolved budget блокирует A1 PASS.
- Bounded post-B1 correction: non-vector peak remains `<= 1,024 MiB`; a local embedding provider child process has a separately enforced `<= 2,048 MiB` ceiling on the measured 32 GiB workstation. Static model artifact bytes are recorded but do not consume either working-set gate.
- Bounded E2 correction: `warm exact query <=500 ms` continues to mean a warm in-process query. E2's separately measured new-process reopen+query includes Windows process startup and store reopen; its exact max is `<=750 ms`, derived above the observed 575.127 ms maximum with deterministic headroom. The failed 500-ms classification run and later series are both retained; the amendment changes classification, not samples.
- Amendment DoD: canonical `performance-contract.md` and any machine-readable manifest encode the same split authority; an executable oracle rejects vector child peak above 2,048 MiB and non-vector peak above 1,024 MiB; existing A1 quality/containment/redaction gates and full locked workspace tests remain GREEN; independent A master review PASS is mandatory.
- `provider-matrix.md` называет official sources, egress/privacy, failure/fallback и результат bounded synthetic spike либо честное `UNVERIFIED`.
- `root-identity-transition-passport.md` фиксирует ровно одну accepted legacy policy и lifecycle result; `root-language-map-passport.md` — accepted language contour и gaps, не identity alternatives.
- `service-evidence-contract.md` фиксирует canonical containment/reparse/cleanup predicates и redacted evidence schema; negative fixtures доказывают fail-before-write.
- `a2-materialization-passport.md` классифицирует каждый gap; фиксирует exact shared crates/versions/module declarations, ownership current source/state/application migration seams, `.cfmap.md` single-classification и code-root admission producers/consumers. Tree-sitter остаётся roadmap authority; silent parser replacement запрещён.
- Master reviewer подтверждает consistency с DT2 handoff, TDR claim boundary и отсутствие product/runtime changes.

## Операционная проверка

- Test oracle / причинный RED: discovery-лист; product RED неприменим. Causal gap — на baseline отсутствуют DT3 evidence paths/query oracle и отсутствует принятый ответ на root/provider/language/map decisions.
- Baseline: `cargo test --workspace --all-targets --locked --no-fail-fast`; `cargo build --release --locked`; `git status --short --branch`.
- Discovery runner contract: `powershell -File spikes/dt3-foundation/run.ps1 -DocumentRoot <runtime-path> -CodeRoot <runtime-path> -ServiceRoot <runtime-path> -RunId <id>`; runner до write проверяет canonical containment/reparse rules, пишет exact run marker, делает readback и сериализует только redacted schema.
- Окружение: Windows/PowerShell, locked Rust toolchain; network disabled by default; target root read-only outside isolated service subtree.
- Ожидаемый PASS: accepted identity transition, scoped quality sections, numeric performance limits, safe-service/evidence predicates и exact dependency/admission ownership замыкают A2 materialization без нового owner input. Measurements содержат redacted raw numeric samples, но не raw corpus. Нерешённый owner question — `BLOCKED`, а не A1 PASS.
- Evidence: `evidence/dt3/foundation/**`, `tests/fixtures/dt3/**`, A master verdict.
- Unverified areas: реальные production code roots сверх принятого contour; production-scale model quality/cost; compiler definitions/references; Linux/GPU — пока явно out of support.

## Условия остановки

- Baseline tests/rebuild дают regression; target/service containment или redaction не доказаны; corpus/root input отсутствует; provider требует неразрешённый egress/credentials; license неясна; query section/threshold не проверяемы; performance budget или legacy transition требуют owner choice; dependency/admission owner не однозначен.
- При stop worker не меняет product code/dependencies и возвращает Root exact evidence + decision question. B–E остаются dormant.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист E1 — Fusion ranking fallback

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-23`
- Branch / Leaf ID: `E / E1`
- Вес задачи: `8%`
- Состояние: `MATERIALIZED RUNNING`

## Наблюдаемое изменение

- Baseline: accepted exact/lexical/vector/map/symbol candidates exist independently; no accepted cross-channel calibration/dedupe/provenance behavior.
- После листа: one deterministic fused SearchResponse meets A1 numeric quality contract, preserves exact dominance/mode semantics and continues with explicit runtime vector unavailable/degraded fallback after a real vector contour has been accepted.

## Целевое состояние листа

Candidate provenance is retained; duplicate StableId has deterministic merge policy; raw Tantivy/vector scores are normalized/calibrated only by accepted method; ties end with StableId ascending. Map/symbol facts influence only the roles authorized by A2, not hidden ontology.

## Preconditions

- B2, C2 and D2 accepted/integrated at exact immutable base `0ae82491062698b195f45ca1e6bdcaca4fb2a501`; C2 exact base contained accepted D2 identity; B2 hits expose full model/state/projection provenance; combined lifecycle/identity/map→symbol relation gates PASS.

## Ownership

- Write: dedicated `src/application/fusion.rs` plus E1 application registry declaration if required, E1-specific tests/fixtures/evidence.
- Read-only: public A contracts, dependencies, and B/C/D adapter internals; no direct store handles or adapter reinterpretation.
- Fusion consumes `SearchHit`/capability statuses only. It may normalize by channel rank/reciprocal-rank or other predeclared monotonic calibration, but never compare uncalibrated lexical/vector raw scores directly.

## Definition of Done

- Balanced/Current/Design, exact, paraphrase, doc→map→symbol, dedupe, no-hit, provider absent/failure and repeated-order cases pass the immutable fusion section; owner sections remain unchanged and every previously `NOT_APPLICABLE_UNTIL` row is activated only after its producer gate.
- Quality thresholds cannot be weakened in E; a miss returns rework to producer/calibration decision.

## Операционная проверка

- RED: exact base can return independent lexical/vector/map/symbol candidates but has no production fused coordinator satisfying A1 Q01-Q06.
- GREEN: deterministic channel calibration with exact dominance, mode semantics, StableId dedupe/tie-break and projection provenance preservation; vector unavailable/degraded falls back to remaining accepted channels with truthful freshness. Five repeated runs must be byte/order equal.
- Quality: activate all E1-ready rows from A1 queries/quality contract, including paraphrase and document→map→symbol; exact rank-1 remains 100%, must-not zero, no-hit empty, dedupe/order 5/5. No threshold weakening.
- Final: targeted fusion suite, combined B2/C2/D2 replay, full locked workspace tests, fmt/clippy, independent E master review. E2 remains dormant until PASS+integration.

## Условия остановки

- A2 result cannot express provenance/lifecycle, raw scores require contract invention, required hit threshold misses or exact dominance regresses → Root/A backflow; E2 remains dormant.

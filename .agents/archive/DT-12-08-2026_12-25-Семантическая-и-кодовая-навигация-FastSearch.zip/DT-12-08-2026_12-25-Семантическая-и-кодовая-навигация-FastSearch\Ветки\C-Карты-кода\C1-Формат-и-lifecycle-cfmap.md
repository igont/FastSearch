<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист C1 — Формат и lifecycle cfmap

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-15`
- Branch / Leaf ID: `C / C1`
- Вес задачи: `9%`
- Состояние: `MATERIALIZED / REWORK`

## Наблюдаемое изменение

- Baseline: A1 hand-authored fixtures, A2 identity/lifecycle contract; no accepted `.cfmap.md` schema or source adapter.
- После листа: read-only `.cfmap.md` schema/admission and AUTO/CURATED/stale lifecycle are executable; CURATED bytes remain authored and unchanged, AUTO facts are rebuilt into existing SQLite-backed canonical state, and failed derivation leaves previous projection non-current but recoverable.

## Целевое состояние листа

Maps enter canonical source/state flow with versioned validation and stable identity. C1 alone admits `.cfmap.md`; A2 Markdown admission excludes this suffix from ordinary Markdown records, so duplicate classification is a causal regression. `.cfmap.md` is always read-only to FastSearch. CURATED manifests contain authored facts; AUTO manifests declare a source locator/generation identity, while generated facts are returned as canonical records and persisted only through the accepted existing StateStore/SQLite flow. All-or-nothing invalid-source policy, rename/delete/reopen and stale detection are observable. No pathname-based regeneration writer exists, eliminating the reviewed Windows reparse/TOCTOU write boundary.

## Preconditions

- A2 maps-registry rework accepted/integrated at exact base `d9bddda5a3c18af4dbe5d83e24c0a52d11f2a6ce`; A1 map fixtures accepted; Root selected read-only manifest + existing SQLite projection authority after C1 review proved pathname write TOCTOU.

## Definition of Done

- Exact schema/version, good/bad/stale fixtures, causal RED/GREEN, single-classification and byte-preservation oracle are materialized before product code.
- Product code exposes no file-write/regenerate API for `.cfmap.md`; tests prove authored bytes unchanged across AUTO derivation, repeated update is idempotent, rename/delete/reopen reconcile state, external-symlink source is rejected, and derived failure leaves the prior projection recoverable but non-current.

## Операционная проверка

- Commands: targeted C1 lifecycle tests plus `cargo test --workspace --all-targets --locked --no-fail-fast`, `cargo fmt --check`, `cargo clippy --workspace --all-targets --locked -- -D warnings`. Evidence includes byte/content preservation before/after, SQLite state lifecycle and DT2 Markdown regression.

## Условия остановки

- Any `.cfmap.md` write path, second durable authority, external-symlink acceptance, public identity gap or target-root mutation → Root; C2 remains dormant.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист B1 — Vector provider projection spike

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-20`
- Branch / Leaf ID: `B / B1`
- Вес задачи: `8%`
- Состояние: `MATERIALIZED / RUNNING`; immutable resume anchor `a38621655689026e0ee3780b5a1e2026c7dcd134`

## Наблюдаемое изменение

- Baseline: A2 accepted contract plus A1 provider/quality/performance passport; no provider implementation authority.
- После листа: минимум one provider/model/store/projection direction is executable, licensed, privacy-compatible and meets pre-fixed numeric quality/latency/resource gates. Иначе B и полный DT3 остаются `BLOCKED/REWORK`; runtime fallback не превращает отсутствие real vector contour в acceptance.

## Целевое состояние листа

Spike proves embedding normalization, model identity, cache/invalidation, batch limits, restart and no-provider behavior on synthetic plus approved representative text. It does not mutate public contracts or production runtime.

## Границы состояния

- Exact comparison runtime is local-only: `fastembed = =5.17.4` for BGE-M3 and multilingual-E5-small; Qwen uses immutable `ghcr.io/huggingface/text-embeddings-inference@sha256:ad950d30878eceb72aaf32024d26fa2b1d04a75304fa0b4776b49aa1941fea07` ONNX image GPU-first on GTX 1630 (4 GiB VRAM, compute capability 7.5). GPU accepts only 5 cold + 5 warm valid-vector runs, sampled max VRAM `< 3892 MiB`, and no CUDA OOM/device-loss/runtime error; any breach selects CPU fallback, which must independently complete 5 cold + 5 warm valid-vector runs. The image is verified/pulled before corpus input, with model directory read-only and endpoint bound only to loopback. Corpus-bearing Qwen runs on Docker `--internal` no-egress network and fails closed when no verified cache exists; B1 must prove both. Before corpus input, provisioning admits only public `https://huggingface.co/BAAI/bge-m3`, `https://huggingface.co/intfloat/multilingual-e5-small` and `https://huggingface.co/Qwen/Qwen3-Embedding-0.6B` artifacts into separate canonical caches. It records upstream revision, file manifest and SHA-256, rejects reparse escape, cleans only incomplete exact-run cache. Text/corpus never egresses. B1 removes only its exact named container/network and incomplete run cache on stop, retaining verified model artifacts. B1 cannot add/change `Cargo.*`/`src/adapters/mod.rs`; no Qwen Rust dependency is needed.

## Preconditions

- A2 local-vector rework accepted/integrated at a Root-recorded exact base; Root resumes B1 with immutable anchor. Provider shortlist and thresholds fixed by A1.
- A1 PV-20 resource amendment master PASS and Root integration are mandatory before the 2,048 MiB vector-child gate is authoritative; Root then advances B worktree and records the exact immutable B1 resume anchor.
- B1 comparison corpus is the exact read-only local union of `tests/fixtures/dt3/document-root` and `tests/fixtures/dt2` in the B worktree, logical root `document-representative-b1-fixture`, approved by Root for deterministic provider selection. It is not claimed as replay of the redacted 918-file A1 runtime root; arbitrary/full representative-root acceptance remains mandatory in E2.

## Definition of Done

- Causal quality/performance/failure comparison of all three profiles identifies at least one accepted real direction and exact B2 contract, including rollback/fallback and model migration. Quality gates select the winner; p95 latency and peak memory break quality ties. Runtime provider absence/failure is accepted only after this real contour exists. Model artifact bytes are recorded separately and cannot fail the generated-service-size budget.

## Операционная проверка

- Executable spike imports the applicable A1 `queries.tsv` expected/must-not rows into fixed local fixture queries and fails unless required rank/must-not/dedupe/order are identical over five repeats.
- For every executable profile record five cold and five warm valid-vector runs, p95 latency, child-process peak working set, vector dimension/norm and batch boundary. The accepted E5 direction additionally proves restart with the same model hash, deterministic repeated output, exact missing-cache/no-provider failure and recovery without corpus mutation.
- The runner enforces vector-provider child-process peak working set `<= 2,048 MiB`, the measured owner-approved ceiling for this 32 GiB workstation. The original `<= 1,024 MiB` remains the non-vector runtime budget; neither limit applies to static model artifact bytes.
- Provisioning gate verifies revision/manifest/SHA-256 for all three public caches, canonical containment and a real Windows reparse rejection. Corpus-bearing runs are offline/local-only; Qwen must prove pinned-image no-egress plus loopback reachability or remain causally unavailable. A failed comparison profile is evidence, never silently removed.
- Final gate: `cargo check --offline` for the isolated spike, its executable quality/operational/privacy runner, full locked workspace tests, and independent master review. B2 remains closed until PASS.

## Условия остановки

- Все directions fail privacy/license/hardware/numeric quality threshold, incompatible dependency or public lifecycle gap → Root; B2 remains dormant and full DT3 cannot PASS without owner scope change + material replan.

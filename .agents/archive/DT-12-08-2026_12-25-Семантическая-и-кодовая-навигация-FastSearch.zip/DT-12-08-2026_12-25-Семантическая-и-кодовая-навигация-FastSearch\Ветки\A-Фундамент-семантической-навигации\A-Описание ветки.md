<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки A — Фундамент семантической навигации

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-28`
- Branch ID: `A`
- Base revision: initial `135572ff45321005ca75c6bc3624e1525f99bce7`; при старте владелец требует повторный clean preflight и operational exact base.

## Наблюдаемое изменение

- Baseline: DT2 real document search принят; DT3 ports/types существуют как object-safe scaffold, но corpus quality, multi-root identity, projection lifecycle, provider/privacy, `.cfmap.md` и language matrix не доказаны.
- После ветки: измерительный foundation принят, затем public contracts/dependencies/ownership позволяют B/C/D реализовывать независимые adapters без переопределения authority и без E-local backflow.

## Целостное состояние ветки

Для parameterized document/code roots существует reproducible corpus/scoped-quality/numeric-performance/provider/service-safety passport и принята одна legacy DT2 → named-root transition policy. На его основе public boundary выражает named-root identity, source/projection provenance, independent capability lifecycle, typed unavailable/partial failures и deterministic fused results. A2 реализует только shared identity/migration/admission foundation; vector/map/symbol adapters остаются B/C/D.

## Ownership

- A1 разрешено изменять: `evidence/dt3/foundation/**`, `tests/fixtures/dt3/**`, `spikes/dt3-foundation/**`.
- A2 ownership: `src/domain/**`, `src/ports/mod.rs`, `src/adapters/mod.rs`, `Cargo.toml`, `Cargo.lock`, bounded shared named-root/source admission, mandatory-rebuild transition changes in existing source/state/application seams и public/upgrade contract tests. A2 фиксирует единственный Tree-sitter envelope: `tree-sitter = =0.25.10`, `tree-sitter-rust = =0.24.0`, `tree-sitter-python = =0.25.0`; B/C/D не добавляют shared dependency.
- C1 доказал A-backflow: только A2 добавляет declaration-only registry export `maps` в `src/adapters/mod.rs`; map logic и public boundary остаются C-owned/неизменными.
- B1 owner decision доказал второй bounded A-backflow: A2 добавляет only `fastembed = =5.17.4` in `Cargo.toml`/lock and declaration-only `vector` registry module. B uses only this local ONNX runtime; no text egress, credentials or remote inference.
- D2 preflight доказал bounded registry backflow: A2 alone adds declaration-only `pub mod symbols;` and empty `symbols.rs`; no symbol logic, public port or dependency change.
- B1 R2 measured a local E5 child-process peak near 1.44 GiB on a 32 GiB workstation. Per the owner directive to avoid abstract model limits, A1 alone revises the vector-provider child-process budget to an enforced 2,048 MiB ceiling while retaining 1,024 MiB for non-vector DT2/A1 runtime measurements. Model bytes remain diagnostic and uncapped; B1 and E2 still record actual peak memory.
- Lifecycle gate: bounded A1 evidence amendment is `MATERIALIZED / RUNNING` on exact Root integration base `dc9665775c6b4e1245927aa399537111deab7c3b`; B1 is `WAITING` and may resume only after amendment master PASS, Root merge and an immutable exact resume anchor.
- B2 preflight/master proved a bounded public provenance gap: A2 alone adds an optional typed per-hit projection provenance carried through `SearchHit`/`SearchResponse`, with model identity, durable state generation and projection generation. Existing non-vector constructors stay source-compatible and use `None`; A2 changes no adapter/runtime/dependency. B2 waits for accepted/integrated contract and an exact immutable resume anchor.
- E2 security review proved Windows junction-swap cannot be closed by pathname rechecks alone. A2 alone adds target-Windows direct `windows-sys = =0.61.2` with only `Win32_Foundation` and `Win32_Storage_FileSystem`; the version is already locked transitively. A2 changes no runtime logic. E2 waits for dependency-only PASS+integration, then owns persistent no-`FILE_SHARE_DELETE` directory handles and the swap-denial oracle.
- E2 release measured cross-process reopen+query samples 270.126/353.159/575.127/540.506/261.237 ms on the same accepted binary, while a second identical series maxed at 282.027 ms. The original 500 ms pure in-process warm-query ceiling remains unchanged; A1 owns a bounded evidence amendment adding a distinct E2 cross-process CLI reopen+query ceiling of 750 ms. Every observed series remains committed and must pass its applicable gate; no outlier is discarded.
- Только чтение: DT2 adapters/application/tests, `ROADMAP.md`, `evidence/dt2-dt3-handoff.md`, representative roots и governance/TDR sources.
- Запрещено: concrete vector/map/symbol/fusion implementation, runtime/CLI wiring, target-vault docs/governance edits, credentials или raw corpus в Git.

## Зависимости и интеграция

- Preconditions: DT2 handoff, clean trusted document baseline, owner start command.
- Consumers: B, C, D и E.
- Producer gate: A1 master `PASS` → Root PV-4 materialization/review A2; A2 public + upgrade + shared-envelope oracle `PASS` → common integrated A base.
- Допустимая параллельность: A1 один; B/C/D не запускаются. После A2 B1/C1/D1 могут идти параллельно при непересекающихся manifests.
- Порядок интеграции: A1 evidence candidate, затем A2 candidate; Root интегрирует A до любых consumers.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| A1 | 12% | Принят hard-data passport и decision map | Полностью materialized, единственный runnable leaf после owner start |
| A2 | 18% | Public/legacy-transition/dependency/admission foundation принят | `MATERIALIZED / RUNNABLE AFTER DELTA REVIEW`; A1 PASS accepted |

Сумма листьев: `30%`.

## Definition of Done

- A1 unknowns превращены в принятые измерения, bounded support scope и explicit owner decisions/gaps.
- A2 contract suite доказывает object safety, logical-selector → StableId mapping, accepted DT2 transition, root/projection identity и honest status/error semantics до consumer adapter work.
- B/C/D получают frozen shared dependencies/modules, disjoint admission ownership и exact integrated base; новая shared dependency или source seam после A2 требует A backflow, а не branch-local edit.

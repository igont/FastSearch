<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист D2 — Symbol snapshot retrieval

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-26`
- Branch / Leaf ID: `D / D2`
- Вес задачи: `12%`
- Состояние: `RESOURCE AMENDMENT MATERIALIZED RUNNING`

## Наблюдаемое изменение

- Baseline: accepted D1 parser/identity, production Symbols unavailable.
- После листа: named code roots produce canonical CodeSymbol snapshots and deterministic symbol search with accepted lifecycle/status/error semantics.

## Целевое состояние листа

Add/change/delete/rename/duplicate/root-collision/parse-failure/reopen/rebuild work through public ports. Exact technical identifier is preserved; structural locator is explainable; unsupported language and partial index are honest.

## Preconditions

- D1 master PASS; A2 declaration-only symbols registry rework accepted/integrated at Root-recorded exact base; accepted logical-root/legacy identity mapping from A2 is unchanged. Root resumes D2 with immutable anchor containing that merge revision.
- Bounded E2 feedback: exact integration `cc91f63780357538b2e86e78adc8bee7fd76f510` current `src` measured with the accepted parser/query/traversal has max 10,302 nodes and 14/20 files exceed 512. D2 amendment changes only the node budget/evidence/tests, not identity, query, ports or runtime.

## Definition of Done

- Causal symbol corpus oracle and representative parameterized-root run pass against invariant logical selectors; DT2 document sources remain unchanged; no absolute path or parser-node identity leaks. Accepted D2 identity is emitted as the mandatory producer artifact for C2.

## Операционная проверка

- Exact RED/GREEN/manifest/commands materialize from D1; broad DT3-Q01..Q04 mandatory.
- Amendment GREEN: `MAX_NODES=16_384`; exact parameterized current `src` succeeds twice with identical identities/order and a 20-file/50,451-node passport; dense >512 and <=16,384 succeeds; >16,384 fails atomically with zero snapshots. Existing >64KiB pre-read, unsupported, syntax, depth/files, Rust/Python and lifecycle gates remain GREEN. Independent D master PASS and Root integration are required before E2 resumes.
- Integration robustness: historical counts are evidence keyed to `cc91f637`, not a permanent equality assertion. The current-src test derives a sorted inventory at runtime, asserts two scans are identical and complete/non-empty, and verifies every per-file node count is within 16,384. Adding an accepted E-owned Rust source cannot invalidate D while exceeding the node limit still fails.

## Условия остановки

- Cross-root collision, nondeterminism, false-current partial parse, DT2 source regression or public gap → Root rework/backflow; E remains closed.

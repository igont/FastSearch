<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки C — Карты кода

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-17`
- Branch ID: `C`
- Base revision: `56ad9f2fcfa43fcf0a90bebe5d6d5c4bd2f8e6b1` — exact Root integration revision containing accepted A2+C1+D2.
- Состояние ветки: `C1 ACCEPTED / C2 MATERIALIZED RUNNING`.

## Наблюдаемое изменение

- Baseline: `RecordKind::CodeMap`/`CodeMapPort` are scaffold; representative vault has 0 `.cfmap.md`; `related` returns unavailable.
- После ветки: accepted `.cfmap.md` manifests remain read-only; authored CURATED facts are preserved byte-for-byte, while AUTO facts are rebuilt as derived canonical records in the existing SQLite state flow. Stale/change/delete lifecycle remains visible and related navigation uses only explicit traceable facts.

## Целостное состояние ветки

Map identity, source ownership and generation are deterministic. `.cfmap.md` is never written by FastSearch: CURATED relations are authored source, AUTO manifests only declare source/generation intent, and generated facts are a rebuildable SQLite projection. Invalid/stale map is never silently current. Related results point to canonical records with explainable relation provenance and never claim compiler resolution.

## Ownership

- Tentative: `src/adapters/maps/**`, map-specific tests/fixtures/evidence. C1 — единственный concrete `.cfmap.md` admission/classification owner на A2 shared seam.
- Read-only: shared domain/ports/deps/module registry, existing source/state/lexical/vector/symbol/application; если A2 seam не достаточен, C возвращает A backflow.
- Forbidden: changing target vault/governance/TDR, inventing compiler definition/reference, cross-store handles, public contracts.

## Зависимости и интеграция

- Preconditions: A2 maps-registry and C1 accepted; D2 structural identity accepted/integrated at exact immutable C2 base `56ad9f2fcfa43fcf0a90bebe5d6d5c4bd2f8e6b1`. PV-15 authority decision forbids FastSearch writes to `.cfmap.md`; AUTO output uses existing canonical record/state flow.
- Consumers: E.
- Producer gate: C1 schema/lifecycle PASS + accepted/integrated D2 structural identity → C2 related navigation on exact combined base.
- Parallel: B/D after A2 with disjoint paths.
- Integration: Root integrates C1 and D2 before materializing C2; C2 exact base contains A2+C1+D2, then Root integrates C2 before E.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| C1 | 9% | Read-only `.cfmap.md` schema, SQLite-derived AUTO lifecycle and CURATED preservation accepted | `ACCEPTED`; master PASS integrated |
| C2 | 6% | Explicit document/map/symbol related navigation accepted | `MATERIALIZED RUNNING`; exact base contains accepted C1+D2 |

Сумма листьев: `15%`.

## Definition of Done

- Valid/invalid/add/change/delete/stale/reopen and curated-preservation cases pass.
- `related` is deterministic and traceable; absent map facts remain unavailable, but accepted symbol-target corpus cannot PASS as permanently unresolved/partial.
- DT2 Markdown handling remains compatible; special `.cfmap.md` classification is not duplicated as ordinary sections unless contract explicitly requires it.

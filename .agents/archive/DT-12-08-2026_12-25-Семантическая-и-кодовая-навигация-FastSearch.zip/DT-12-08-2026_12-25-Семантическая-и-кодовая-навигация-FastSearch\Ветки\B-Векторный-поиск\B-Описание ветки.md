<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки B — Векторный поиск

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-29`
- Branch ID: `B`
- Base revision: `054055f1f14c6dbe57905211f315d63208feb314` — exact failed-final-review integration containing accepted A–E production contour.
- Состояние ветки: `B1 ACCEPTED / B2 PV-29 ACCEPTED INTEGRATED`; candidate `21d942048eac6772d386f39ddba907e65f68f589`, integration `3a6ed6a7d97f2193f35138380e2b66255c67fddd`.

## Наблюдаемое изменение

- Baseline: vector capability honest `Unavailable`; no provider/model/store/projection generation.
- После ветки: accepted canonical records получают rebuildable model-versioned vector projection; paraphrase retrieval работает на labeled corpus, а absence/failure оставляет lexical contour usable и честно наблюдаем.

## Целостное состояние ветки

Vector data является derived projection tied to record content hash, model identity и accepted durable generation. Provider не становится source authority. Reopen/update/delete/rebuild/failure имеют проверяемое состояние; raw provider scores не объявляются общим ranking score.

## Ownership

- Tentative: `src/adapters/vector/**`, vector-specific tests/fixtures/evidence.
- Read-only: shared domain/ports/`Cargo.toml`/`Cargo.lock`/`src/adapters/mod.rs` and source/state/lexical/map/symbol/application after A2. B consumes only A2-approved `fastembed = =5.17.4` local ONNX envelope and cannot add dependency; incompatible frozen envelope — A backflow.
- Forbidden: provider credentials/corpus in Git, external egress without owner decision, public contract changes, E fusion.

## Зависимости и интеграция

- Preconditions: A2 local-vector rework accepted/integrated by Root at exact base `d9bddda5a3c18af4dbe5d83e24c0a52d11f2a6ce`. Before any corpus input B1 provisions public artifacts only into three canonical service-root caches: `models/bge-m3`, `models/multilingual-e5-small`, `models/qwen3-embedding-0.6b`; records upstream revision/file manifest/SHA-256, rejects reparse escape, deletes incomplete exact-run cache, and proves offline fail-closed load. Qwen GPU accepts only 5 cold + 5 warm valid-vector runs, max sampled VRAM `< 3892 MiB`, and no CUDA OOM/device-loss/runtime error; otherwise B1 runs CPU fallback 5 cold + 5 warm valid-vector runs.
- Consumers: E.
- Producer gate: B1 accepted provider/projection spike → B2 production contract.
- Parallel: C/D allowed after A2 with disjoint paths.
- Integration: Root merges accepted B only; then combined projection gates after C/D.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| B1 | 8% | Provider/model/store/projection choice доказан synthetic + Root-approved deterministic local fixture measurements | `ACCEPTED`; master PASS integrated |
| B2 | 12% | Real vector lifecycle/retrieval/fallback и immutable verified bytes связаны с provenance | `ACCEPTED`; master+security PASS, integrated as `3a6ed6a` |

Сумма листьев: `20%`.

## Definition of Done

- Document/vector section A1 quality gate passes without weakening exact/lexical; B1 compares BGE-M3, multilingual-E5-small and Qwen3-Embedding-0.6B on identical inputs. Eligible winner passes required-hit/must-not/repeat gates; ranking is quality first, then p95 latency/peak memory. Model artifacts are excluded from generated service-size budget and recorded separately.
- Model changes invalidate/rebuild projection deterministically; add/change/delete and reopen proven.
- Provider unavailable/failure has typed status and no unapproved egress.
- Model `Current`/provenance разрешены только когда полный manifest и фактически загруженные provider bytes образуют одну неизменяемую identity boundary. Между verify и load запрещено path-based окно: B2 удерживает достаточные no-write/no-delete file/directory handles либо использует эквивалентный immutable verified snapshot с post-load identity proof. Coordinated mutation/junction race обязан завершиться typed fail-closed без hits/Current и без старого provenance для новых bytes.

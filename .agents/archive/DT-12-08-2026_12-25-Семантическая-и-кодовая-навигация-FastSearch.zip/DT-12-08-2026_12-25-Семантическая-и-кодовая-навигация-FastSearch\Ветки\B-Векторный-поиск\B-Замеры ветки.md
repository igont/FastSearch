<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Замеры ветки B

Во время активной работы Root добавляет короткий управленческий checkpoint не реже одного раза в 20 минут.

| Time | Active leaf | New verifiable result | Accepted delta | Wait or rework | Root decision |
|---|---|---|---:|---|---|
| 12.08.2026 18:40 | B1 | E5 deterministic 10 runs, p95 2414 ms, peak 1,502,838,784 B; BGE/Qwen causal unavailable | +8% | PASS | выбрать local multilingual-E5-small |
| 12.08.2026 20:05 | B2 | Real E5 lifecycle/recovery 379.52 s, provenance/invalidation PASS | +12% | PASS | интегрировать B2 |
| 13.08.2026 01:15 | B2 | Final review воспроизвёл verify→load identity race | -12% | REWORK | immutable bytes + race regression на PV-29 |
| 13.08.2026 02:30 | B2 | Disposable E5 race 71.26 s, stationary lifecycle 339.96 s, causal reader 0.57 s; full/fmt/clippy PASS | +12% | PASS | принять `21d9420`, интегрировать B2 |

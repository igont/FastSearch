<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист D1 — Language parser identity spike

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-5`
- Branch / Leaf ID: `D / D1`
- Вес задачи: `8%`
- Состояние: `MATERIALIZED / RUNNING`

## Наблюдаемое изменение

- Baseline: accepted A1 language/root corpus and A2 identity contract; no parser/grammar acceptance evidence.
- После листа: one bounded Tree-sitter crate/grammar/version/query set extracts required declaration shapes with stable structural identity, resource limits and explicit unsupported/partial failure policy, or exact language remains unsupported.

## Целевое состояние листа

Spike covers representative Rust/Python or the exact A1-approved matrix, duplicate names/scopes, syntax errors, unicode paths, large files, rename and deterministic repeated parse. It validates Tree-sitter core/grammar/version/query capability and license without implementing runtime or claiming compiler resolution. Другой parser family не входит в worker discretion.

## Preconditions

- A2 accepted/integrated; A1 language priority, fixtures and limits fixed; A2 exact read-only Tree-sitter envelope is `tree-sitter = =0.25.10`, `tree-sitter-rust = =0.24.0`, `tree-sitter-python = =0.25.0` and its declaration module is read-only for D1.

## Definition of Done

- Tree-sitter version/grammar/query strategy and identity serialization are proven against hand-authored oracle; resource/error policy and D2 exact contract are accepted.

## Операционная проверка

- Exact commands/paths materialize after A2 using its frozen dependencies; causal RED must show identity or parse-policy failure before GREEN. A required crate/version change is A backflow, not a D1 manifest edit.

## Условия остановки

- Tree-sitter grammar cannot express required shapes, license/dependency incompatible, identity unstable, error recovery publishes false facts, or compiler semantics required → owner backflow/roadmap correction + material replan; D2 remains dormant. Silent replacement by another parser is forbidden.

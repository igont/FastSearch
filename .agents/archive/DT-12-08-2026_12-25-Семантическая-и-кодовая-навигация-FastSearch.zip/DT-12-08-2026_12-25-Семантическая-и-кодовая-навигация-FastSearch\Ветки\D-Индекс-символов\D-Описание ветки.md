<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки D — Индекс символов

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-26`
- Branch ID: `D`
- Base revision: future exact Root integration revision containing accepted A2.
- Состояние ветки: `D1 ACCEPTED / D2 RESOURCE AMENDMENT MATERIALIZED RUNNING`.

- E2 discovery at integration `cc91f63780357538b2e86e78adc8bee7fd76f510` measured 20 admitted Rust files, 50,451 visited nodes total and maximum 10,302 nodes in `adapters/source/mod.rs`; the accepted 512-node limit rejects 14/20 production files. D2 alone owns a bounded amendment to `MAX_NODES=16_384`, the smallest power of two above the measured maximum (59.04% headroom). The unchanged 64KiB pre-read, depth/files, unsupported/syntax and fail-atomic guards remain mandatory.
- E2 integration added `application/production.rs`, making the live contour 21 files and proving that the D2 regression test must not freeze a historical file/aggregate total. D2 owns a test/evidence-only robustness amendment: the `cc91f637` 20-file/50,451-node numbers remain a revision passport, while the executable test inventories the current exact `src`, requires two identical complete scans, non-empty admitted set, every file below 16,384, and stable sorted identities/order. Product limit remains unchanged.

## Наблюдаемое изменение

- Baseline: `RecordKind::CodeSymbol`/`SymbolPort` are scaffold; source scanner accepts only Markdown/TSV; no named code roots, language matrix or parser identity.
- После ветки: accepted Tree-sitter grammars for the approved languages produce stable structural symbol snapshots and deterministic retrieval from replaceable named code roots, with partial/unsupported/stale states and no compiler-semantic claim.

## Целостное состояние ветки

Symbol identity depends on accepted logical root + normalized relative locator + language/structural symbol facts, never absolute path, traversal order or parser node ID. Parse failure does not publish fabricated/partial current records. Delete/rename/reopen/rebuild are observed through canonical state/projection flow.

## Ownership

- Tentative: `src/adapters/symbols/**`, symbol-specific tests/fixtures/evidence and concrete code-root admission on the A2 shared seam. Tree-sitter core/grammar dependencies and module declarations are frozen by A2 from A1 evidence.
- Read-only: shared domain/ports/`Cargo.*`/module registry, existing source/state/lexical, vector/map/application. D cannot select a new crate after A2; incompatibility returns A backflow.
- Forbidden: compiler definition/reference claims, dirty buffers, semantic refactoring, unsupported-language silent fallback, public contract changes.

## Зависимости и интеграция

- Preconditions: accepted/integrated A2 and A1 supported language/root passport.
- Consumers: C2 mandatory accepted-corpus symbol targets, E.
- Producer gate: D1 parser/identity spike PASS → D2 production snapshot/retrieval.
- Parallel: B/C after A2 with disjoint paths.
- Integration: Root integrates D2 before C2 materialization; C2 exact base consumes D2 identity and replays relation oracle before E.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| D1 | 8% | Language/parser/identity/error policy доказаны | `ACCEPTED`; master PASS integrated |
| D2 | 12% | Real symbol snapshot/retrieval lifecycle принят | `RESOURCE AMENDMENT MATERIALIZED RUNNING`; measured 16,384-node bounded correction |

Сумма листьев: `20%`.

## Definition of Done

- Supported language contour fixed from actual roots and fixtures; unsupported files are explicit.
- Stable symbols survive reopen and deterministic rebuild; rename/delete/parse failure/duplicate/collision cases pass.
- Output says `structural source symbol`; compiler snapshot/definition/references remain unavailable.

<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Вердикт мастер-ревьюера ветки B

Файл append-only изменяет только мастер-ревьюер.

## Итерация 1 — B1

- Candidate revision: `41e14446caef10b335f48a46d90e2bdeee485b42`; base `d9bddda5a3c18af4dbe5d83e24c0a52d11f2a6ce`; ancestry/clean confirmed.
- Verdict: `REWORK`.
- Confirmed: isolated spike `cargo check --offline`, finite E5 384-dim vector, causal BGE 2-output versus 3-output adapter incompatibility, no product/public/B2 changes.
- Findings: no canonical owner-approved representative anchor; missing complete provisioning/offline/containment/reparse/cleanup, five cold+five warm p95/peak-memory/batch/restart/normalization/no-provider evidence; quality command was not bound to immutable expected/must-not/repeat oracle.

## Итерация 2 — B1 delta

- Candidate revision: `aa29825d70419a972dad9afa3ec42a0c6c957458`; descendant/clean confirmed.
- Verdict: `REWORK`.
- Closed partially: fixed E5 query/rank-1 is reproducible.
- Remaining: immutable representative approval, must-not/top-K/five-repeat mapping to `queries.tsv`; missing-cache returns raw OS error rather than typed local no-provider; committed real containment/reparse and all operational/privacy gates remain absent.

## Итерация 3 — B1 operational delta

- Task ID: `FASTSEARCH-DT3`; Plan version: `PV-18`; scope: `B1`.
- Candidate revision: `4c4e44c2300cf1b5f8befb1ad581bf072cb0454a`; previous revision: `aa29825d70419a972dad9afa3ec42a0c6c957458`; descendant and clean worktree confirmed.
- Recheck scope: `spikes/dt3-vector/run-operational.ps1` against the PV-18 operational/privacy gate.
- Verdict: `REWORK`.
- Evidence states: `SCOPED PASS` for ten isolated fixed-fixture E5 process observations; `PRODUCTION UNVERIFIED` for B2/runtime; no B2/product/public diff.

### Blocking findings

1. E5 fails the frozen resource budget. Independent runner replay measured peak child working set `1,504,088,064` bytes (`1434.4 MiB`); A1 performance contract permits `<= 1024 MiB`. The runner records but never enforces this numeric gate.
2. PV-18 quality/operational oracle remains partial: runner does not import/map applicable `queries.tsv` expected/must-not rows, assert must-not, norm or explicit batch boundary, and does not prove recovery after missing cache. Missing cache is rejected only as raw OS error, not a typed stable no-provider status.
3. Privacy/provisioning evidence remains partial: no real Windows reparse escape test (only cache-root attribute/prefix checks), no descendant check, complete revision/manifest/SHA-256/model-byte evidence, offline fail-closed load, exact cleanup, or executable Qwen pinned-image no-egress/loopback evidence. BGE/Qwen narratives alone do not close their gates.
4. Final required combined evidence (`cargo check --offline`, runner, full locked workspace tests) is not recorded on this exact candidate.

### Проверено

- Runner reproduced ten finite 384-dim E5 results with identical rank order `0,1,2`; p95 by its conservative maximum-for-10 calculation was `2565 ms`.
- PV-18 Root replan explicitly approves the exact local DT2+DT3 fixture union, so the former representative-root finding is closed by plan authority.

### Не проверено и residual risk

- B2 stays `DORMANT OUTLINE`; production lifecycle, fallback and public runtime remain unverified.

## Итерация 4 — B1 PV-20 memory delta

- Task ID: `FASTSEARCH-DT3`; Plan version: `PV-20`; scope: `B1`.
- Candidate revision: `4321688700273fa7e95d0615f6017b31b97455cd`; immutable resume anchor `a38621655689026e0ee3780b5a1e2026c7dcd134` is an ancestor; worktree clean.
- Recheck scope: only `spikes/dt3-vector/run-operational.ps1` after PV-20 A1 resource amendment.
- Verdict: `REWORK`.
- Evidence states: `SCOPED PASS` for the bounded E5 process measurement and its 2,048 MiB child ceiling; `PRODUCTION UNVERIFIED` for B2/runtime.

### Blocking findings

1. Previous memory finding is closed under PV-20: runner now enforces the authoritative separate vector-child budget `<= 2,147,483,648` bytes. Independent replay passed with ten fixed E5 runs, p95 `2329 ms` and peak `1,502,531,584` bytes. This closes no other gate.
2. `B1-R5` remains: the runner does not import/map applicable `queries.tsv` rows or assert expected/must-not semantics, vector norm, explicit batch boundary, recovery after missing-cache rejection, or typed stable no-provider status. A raw missing-path OS error remains the observed failure.
3. `B1-R6` remains: real Windows reparse-escape/descendant test, complete three-profile revision-manifest-SHA256/model-byte evidence, offline fail-closed load, exact cleanup, and executable Qwen pinned-image no-egress/loopback evidence are absent. BGE/Qwen strings are not sufficient executable proof.
4. Final exact-candidate acceptance bundle still lacks full locked workspace test evidence after the runner; B2/product/public changes remain absent and B2 must not materialize.

### Проверено

- `cargo check --offline` for the spike passed after the delta.
- Runner independently replayed all ten E5 processes and enforced the PV-20 child memory ceiling.

## Итерация 5 — B1 R4 delta

- Task ID: `FASTSEARCH-DT3`; Plan version: `PV-20`; scope: `B1`.
- Candidate revision: `0dff76fb259ff4c684c8437ebf3ed7a0ce9759a1`; descendant/clean confirmed.
- Recheck scope: fixed E5 oracle, model identity capture, typed missing-cache/recovery and final checks.
- Verdict: `REWORK`.
- Evidence states: `SCOPED PASS` for E5 fixed-fixture operational run, typed local missing-cache/recovery, `cargo check --offline` and full locked workspace tests; `PRODUCTION UNVERIFIED` for B2/runtime.

### Blocking findings

1. The claimed all-profile integrity gate is incomplete and too weak. It validates a prefix of one hash per profile (`StartsWith` 16 hex characters), not the pinned full SHA-256, and emits no upstream file manifest for each cache. PV-20/B1 require revision, file manifest and SHA-256 before corpus input; one selected file plus prefix cannot detect changed companion/tokenizer/config/model files.
2. Qwen privacy gate remains only a narrative string. Exact plan requires executable evidence of pinned-image no-egress plus loopback reachability, or a causally demonstrated unavailable outcome. This candidate neither creates/verifies the exact Docker internal network/image/readonly model boundary nor records concrete probe/exit evidence. BGE similarly has no runner-generated causal evidence; its retained text is not a rerun gate.
3. Must-not is metadata-only: runner checks that `queries.tsv` contains `architecture.md` / `secret sentinel`, but it cannot map returned indexes to logical selectors nor assert that forbidden selector is absent. Thus the stated A1 expected/must-not contract is not executable in this spike.
4. Real Windows reparse escape/descendant rejection, offline fail-closed verification and exact named cleanup remain absent from the runner/evidence.

### Проверено

- Independently re-executed operational runner: ten E5 runs, finite 384-dim normalized vectors, batch `1`, same order `0,1,2`, typed `B1_NO_PROVIDER_CACHE_MISSING`, recovery, peak within PV-20 2,048 MiB child budget.
- `cargo check --offline` passed; `cargo test --workspace --all-targets --locked --no-fail-fast` passed (all tests).

### Не проверено и residual risk

- B2 remains `DORMANT OUTLINE`; no production vector lifecycle/fallback/public runtime is accepted.

## Итерация 6 — B1 R5 delta

- Task ID: `FASTSEARCH-DT3`; Plan version: `PV-20`; scope: `B1`.
- Candidate revision: `b7a2de30c618421de05e97ac44dab175a82d6f5a`; descendant/clean confirmed.
- Recheck scope: full cache observation, selector/must-not, junction, BGE and Qwen causal observations.
- Verdict: `REWORK`.
- Evidence states: `SCOPED PASS` for E5 operational sequence, full observed local cache manifest, BGE adapter mismatch and selected Qwen Docker observation; `PRODUCTION UNVERIFIED` for B2/runtime.

### Blocking findings

1. The Windows junction check proves only that `junction-probe` itself has the reparse attribute. It never passes this descendant through the cache/provisioning admission predicate or verifies rejection of traversal/use; it then labels it `rejected` unconditionally. This is not the required real descendant reparse-escape rejection.
2. Qwen evidence is incomplete for the required privacy boundary. Runner records only ports and `ReadonlyRootfs` (`{"80/tcp":[]} false`), but does not verify the pinned image digest, Docker network `.Internal=true`, the `/data` model mount is read-only, or a loopback probe/cause. Independent inspection happens to show those other runtime facts, but they are not candidate's executable evidence. Thus the causal no-egress/loopback-unavailable claim is not fully materialized.
3. Full manifest is now recorded, but its integrity gate still pins only the first 16 hex characters of three selected files and has no expected manifest comparison. The recorded manifest is diagnostic rather than a verification that the cached tree matches the approved upstream artifact set.
4. Exact cleanup proof remains limited to the synthetic junction, not the named Qwen container/network or incomplete exact-run cache specified by B1.

### Проверено

- Independently replayed runner PASS: all ten E5 runs with deterministic selectors/order, typed missing-cache/recovery, bounded peak, BGE exact 2-vs-3 output error; cache manifest contains recursive locators, bytes and full computed SHA-256.
- Independent Docker readback: actual image digest is pinned, network is `Internal=true`, and `/data` bind is read-only; no published port. These facts reduce residual risk but cannot replace candidate gate evidence.

### Не проверено и residual risk

- B2 remains `DORMANT OUTLINE`; production lifecycle/fallback/public runtime are not accepted.

## Итерация 7 — B1 R6 closure delta

- Task ID: `FASTSEARCH-DT3`; Plan version: `PV-20`; scope: `B1`.
- Candidate revision: `81ce3f009d5fe9b70b175b48ac0bfe8e6a75bdf8`; descendant/clean confirmed.
- Recheck scope: R5 junction admission, complete model lock, Qwen privacy/cause and exact cleanup.
- Verdict: `PASS`.
- Evidence states: `SCOPED PASS` for B1 local provider/projection spike; `PRODUCTION UNVERIFIED` for B2, which remains dormant by plan.

### Blocking findings

- Нет.

### Проверено

- `cargo check --offline` independently passed; diff whitespace check clean. Candidate worktree clean.
- Executed evidence records actual junction passed to an admission predicate and typed rejection before enumeration, then exact junction absence after cleanup.
- `model-manifest.lock` fixes per-profile count and full canonical SHA-256 root; runner verifies full SHA equality of primary artifacts plus each sorted locator/byte/full-SHA256 set before corpus-bearing E5 processing.
- Executed evidence records E5 10-run deterministic fixed oracle, norm/batch, typed missing-cache/recovery and PV-20 child-memory gate; BGE exact adapter output mismatch.
- Qwen gate evidence records pinned image digest, internal Docker network, read-only root and `/data` bind, no published port, failed loopback probe, then removal/readback absence of the exact named container and network. Verified model caches are retained.
- Prior exact full locked workspace test pass is reusable: this delta changes only the isolated spike runner and manifest lock; the runner itself was executed under the new candidate.

### Не проверено и residual risk

- B1 is a bounded local spike, not production vector lifecycle. B2 production add/change/delete/reopen/rebuild/fallback remains `DORMANT OUTLINE` and must have its own causal acceptance.

## Итерация 8 — B2 первичное master-review

- Task ID: `FASTSEARCH-DT3`; Plan version: `PV-21`; scope: `B2`.
- Candidate revision: `2741dd279a41320c420ffb4d80070b2dae597542`; exact base `85d927e56d1f4cd3a7ccb9dccd0a1f776fec99b6` is ancestor; candidate worktree clean.
- Verdict: `REWORK`.
- Evidence states: `SCOPED PASS` for local E5 test lifecycle; `PRODUCTION UNVERIFIED` pending a truthful model-identity/provenance contract.

### Blocking findings

1. `B2-R1` — full model identity invalidation is not implemented. `LocalE5Vector::open`/`reconfigure` accept an arbitrary caller string and neither derive nor verify it against the B1 full manifest lock/model bytes. The model files can change while the same supplied string remains, and `apply` then considers equal content hashes unchanged and returns `Current` with stale vectors. The test only changes the manually supplied label; it does not prove identity from model artifacts.
2. `B2-R2` — vector retrieval does not return model/projection provenance to its port consumer. `VectorProjectionProvenance` is only a concrete-adapter accessor; `VectorRetrieval::search` returns ordinary `SearchResponse`/`SearchHit` with channel and raw score but no model identity or projection/state generation. E, which consumes the port, cannot distinguish/reject stale model projection as required by B2 target state.
3. `B2-R3` — provider failure during `search` calls `provider_failed(0, error)`, overwriting the accepted authoritative `state_generation` with `0` while degrading the projection. This corrupts the observed relation between the durable state generation and derived projection precisely on failure/recovery paths; the test does not inject a provider failure after a successful Current projection.

### Проверено

- Exact diff is limited to approved `src/adapters/vector.rs` and `tests/b2_vector_lifecycle.rs`; no public/Cargo/application change.
- Independently executed B2 targeted suite with `FASTSEARCH_E5_MODEL_ROOT`: 2/2 PASS, including ignored real local E5 lifecycle; `cargo fmt --check` and `cargo clippy --workspace --all-targets --locked -- -D warnings` PASS.
- Candidate implementation has finite normalization, deterministic ID tie order, typed missing local cache and keeps record authority outside the adapter.

### Не проверено и residual risk

- B1 operational evidence is reusable from accepted B1; full B2 lifecycle cannot pass until B2-R1..R3 are corrected and causally rechecked. E remains closed.

## Итерация 9 — B2 PV-22 delta-review

- Task ID: `FASTSEARCH-DT3`; Plan version: `PV-22`; scope: `B2` plus A2-approved provenance backflow.
- Candidate revision: `3ecd51b34a49ee7d83acd94349ea6567099aefbb`; both prior B2 candidate and immutable anchor `37f8e1ef40ac4df73dea48ccb90e4f97aa21b59f` are ancestors; worktree clean after real test completed and mutation artifact was removed.
- Verdict: `REWORK`.
- Evidence states: `SCOPED PASS` for manifest verification at `apply/rebuild`, public port provenance and preserved failure generation; `PRODUCTION UNVERIFIED` pending invariant preservation on the search path.

### Blocking findings

1. `B2-R4` — model mutation does not invalidate a projection already `Current` on `search`. `model_manifest()` is evaluated only by `apply/rebuild`; `VectorRetrieval::search` uses its cached `model_manifest` and invokes ONNX directly without comparing current artifact fingerprint. After a model file is changed, search can return vector hits marked `Current` with provenance for the old fingerprint until some caller voluntarily rebuilds. This violates the explicit B2 model-change invalidation/no-false-Current contract. The new test mutates a file then calls `rebuild`, so it does not expose the stale `search` path.

### Проверено

- B2 primary target passed; real ignored E5 test ran past the shell timeout to natural completion and removed `b2-model-bytes-mutation.tmp`.
- Delta correctly replaces caller-label-only identity with a complete local E5 manifest fingerprint at apply/rebuild; `dyn VectorRetrieval` now yields per-hit public model/projection provenance.
- Search provider failure now preserves captured durable generation rather than hard-coding `0`.

### Переиспользовано без повторной проверки

- B1 accepted manifest/resource/privacy runner and prior exact workspace checks: delta is limited to vector/provenance implementation and targeted contract tests.

### Не проверено и residual risk

- Until B2-R4 is fixed with a causal mutation-after-Current `search` test, E remains closed and B2 cannot be accepted.

## Итерация 10 — B2 R4 closure delta

- Task ID: `FASTSEARCH-DT3`; Plan version: `PV-22`; scope: exact B2 delta.
- Candidate revision: `fd0726c3a1859850a50a0ee08beb2916d0a8d33a`; descendant/clean confirmed.
- Recheck scope: Current projection after model artifact mutation, typed fail-closed response and cleanup/recovery.
- Verdict: `PASS`.
- Evidence states: `SCOPED PASS` for B2 local vector lifecycle and B1 inherited operational gates; `PRODUCTION UNVERIFIED` only beyond B2's accepted adapter boundary.

### Blocking findings

- Нет.

### Проверено

- `VectorRetrieval::search` now computes the accepted complete manifest before query embedding. Any changed/missing artifact causes typed provider failure, sets the actual captured durable generation degraded and returns no vector hits; an observed fingerprint mismatch returns stale/no hits.
- The causal test mutates the local E5 cache after `Current`, invokes the port search before rebuild and asserts empty non-Current result; RAII cleanup protects exact mutation removal, then recovery rebuilds.
- Independently observed the detached real ignored E5 replay until natural child completion; no mutation artifact remained and worktree was clean. The new implementation is limited to B2 vector code/test.
- Prior `fmt --check`, clippy `-D warnings`, B1 operational v5, targeted/local E5 and full locked workspace evidence remain applicable; no public/Cargo/application drift.

### Не проверено и residual risk

- This is an accepted local adapter contour. E's fused runtime, external representative-root acceptance and production deployment remain subsequent-gate work, not claims of B2.

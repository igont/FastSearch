<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Описание ветки E — Сведение retrieval и runtime

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-29`
- Branch ID: `E`
- Base revision: `054055f1f14c6dbe57905211f315d63208feb314` — exact failed-final-review integration containing accepted A–E contour and all three PV-29 causal defects.
- Состояние ветки: `E1 ACCEPTED / E2 PV-29 STRICT FINAL ACCEPTED INTEGRATED`; performance product/evidence `b07abdc`/`4342def`, final RAII candidate `8f921f63c46922494a9d0e6115e24b2e07c6c956`, integration `7d055df6f2aa2eed81ec31dc6de647221e7b2ee2`.

## Наблюдаемое изменение

- Baseline: lexical-only `RealRuntime`; B/C/D adapters independently accepted but not composed; raw channel scores are incomparable.
- После ветки: one production runtime indexes parameterized named roots, combines exact/lexical/vector candidates deterministically, exposes explicit map/symbol navigation and survives optional provider/failure/reopen/rebuild without false status.

## Целостное состояние ветки

Fusion uses A2 provenance/lifecycle contract and A1 labeled oracle. Exact dominance, dedupe, per-mode semantics and final StableId tie-break are fixed before tuning. E calls accepted ports only; it does not reach adapter stores, reinterpret map/symbol facts or create alternate mock/provider route. CLI keeps replaceable paths and isolated `.cfknowledge` service zone.

## Ownership

- Tentative: `src/application/**`, a dedicated fusion/composition module assigned by A2, E integration/CLI/acceptance tests and evidence.
- Read-only: A public contracts/deps and B/C/D adapter internals; DT2 source/state/lexical unless exact compatibility repair is returned to owner branch.
- Forbidden: new public method/dependency, hidden cross-store authority, hardcoded roots, runtime mock/alternate fault route, MCP/agent transport.

## Зависимости и интеграция

- Preconditions: A, B, D and C2 accepted/integrated; C2 was built on exact integrated D2 identity; combined identity/lifecycle/map→symbol relation gates PASS.
- Consumers: DT4 handoff.
- Producer gate: E1 fusion/fallback PASS → E2 real runtime/CLI acceptance.
- Parallel: none with pending B/C/D product changes.
- Integration: E1 then E2; Root final gates/archive/main merge.

## Листы

| Leaf ID | Вес задачи | Наблюдаемое состояние | Gate |
|---|---:|---|---|
| E1 | 8% | Explainable deterministic fusion/fallback accepted | `ACCEPTED`; master PASS integrated |
| E2 | 7% | Real runtime/CLI acceptance with truthful resource evidence, disjoint scale root and root-to-leaf no-follow bootstrap/run | `ACCEPTED`; master Iteration 11 + security PASS, integrated as `798a27f` |

Сумма листьев: `15%`.

## Definition of Done

- Fusion section of the immutable A1 quality contract passes after document/vector, map and symbol owner sections; `NOT_APPLICABLE_UNTIL` rows are activated only at their declared gates and never treated as zero-score evidence.
- Mixed query oracle passes without regressing exact/FTS and without comparing uncalibrated raw scores directly.
- Parameterized roots/service zone, independent capability lifecycle, failure/reopen/rebuild and status are observable across processes.
- Production mock audit is empty; a real vector contour has passed B gates. Individual runtime configurations may report provider `Unavailable` and fall back, but permanent absence of accepted vector implementation cannot satisfy this branch or full DT3.

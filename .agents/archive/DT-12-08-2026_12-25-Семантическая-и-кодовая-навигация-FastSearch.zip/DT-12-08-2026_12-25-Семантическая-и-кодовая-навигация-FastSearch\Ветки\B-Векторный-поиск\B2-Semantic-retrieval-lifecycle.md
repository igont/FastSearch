<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист B2 — Semantic retrieval lifecycle

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-29`
- Branch / Leaf ID: `B / B2`
- Вес задачи: `12%`
- Состояние: `PV-29 ACCEPTED / INTEGRATED`; candidate `21d942048eac6772d386f39ddba907e65f68f589`, integration `3a6ed6a7d97f2193f35138380e2b66255c67fddd`

## Наблюдаемое изменение

- Baseline: accepted B1 direction; vector capability not production-wired.
- После листа: accepted real vector projection and search implement ports with deterministic add/change/delete/reopen/rebuild, model invalidation, typed runtime unavailable/degraded and no false Current.

## Целевое состояние листа

Production vector adapter returns vector-channel candidates with model/projection provenance for E; it cannot overwrite SQLite authority or compare raw score with lexical itself.

## Preconditions

- B1 master PASS integrated at exact immutable base `85d927e56d1f4cd3a7ccb9dccd0a1f776fec99b6`; accepted provider is local multilingual-E5-small, with BGE/Qwen causal unavailable evidence retained. A2 vector contracts and A1 PV-20 resource authority are inputs.
- B2 resumes only after A2 public provenance backflow master PASS and Root integration; Root advances B worktree and records exact immutable resume anchor. B2 then derives full model fingerprint from the verified artifact manifest/bytes rather than caller label, preserves durable generation on provider failure, and returns A2 provenance through every vector hit.
- PV-29 final-review recovery: manifest verification, provider load and published `ModelIdentity` must be one immutable byte identity. Path re-open after hashing is insufficient. B2 owns a pinned/no-write/no-delete model boundary or immutable verified snapshot plus post-load proof; exact test hook coordinates file content and junction-swap attempts specifically between verify and provider load and proves typed Degraded/Unavailable, zero vector hits, no false Current and no stale provenance.

## Ownership

- Write: only `src/adapters/vector.rs` or descendants, B2-specific tests/fixtures/evidence.
- Read-only: public domain/ports, Cargo files, adapter registry, source/state/lexical/maps/symbols and application composition. SQLite remains source authority; vector data is rebuildable derived projection.
- A public contract/dependency/module/application gap stops for bounded Root backflow; test-only production masking and hidden alternate provider routes are forbidden.

## Definition of Done

- A1 document/vector numeric quality and performance budgets plus A2 lifecycle contract pass with a real configured provider; separate runtime provider absence/failure and recovery are causal tests; DT2 broad suite remains GREEN.

## Операционная проверка

- RED on exact base: production `VectorPort` remains unavailable and cannot project/search accepted canonical records with E5 model identity.
- GREEN lifecycle: deterministic add/change/delete/reopen/rebuild; content-hash + full model identity invalidation; finite normalized vector candidates with model/projection provenance; five-repeat stable order/dedupe; typed missing provider/failure/degraded state never reports false `Current`; recovery rebuild preserves SQLite authority.
- Resource/quality: use B1 full manifest lock and local E5 cache; replay applicable A1 expected/must-not rows, 5 cold+5 warm, p95 and vector-child peak `<=2048 MiB`. Provider code remains offline/local-only and cache paths parameterized, never hardcoded user paths.
- Final: targeted B2 suite, B1 operational runner, full locked workspace tests, fmt/clippy and independent B master review. E remains closed until Root integrates accepted B2.
- Security RED/GREEN: deterministic barrier reproduces verify→load mutation/junction race on exact base; GREEN either OS-denies mutation for the complete provider lifetime or detects it before publication. External sentinel/cache originals remain unchanged, temporary snapshot/handles have exact cleanup/readback, and stationary full E5 lifecycle still passes.

## Условия остановки

- Model/store migration cannot recover, provider failure corrupts prior projection, threshold miss or public gap → Root rework/backflow; E remains closed.

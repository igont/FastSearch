<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Замеры ветки E

Во время активной работы Root добавляет короткий управленческий checkpoint не реже одного раза в 20 минут.

| Time | Active leaf | New verifiable result | Accepted delta | Wait or rework | Root decision |
|---|---|---|---:|---|---|
| 12.08.2026 20:35 | E1 | Fusion 24/24 x5, combined B2/C2/D2 PASS | +8% | PASS | интегрировать E1 |
| 13.08.2026 00:45 | E2 | 20/20 release processes; cold max 329.297 ms; reopen+query max 276.974 ms; non-vector 39,723,008 B; vector 1,520,291,840 B; ratio 1.434960 | +7% | master/security PASS | принять `bd160b5`, интегрировать и выполнить Root final gates |
| 13.08.2026 01:15 | E2 | Final review: contaminated denominator и exact-run child race | -7% | REWORK | frozen disjoint inventory + pinned exact run |
| 13.08.2026 03:00 | E2 | PV-29 v3 20/20: source 1,686,257 B, service 2,459,851 B, ratio 1.458764; cold 354.938 ms; reopen+query 284.894 ms; peaks 40,083,456/1,520,627,712 B | +7% | PASS затем final-delta REWORK | вынести scaling input за WorkRoot и повторить replay |
| 13.08.2026 04:00 | E2 | PV-29 final 20/20: disjoint doc/code/runtime-doc; source 1,688,328 B, service 2,460,147 B, ratio 1.457150; inventory unchanged; all gates true | +7% | PASS | принять `068a3a9`, интегрировать и повторить Root final review |
| 13.08.2026 05:00 | E2 | PV-29 strict final: product `b07abdc`, binary `5c9bd1c3…`, source 1,691,380 B, service ratio 1.464805, 20/20/all gates, deterministic existing-parent race PASS | +7% | PASS | принять evidence-only `4342def`, интегрировать и финальный delta-review |

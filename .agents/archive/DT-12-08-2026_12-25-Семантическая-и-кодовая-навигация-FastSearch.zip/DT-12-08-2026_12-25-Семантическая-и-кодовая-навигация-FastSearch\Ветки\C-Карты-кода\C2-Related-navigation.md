<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист C2 — Related navigation

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-17`
- Branch / Leaf ID: `C / C2`
- Вес задачи: `6%`
- Состояние: `MATERIALIZED RUNNING`

## Наблюдаемое изменение

- Baseline: C1 accepted maps persist, but real `related` remains unavailable.
- После листа: explicit map-to-document/map/symbol relations return deterministic canonical records with provenance; missing/stale/dangling relations are structured and never fabricated.

## Целевое состояние листа

Related navigation follows accepted explicit relations and stable IDs only. Catalog/map links remain navigation hints, not compiler-resolved definition/reference. Deletion and stale map state are visible after reopen.

## Preconditions

- C1 master PASS and accepted D2 are integrated by Root at immutable base `56ad9f2fcfa43fcf0a90bebe5d6d5c4bd2f8e6b1`; exact C2 base contains A2+C1+D2. C2 consumes D2 structural identity mandatorily for every symbol-target row in the accepted map section.

## Ownership

- Write: only `src/adapters/maps/**`, C2-specific tests/fixtures/evidence.
- Read-only: public domain/ports, module registry, source/state/lexical/vector/symbol/application and accepted C1/D2 artifacts.
- If accepted ports cannot express required deterministic provenance or production composition requires an A/E-owned change, stop for bounded Root replan; test-only module inclusion is forbidden.

## Definition of Done

- Found/missing/dangling/cycle/delete/stale cases and deterministic order pass through `CodeMapPort`; accepted map→symbol targets resolve against exact D2 identity, and the oracle is replayed after reopen/delete/rename. `Partial` is allowed only for explicitly unsupported/out-of-contract targets, not accepted corpus rows.

## Операционная проверка

- RED on exact `56ad9f2fcfa43fcf0a90bebe5d6d5c4bd2f8e6b1`: add the accepted C2 relation fixture and targeted production test proving `related` cannot yet resolve its document/map/symbol targets through the C1 adapter and exact D2 structural IDs.
- GREEN: implement deterministic maps-only relation traversal covering found, missing, dangling, cycle, delete and stale cases; accepted symbol-target rows must resolve to exact D2 IDs, preserve provenance and remain stable over five repeats.
- REFACTOR: remove duplicate traversal/ordering code without changing accepted public ports, state authority or D2 identity; rerun targeted suite after every bounded change.
- Final gate: targeted C2 relation suite plus A1 quality oracle Q01-Q04, full locked workspace tests, fmt/clippy, and combined map→symbol replay after reopen/delete/rename on the same exact base before E1.

## Условия остановки

- Relation needs compiler resolution, cyclic ownership with D/E or public error/provenance gap → Root replan; E remains closed.

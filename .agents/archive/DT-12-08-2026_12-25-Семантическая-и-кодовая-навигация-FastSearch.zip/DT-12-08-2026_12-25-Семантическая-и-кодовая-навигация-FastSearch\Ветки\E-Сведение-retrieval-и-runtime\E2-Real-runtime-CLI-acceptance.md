<!-- dtree generator=0.2.0 schema-sha256=87d9f90a383b49732bad06d7dc45b7eff3eec2011144a9341cdb69e4782ad132 -->
# Лист E2 — Real runtime CLI acceptance

- Task ID: `FASTSEARCH-DT3`
- Plan version: `PV-29`
- Branch / Leaf ID: `E / E2`
- Вес задачи: `7%`
- Состояние: `PV-29 STRICT FINAL ACCEPTED / INTEGRATED`; performance product/evidence `b07abdc`/`4342def`, final RAII candidate `8f921f63c46922494a9d0e6115e24b2e07c6c956`, integration `7d055df6f2aa2eed81ec31dc6de647221e7b2ee2`

## Наблюдаемое изменение

- Baseline: E1 fused core accepted, production CLI/runtime still DT2 lexical-only composition.
- После листа: one real production composition accepts replaceable document/code roots and service root, indexes/reopens/rebuilds all accepted capabilities, exposes fused search/get/related/status and passes representative quality/performance/recovery gates.

## Целевое состояние листа

Normal CLI has no test/provider/mock alternate factory. Optional provider absence is a supported configuration only because the same production composition contains an accepted real vector adapter; it is not a substitute for that adapter. Service artifacts satisfy the A1 canonical containment/reparse contract, remain excluded from source scan and are cleaned only by exact run marker. A second process observes committed authority/projection status honestly.

## Preconditions

- E1 master PASS integrated at exact immutable base `cc91f63780357538b2e86e78adc8bee7fd76f510`; accepted A2/B2/C2/D2 contracts are frozen inputs.
- E2 resumes after D2 PV-25 node-budget amendment master PASS and Root integration. Root advances E worktree and records a new exact immutable anchor; frozen E2 safety R2 changes are merged without weakening their tests.
- Current resume gate supersedes the old D-only anchor: A2 Windows safety dependency must pass master review and be integrated by Root; Root then merges it into the frozen E2 product/safety branch and records a new exact immutable anchor before any further E mutation or acceptance run.
- Final SAFE backflow: pathname revalidation is defense-in-depth only. On Windows the runtime holds service and `runs` directory handles opened without `FILE_SHARE_DELETE` for its lifetime; an attempted delete/rename/junction swap must be OS-denied and external sentinel/marker remain absent. A2 owns only the direct Windows API dependency; E owns handle lifecycle and tests after the exact dependency merge anchor.
- Performance resume gate: A1 PV-28 evidence amendment must be master PASS and integrated; Root then records a new exact E2 anchor. Runner classifies in-process warm queries against 500 ms and new-process reopen+query against 750 ms, preserving all raw samples and semantics.
- Performance producer gate satisfied: accepted A1 candidate `a0178dd70bb4dc09434c7ed6da545043d2cc9233` integrated as `ccab337`; Root merged it into E2 and recorded exact resume anchor `16deeeb826b26f29af2587dd17024252104a4f47`.
- Root-approved runtime acceptance inputs are read-only `tests/fixtures/dt3/document-root` + `tests/fixtures/dt2` as deterministic document root and the current exact FastSearch integration Rust source contour as code root. Arbitrary temporary copied roots prove replaceability. The redacted historical 918-file A1 root has no recoverable machine path and is not falsely claimed; E2 records this as external scale residual, not as a functional bypass.
- PV-29 producer ordering: E2 may implement disjoint runner and exact-run handle closure on `054055f`, but final evidence/candidate acceptance waits B2 immutable-model PASS, Root integration and a new exact E2 anchor. Then all 20 release processes, E5 recovery and cross-branch gates are replayed on that anchor.
- Current execution transition: Root explicitly authorizes only E2 RED/GREEN code/tests for `INT-EVID-01` and `INT-SAFE-01` on exact `054055f`; no final release JSON, candidate acceptance or master PASS claim is allowed until B2 is accepted/integrated and Root records the new immutable replay anchor.
- Producer gate satisfied: B2 candidate `21d942048eac6772d386f39ddba907e65f68f589` master+security PASS integrated as `3a6ed6a`; Root merged it into E and recorded final replay anchor `5ea884bd70e3db161624379ac84ef45b9b8085e0`.

## Ownership

- Write: `src/application/**`, CLI/runtime composition, E2-specific tests/fixtures/evidence and final integration report draft.
- Read-only: public A contracts/dependencies and B/C/D adapter internals; no governance controlled-field writes, provider downloads or model cache mutation.
- Production composition may parameterize the verified E5 cache path/configuration but cannot hardcode a user path. Provider absence remains typed fallback in the same composition, not an alternate mock route.

## Definition of Done

- Init/update/rebuild/search/get/related/status run on arbitrary temporary fixture roots and approved representative roots without hardcode.
- Add/change/delete, vector failure/absence, partial unsupported symbol/map state, drop/reopen and rebuild equality pass; accepted map→symbol rows are resolved, not permanently partial; no false Current.
- Copied legacy DT2 service → named-root update → separate-process reopen → rebuild follows A2 transition policy with no wrong `get`, duplicate/collision or false `Current`.
- All activated A1 quality sections and numeric release performance budgets/ratios pass or produce explicit rework; production mock audit none; DT2 all-targets remains GREEN.
- Final integration report separates structural navigation from unavailable compiler definition/references, lists DT4 transport gap and carries a read-only TDR/paradigm delta/evidence handoff. It does not mutate/promote/close governance fields without separately assigned writer/review/approval.

## Операционная проверка

- RED: exact base CLI composes only DT2 lexical runtime and exposes no fused vector/map/symbol navigation or named code-root lifecycle.
- GREEN: one production composition wires accepted source/state/lexical/vector/maps/symbols/fusion; CLI supports parameterized document root, code root, service root and optional verified local E5 root for init/update/rebuild/search/get/related/status. No test/provider factory appears in normal help.
- Causal lifecycle: add/change/delete, map→symbol, unsupported syntax, provider absence/failure/recovery, copied legacy stale→rebuild, collision, second-process reopen and rebuild equality; no false Current and no fabricated compiler semantics.
- Acceptance: arbitrary temp copies plus Root-approved deterministic document/code inputs; all 24 A1 rows five repeats, release five cold+five warm, non-vector `<=1024 MiB`, vector child `<=2048 MiB`, service-state ratios excluding static model bytes. Exact service containment, real junction rejection and cleanup-marker readback.
- Evidence integrity: WorkRoot/service/run/model/cache paths are pairwise and two-way disjoint from every input root after canonical nearest-existing-ancestor and reparse checks. Source bytes are the sum of the frozen sorted pre-write inventory, re-read equal after run; generated state is never counted as source. Negative overlap/junction tests reject before write. `service_bytes / frozen_source_bytes <=2.0` is recomputed/read back from committed JSON; prior `1.434960` claim is retracted because its denominator was contaminated.
- Exact-run safety: service, `runs` and the exact invocation-owned run directory are handle-pinned without write/delete replacement for the complete marker/write/cleanup lifetime. Check/create/guard is one fail-before-write boundary. Coordinated race attempts run-child rename/delete/junction swap before marker write and during cleanup; operation is denied or detected before external write/delete, external sentinel is unchanged and local exact cleanup succeeds.
- Final gates: targeted E2/CLI, production mock audit, combined E1+B2+C2+D2, full locked tests, release build, fmt/clippy, final integration report with residuals, independent E master review. Archive/main merge remain Root-only after PASS.

## Условия остановки

- Hardcoded/machine path, service containment/reparse/cleanup violation, legacy transition mismatch, dangling accepted map→symbol relation, missing accepted real vector contour, partial failure corrupts authority, lifecycle lies, quality/performance miss or mock/alternate route exists → REWORK/BLOCKED; no archive/main merge.
